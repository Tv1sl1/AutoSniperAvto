# Car Recognition & Slang Dictionary
# Format: KEYWORD -> NORMALIZED FORM
# Usage: synonym_dict.normalize_text(text)

"""
Enhanced synonyms dictionary for improved car recognition in VK groups
Supports slang terms, typos, and regional variations
"""

CAR_BRANDS = {
    "lada": ["LADA", "VOLKSWAGEN", "TODOSAR", "NIKA", "VAZ"],
    "renault": ["RENAULT", "CAMAZ", "TOYA", "TOYOTA", "NISSAN"],
    "chevrolet": ["CHEVROLET", "GOL", "AVTOR", "CHOPPER"],
    "bmw": ["BMW", "FERRARI", "MERCEDES", "LEXUS"],
    "audi": ["AUDI", "LANCIADA", "CHEBUTKAN", "DACIA"],
    "mercedes": ["MERSEDES", "BMC", "BWC", "DAM"]
}

CAR_MODELS = {
    "tosiok": ["TOYOTA", "TOSIK"],
    "lancadada": ["CHEVROLET", "LANCIADA", "CHEBUTKAN"],
    "laevda": ["LADA", "LAVODA"],
    "lavoda": ["LADA", "LAZIO"],
}

CAR_PATTERNS = [
    ("engine", ["ENGINE", "MOTOR", "DVIGATEL", "TRANSMISSION"]),
    ("brakes", ["TROMKI", "TROMILY", "BRAKES"]),
    ("transmission", ["COROBKA", "DVIGA", "TRANS"]),
]

def normalize_car_brand(word):
    """Normalize car brand name"""
    lower_word = word.lower()
    
    for brand, variations in CAR_BRANDS.items():
        if lower_word in [v.lower() for v in variations]:
            return brand.upper()
    
    # Check common variations
    variations = ["VAZ", "LADA", "TOYOTA", "NISSAN"]
    if lower_word in [v.lower() for v in variations]:
        return lower_word.upper()
    
    return word

def add_slang_support(text):
    """Add slang to text"""
    slang_terms = [
        ("golf", "GOL"),
        ("bmw", "BMC"),
        ("chevrolet", "CHEVROLET"),
        ("renerault", "RENAULT"),
    ]
    
    for term, slang in slang_terms:
        if term.lower() in text.lower():
            return f"{text} [{slang}]"
    
    return text

if __name__ == "__main__":
    # Test the dictionary
    test = "lada renerout gol bmw chevrolet tosik"
    result = test.replace("renerault", "RENAULT")
    print(f"Original: {test}")
    print(f"Processed: {result}")

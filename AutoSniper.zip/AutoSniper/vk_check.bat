@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoSniper - VK check

set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"

"%PYTHON%" --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    pause
    exit /b 1
)

echo Checking VK token and communities...
echo.
"%PYTHON%" scripts\vk_check.py
echo.
echo Press any key to close.
pause >nul

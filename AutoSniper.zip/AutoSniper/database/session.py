"""Async engine/session factory and small database helpers."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import StaticPool

from config.logger import get_logger
from config.settings import DEFAULT_DATABASE_URL, Settings, normalize_database_url
from database.models import Base

logger = get_logger(__name__)


def _engine_kwargs(url: str, *, echo: bool, pool_size: int, max_overflow: int) -> dict[str, object]:
    kwargs: dict[str, object] = {"echo": echo, "future": True, "pool_pre_ping": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"timeout": 30}
        if ":memory:" in url:
            # Every connection to :memory: would otherwise get its own database.
            kwargs["poolclass"] = StaticPool
            kwargs["connect_args"] = {"check_same_thread": False}
    else:
        kwargs["pool_size"] = pool_size
        kwargs["max_overflow"] = max_overflow
        kwargs["pool_recycle"] = 1800
    return kwargs


def _install_sqlite_pragmas(engine: AsyncEngine) -> None:
    """Enable FKs (off by default in SQLite) and WAL for file databases."""

    sync_engine = engine.sync_engine

    @event.listens_for(sync_engine, "connect")
    def _on_connect(dbapi_connection, _connection_record):  # pragma: no cover - driver hook
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
        finally:
            cursor.close()


class Database:
    """Owns the async engine and exposes scoped sessions."""

    def __init__(
        self,
        url: str = DEFAULT_DATABASE_URL,
        *,
        echo: bool = False,
        pool_size: int = 5,
        max_overflow: int = 10,
    ) -> None:
        self.url = normalize_database_url(url)
        self.engine: AsyncEngine = create_async_engine(
            self.url,
            **_engine_kwargs(self.url, echo=echo, pool_size=pool_size, max_overflow=max_overflow),
        )
        if self.url.startswith("sqlite"):
            _install_sqlite_pragmas(self.engine)
        self.session_factory: async_sessionmaker[AsyncSession] = async_sessionmaker(
            bind=self.engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
        )

    @classmethod
    def from_settings(cls, settings: Settings) -> Database:
        return cls(
            settings.database_url,
            echo=settings.db_echo,
            pool_size=settings.db_pool_size,
            max_overflow=settings.db_max_overflow,
        )

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        """Session scope: commit on success, rollback on exception."""
        session = self.session_factory()
        try:
            yield session
            if session.in_transaction():
                await session.commit()
        except Exception:
            if session.in_transaction():
                await session.rollback()
            raise
        finally:
            await session.close()

    async def create_all(self) -> None:
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database schema ensured at %s", _safe_url(self.url))

    async def drop_all(self) -> None:
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)

    async def healthcheck(self) -> bool:
        try:
            async with self.engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            return True
        except Exception as exc:  # pragma: no cover - depends on driver/network
            logger.error("Database healthcheck failed: %s", exc)
            return False

    async def close(self) -> None:
        await self.engine.dispose()


def _safe_url(url: str) -> str:
    """Hide credentials in a DSN before logging it."""
    if "@" not in url:
        return url
    scheme, _, rest = url.partition("://")
    _, _, host = rest.rpartition("@")
    return f"{scheme}://***@{host}"


_DATABASE: Database | None = None


def init_database(settings: Settings) -> Database:
    global _DATABASE
    if _DATABASE is None:
        _DATABASE = Database.from_settings(settings)
    return _DATABASE


def get_database() -> Database:
    if _DATABASE is None:
        raise RuntimeError("Database is not initialized; call init_database() first.")
    return _DATABASE


async def close_database() -> None:
    global _DATABASE
    if _DATABASE is not None:
        await _DATABASE.close()
        _DATABASE = None


__all__ = [
    "Database",
    "close_database",
    "get_database",
    "init_database",
]

"""Repository layer — all SQL lives here, handlers/services stay declarative."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import delete, func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from config.logger import get_logger
from database.models import Listing, Notification, ScraperState, Source, Subscription, User

logger = get_logger(__name__)


def utcnow() -> datetime:
    return datetime.now(UTC)


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get(self, user_id: int) -> User | None:
        return await self.session.get(User, user_id)

    async def get_or_create(
        self,
        user_id: int,
        *,
        username: str | None = None,
        first_name: str | None = None,
    ) -> User:
        user = await self.session.get(User, user_id)
        if user is None:
            user = User(user_id=user_id, username=username, first_name=first_name, is_active=True)
            try:
                async with self.session.begin_nested():
                    self.session.add(user)
                    await self.session.flush()
            except IntegrityError:
                # Concurrent /start from two workers — reload the winner row.
                user = await self.session.get(User, user_id)
                if user is None:  # pragma: no cover - extremely unlikely
                    raise
            logger.info("New bot user: %s (@%s)", user_id, username)
        else:
            changed = False
            if username and user.username != username:
                user.username = username
                changed = True
            if first_name and user.first_name != first_name:
                user.first_name = first_name
                changed = True
            if changed:
                await self.session.flush()
        return user

    async def set_active(self, user_id: int, active: bool) -> bool:
        user = await self.session.get(User, user_id)
        if user is None:
            return False
        user.is_active = active
        await self.session.flush()
        return True

    async def count(self) -> int:
        return int(await self.session.scalar(select(func.count()).select_from(User)) or 0)

    async def count_active(self) -> int:
        stmt = select(func.count()).select_from(User).where(User.is_active.is_(True))
        return int(await self.session.scalar(stmt) or 0)


class SubscriptionRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(
        self,
        *,
        user_id: int,
        make: str,
        model: str | None = None,
        models: Sequence[str] | None = None,
        max_price: int | None = None,
        city: str | None = None,
        max_distance_km: int | None = None,
        max_age_days: int | None = 0,
        year_min: int | None = None,
        is_active: bool = True,
    ) -> Subscription:
        model_list = [str(item).strip() for item in (models or []) if str(item).strip()]
        primary_model = (model or "").strip() or (model_list[0] if model_list else None)
        if primary_model and primary_model not in model_list:
            model_list.insert(0, primary_model)
        if max_distance_km is not None:
            max_distance_km = max(0, min(int(max_distance_km), 5000))
        if max_age_days is not None:
            max_age_days = max(0, min(int(max_age_days), 3650))

        subscription = Subscription(
            user_id=user_id,
            make=make.strip(),
            model=primary_model,
            models=model_list,
            max_price=max_price,
            city=(city or "").strip() or None,
            max_distance_km=max_distance_km,
            max_age_days=max_age_days,
            year_min=year_min,
            is_active=is_active,
            cold_start_done=False,
        )
        self.session.add(subscription)
        await self.session.flush()
        return subscription

    async def get(self, subscription_id: int) -> Subscription | None:
        return await self.session.get(Subscription, subscription_id)

    async def get_owned(self, subscription_id: int, user_id: int) -> Subscription | None:
        stmt = select(Subscription).where(
            Subscription.id == subscription_id, Subscription.user_id == user_id
        )
        return await self.session.scalar(stmt)

    async def find_duplicate(
        self,
        *,
        user_id: int,
        make: str,
        model: str | None,
        max_price: int | None,
        city: str | None,
        max_distance_km: int | None = None,
        year_min: int | None = None,
    ) -> Subscription | None:
        stmt = select(Subscription).where(
            Subscription.user_id == user_id,
            func.lower(Subscription.make) == make.strip().lower(),
            func.lower(func.coalesce(Subscription.model, "")) == (model or "").strip().lower(),
            func.lower(func.coalesce(Subscription.city, "")) == (city or "").strip().lower(),
            func.coalesce(Subscription.max_price, 0) == (max_price or 0),
            func.coalesce(Subscription.max_distance_km, -1)
            == (max_distance_km if max_distance_km is not None else -1),
        )
        if year_min is None:
            stmt = stmt.where(Subscription.year_min.is_(None))
        else:
            stmt = stmt.where(Subscription.year_min == year_min)
        return await self.session.scalar(stmt.limit(1))

    async def list_for_user(
        self,
        user_id: int,
        *,
        active_only: bool = False,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[Subscription]:
        stmt = select(Subscription).where(Subscription.user_id == user_id)
        if active_only:
            stmt = stmt.where(Subscription.is_active.is_(True))
        stmt = stmt.order_by(Subscription.id.desc()).offset(max(offset, 0))
        if limit is not None:
            stmt = stmt.limit(limit)
        result = await self.session.scalars(stmt)
        return list(result)

    async def count_for_user(self, user_id: int, *, active_only: bool = False) -> int:
        stmt = select(func.count()).select_from(Subscription).where(Subscription.user_id == user_id)
        if active_only:
            stmt = stmt.where(Subscription.is_active.is_(True))
        return int(await self.session.scalar(stmt) or 0)

    async def list_active(self) -> list[Subscription]:
        """Active subscriptions of active users — the matching universe."""
        stmt = (
            select(Subscription)
            .join(User, User.user_id == Subscription.user_id)
            .where(Subscription.is_active.is_(True), User.is_active.is_(True))
            .options(selectinload(Subscription.user))
            .order_by(Subscription.id)
        )
        result = await self.session.scalars(stmt)
        return list(result)

    async def list_active_for_user(self, user_id: int) -> list[Subscription]:
        stmt = (
            select(Subscription)
            .where(Subscription.user_id == user_id, Subscription.is_active.is_(True))
            .order_by(Subscription.id.desc())
        )
        result = await self.session.scalars(stmt)
        return list(result)

    async def set_active(self, subscription_id: int, user_id: int, active: bool) -> Subscription | None:
        subscription = await self.get_owned(subscription_id, user_id)
        if subscription is None:
            return None
        subscription.is_active = active
        await self.session.flush()
        return subscription

    async def delete_owned(self, subscription_id: int, user_id: int) -> bool:
        subscription = await self.get_owned(subscription_id, user_id)
        if subscription is None:
            return False
        await self.session.delete(subscription)
        await self.session.flush()
        return True

    async def mark_cold_start_done(self, subscription_ids: Sequence[int]) -> None:
        if not subscription_ids:
            return
        stmt = (
            update(Subscription)
            .where(Subscription.id.in_(list(subscription_ids)))
            .values(cold_start_done=True)
        )
        await self.session.execute(stmt)
        await self.session.flush()

    async def delete_all_for_user(self, user_id: int) -> int:
        stmt = delete(Subscription).where(Subscription.user_id == user_id)
        result = await self.session.execute(stmt)
        await self.session.flush()
        return int(result.rowcount or 0)

    async def count_active(self) -> int:
        stmt = (
            select(func.count())
            .select_from(Subscription)
            .join(User, User.user_id == Subscription.user_id)
            .where(Subscription.is_active.is_(True), User.is_active.is_(True))
        )
        return int(await self.session.scalar(stmt) or 0)


class ListingRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_hash(self, hash_id: str) -> Listing | None:
        return await self.session.scalar(select(Listing).where(Listing.hash_id == hash_id))

    async def get_by_external(self, source: Source, external_id: str) -> Listing | None:
        if not external_id:
            return None
        stmt = select(Listing).where(Listing.source == source, Listing.external_id == external_id)
        return await self.session.scalar(stmt)

    async def add(self, listing: Listing) -> tuple[Listing, bool]:
        """Insert a listing; return ``(listing, created)``.

        A concurrent insert of the same ``hash_id``/external id is tolerated:
        the existing row is returned and ``created`` is ``False``.
        """
        try:
            async with self.session.begin_nested():
                self.session.add(listing)
                await self.session.flush()
            return listing, True
        except IntegrityError:
            existing = await self.get_by_hash(listing.hash_id)
            if existing is None and listing.external_id:
                existing = await self.get_by_external(listing.source, listing.external_id)
            if existing is None:  # pragma: no cover - constraint we don't know about
                raise
            return existing, False

    async def save(self, listing: Listing) -> tuple[Listing, bool]:
        """Insert or refresh an existing listing."""
        existing = await self.get_by_external(listing.source, listing.external_id or "")
        if existing is not None:
            # Keep the first-seen hash stable but refresh mutable fields.
            existing.price = listing.price
            existing.title = listing.title
            existing.raw_text = listing.raw_text
            existing.city = listing.city or existing.city
            existing.photos = listing.photos or existing.photos
            existing.published_at = listing.published_at or existing.published_at
            existing.date_approx = listing.date_approx or existing.date_approx
            existing.make = listing.make or existing.make
            existing.model = listing.model or existing.model
            existing.year = listing.year or existing.year
            existing.generation = listing.generation or existing.generation
            existing.transmission = listing.transmission or existing.transmission
            existing.engine_volume = listing.engine_volume or existing.engine_volume
            await self.session.flush()
            return existing, False
        return await self.add(listing)

    async def list_recent(self, limit: int = 20, *, source: Source | None = None) -> list[Listing]:
        stmt = select(Listing).order_by(Listing.id.desc()).limit(limit)
        if source is not None:
            stmt = stmt.where(Listing.source == source)
        result = await self.session.scalars(stmt)
        return list(result)

    async def count(self) -> int:
        return int(await self.session.scalar(select(func.count()).select_from(Listing)) or 0)

    async def count_by_source(self) -> dict[str, int]:
        stmt = select(Listing.source, func.count()).group_by(Listing.source)
        rows = (await self.session.execute(stmt)).all()
        return {source.value: int(count) for source, count in rows}


class NotificationRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def existing_listing_ids(self, user_id: int, listing_ids: Sequence[int]) -> set[int]:
        if not listing_ids:
            return set()
        stmt = select(Notification.listing_id).where(
            Notification.user_id == user_id, Notification.listing_id.in_(list(listing_ids))
        )
        return set((await self.session.scalars(stmt)).all())

    async def create(
        self,
        *,
        user_id: int,
        listing_id: int,
        subscription_id: int | None = None,
    ) -> Notification | None:
        notification = Notification(
            user_id=user_id,
            listing_id=listing_id,
            subscription_id=subscription_id,
        )
        try:
            async with self.session.begin_nested():
                self.session.add(notification)
                await self.session.flush()
            return notification
        except IntegrityError:
            return None

    async def get(self, notification_id: int) -> Notification | None:
        return await self.session.get(Notification, notification_id)

    async def mark_sent(self, notification_id: int) -> None:
        notification = await self.session.get(Notification, notification_id)
        if notification is None:
            return
        notification.sent_at = utcnow()
        notification.attempts = (notification.attempts or 0) + 1
        notification.last_error = None
        await self.session.flush()

    async def mark_failed(self, notification_id: int, error: str) -> None:
        notification = await self.session.get(Notification, notification_id)
        if notification is None:
            return
        notification.attempts = (notification.attempts or 0) + 1
        notification.last_error = error[:500]
        await self.session.flush()

    async def list_pending(self, limit: int = 50) -> list[Notification]:
        stmt = (
            select(Notification)
            .where(Notification.sent_at.is_(None))
            .options(selectinload(Notification.listing))
            .order_by(Notification.id)
            .limit(limit)
        )
        result = await self.session.scalars(stmt)
        return list(result)

    async def count_sent(self) -> int:
        stmt = select(func.count()).select_from(Notification).where(Notification.sent_at.is_not(None))
        return int(await self.session.scalar(stmt) or 0)

    async def count_pending(self) -> int:
        stmt = select(func.count()).select_from(Notification).where(Notification.sent_at.is_(None))
        return int(await self.session.scalar(stmt) or 0)


class ScraperStateRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get(self, name: str) -> ScraperState | None:
        return await self.session.get(ScraperState, name)

    async def get_or_create(self, name: str) -> ScraperState:
        state = await self.session.get(ScraperState, name)
        if state is None:
            state = ScraperState(name=name, cursor={})
            try:
                async with self.session.begin_nested():
                    self.session.add(state)
                    await self.session.flush()
            except IntegrityError:  # pragma: no cover - concurrent creation
                state = await self.session.get(ScraperState, name)
                if state is None:
                    raise
        return state

    async def get_cursor(self, name: str) -> dict[str, Any]:
        state = await self.get(name)
        return dict(state.cursor or {}) if state else {}

    async def record_success(self, name: str, *, cursor: dict[str, Any], found: int) -> ScraperState:
        state = await self.get_or_create(name)
        state.cursor = cursor or {}
        state.last_run_at = utcnow()
        state.last_success_at = state.last_run_at
        state.last_error = None
        state.consecutive_failures = 0
        state.total_listings = int(state.total_listings or 0) + max(found, 0)
        await self.session.flush()
        return state

    async def record_failure(self, name: str, error: str) -> ScraperState:
        state = await self.get_or_create(name)
        state.last_run_at = utcnow()
        state.last_error = error[:1000]
        state.consecutive_failures = int(state.consecutive_failures or 0) + 1
        await self.session.flush()
        return state

    async def list_all(self) -> list[ScraperState]:
        result = await self.session.scalars(select(ScraperState).order_by(ScraperState.name))
        return list(result)


class StatsRepository:
    """Read-only aggregate counters for /status."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def overview(self) -> dict[str, int]:
        return {
            "users": int(await self.session.scalar(select(func.count()).select_from(User)) or 0),
            "active_users": int(
                await self.session.scalar(
                    select(func.count()).select_from(User).where(User.is_active.is_(True))
                )
                or 0
            ),
            "subscriptions": int(
                await self.session.scalar(select(func.count()).select_from(Subscription)) or 0
            ),
            "active_subscriptions": int(
                await self.session.scalar(
                    select(func.count())
                    .select_from(Subscription)
                    .where(Subscription.is_active.is_(True))
                )
                or 0
            ),
            "listings": int(await self.session.scalar(select(func.count()).select_from(Listing)) or 0),
            "notifications_sent": int(
                await self.session.scalar(
                    select(func.count())
                    .select_from(Notification)
                    .where(Notification.sent_at.is_not(None))
                )
                or 0
            ),
            "notifications_pending": int(
                await self.session.scalar(
                    select(func.count())
                    .select_from(Notification)
                    .where(Notification.sent_at.is_(None))
                )
                or 0
            ),
        }


__all__ = [
    "ListingRepository",
    "NotificationRepository",
    "ScraperStateRepository",
    "StatsRepository",
    "SubscriptionRepository",
    "UserRepository",
    "utcnow",
]

"""SQLAlchemy 2.0 ORM models.

Schema overview
---------------
``users``          — Telegram users of the bot.
``subscriptions``  — saved car search criteria (one row per filter).
``listings``       — deduplicated cars found by scrapers.
``notifications``  — (user, listing) delivery journal, prevents repeat alerts.
``scraper_states`` — per-scraper cursor / health persisted between restarts.
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Declarative base for every model."""


# JSONB on PostgreSQL, plain JSON (TEXT) everywhere else.
JSONList = JSON().with_variant(JSONB, "postgresql")


class Source(enum.StrEnum):
    """Where a listing came from."""

    TG = "TG"
    VK = "VK"
    AVITO = "AVITO"
    AUTORU = "AUTORU"
    DROM = "DROM"
    RSS = "RSS"

    @property
    def title(self) -> str:
        return {
            Source.TG: "Telegram",
            Source.VK: "VKontakte",
            Source.AVITO: "Avito",
            Source.AUTORU: "Auto.ru",
            Source.DROM: "Drom.ru",
            Source.RSS: "RSS",
        }[self]


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )


class User(TimestampMixin, Base):
    __tablename__ = "users"

    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    # ``is_active`` doubles as the notification switch for the user.
    is_active: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default=text("true"), index=True
    )

    subscriptions: Mapped[list[Subscription]] = relationship(
        back_populates="user",
        cascade="all, delete-orphan",
        passive_deletes=True,
        order_by="Subscription.id",
    )
    notifications: Mapped[list[Notification]] = relationship(
        back_populates="user",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"<User {self.user_id} @{self.username} active={self.is_active}>"


class Subscription(TimestampMixin, Base):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False, index=True
    )
    make: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    # ``model`` keeps the first/legacy model; ``models`` stores all selected models.
    model: Mapped[str | None] = mapped_column(String(64), nullable=True)
    models: Mapped[list[str]] = mapped_column(
        JSONList, nullable=False, default=list, server_default=text("'[]'")
    )
    max_price: Mapped[int | None] = mapped_column(Integer, nullable=True)
    city: Mapped[str | None] = mapped_column(String(64), nullable=True)
    # 0 = only the selected city, NULL = no distance limit.
    max_distance_km: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # Only listings published within this many days are matched. NULL/0 = no limit.
    max_age_days: Mapped[int | None] = mapped_column(
        Integer, nullable=True, default=7, server_default=text("7")
    )
    year_min: Mapped[int | None] = mapped_column(Integer, nullable=True)
    is_active: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default=text("true"), index=True
    )
    # New subscriptions skip notifications on their first scrape (cold start).
    cold_start_done: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default=text("true")
    )

    user: Mapped[User] = relationship(back_populates="subscriptions")
    notifications: Mapped[list[Notification]] = relationship(back_populates="subscription")

    __table_args__ = (
        Index("ix_subscriptions_user_active", "user_id", "is_active"),
        Index("ix_subscriptions_active_make", "is_active", "make"),
        CheckConstraint("max_price IS NULL OR max_price > 0", name="ck_subscriptions_max_price_positive"),
        CheckConstraint(
            "year_min IS NULL OR (year_min >= 1950 AND year_min <= 2100)",
            name="ck_subscriptions_year_min_range",
        ),
        CheckConstraint(
            "max_distance_km IS NULL OR (max_distance_km >= 0 AND max_distance_km <= 5000)",
            name="ck_subscriptions_max_distance_range",
        ),
        CheckConstraint(
            "max_age_days IS NULL OR (max_age_days >= 0 AND max_age_days <= 3650)",
            name="ck_subscriptions_max_age_range",
        ),
    )

    @property
    def model_list(self) -> list[str]:
        """All models, falling back to the legacy single ``model`` column."""
        values = [str(item).strip() for item in (self.models or []) if str(item).strip()]
        if not values and self.model:
            values = [self.model]
        return values

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return (
            f"<Subscription {self.id} user={self.user_id} {self.make} "
            f"{', '.join(self.model_list) or '*'} <= {self.max_price} "
            f"{self.city or '*'} active={self.is_active}>"
        )


class Listing(Base):
    __tablename__ = "listings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # SHA-256(title | price | normalized source url) — deduplication key.
    hash_id: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)
    source: Mapped[Source] = mapped_column(
        Enum(Source, native_enum=False, length=16, validate_strings=True),
        nullable=False,
        index=True,
    )
    # Native id inside the source (Telegram message id, VK post id, ...).
    external_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    price: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    city: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    url: Mapped[str] = mapped_column(String(1024), nullable=False)
    photos: Mapped[list[str]] = mapped_column(JSONList, nullable=False, default=list)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    # True when the source has no publication date and the fetch time is used.
    date_approx: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default=text("false")
    )
    raw_text: Mapped[str] = mapped_column(Text, nullable=False, default="")
    # Parsed vehicle attributes — stored so matching stays cheap and explainable.
    make: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    model: Mapped[str | None] = mapped_column(String(64), nullable=True)
    year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    generation: Mapped[str | None] = mapped_column(String(32), nullable=True)
    transmission: Mapped[str | None] = mapped_column(String(16), nullable=True)
    engine_volume: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )

    notifications: Mapped[list[Notification]] = relationship(
        back_populates="listing",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    __table_args__ = (
        UniqueConstraint("source", "external_id", name="uq_listings_source_external_id"),
        Index("ix_listings_source_published", "source", "published_at"),
        Index("ix_listings_make_model", "make", "model"),
    )

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"<Listing {self.id} {self.source.value} {self.make} {self.model} {self.price}>"


class Notification(Base):
    __tablename__ = "notifications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False, index=True
    )
    listing_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("listings.id", ondelete="CASCADE"), nullable=False, index=True
    )
    subscription_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("subscriptions.id", ondelete="SET NULL"), nullable=True
    )
    # NULL until the Telegram API confirms delivery; failed rows are retried.
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    last_error: Mapped[str | None] = mapped_column(String(512), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    user: Mapped[User] = relationship(back_populates="notifications")
    listing: Mapped[Listing] = relationship(back_populates="notifications")
    subscription: Mapped[Subscription | None] = relationship(back_populates="notifications")

    __table_args__ = (
        UniqueConstraint("user_id", "listing_id", name="uq_notifications_user_listing"),
        Index("ix_notifications_pending", "sent_at", "created_at"),
    )

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"<Notification {self.id} user={self.user_id} listing={self.listing_id} sent={bool(self.sent_at)}>"


class ScraperState(Base):
    """Persistent cursor/health for every scraper, keyed by its stable name."""

    __tablename__ = "scraper_states"

    name: Mapped[str] = mapped_column(String(64), primary_key=True)
    cursor: Mapped[dict[str, Any]] = mapped_column(JSONList, nullable=False, default=dict)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    consecutive_failures: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    total_listings: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"<ScraperState {self.name} failures={self.consecutive_failures}>"


__all__ = [
    "Base",
    "Listing",
    "Notification",
    "ScraperState",
    "Source",
    "Subscription",
    "User",
]

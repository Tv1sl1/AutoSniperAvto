"""Ad-hoc search tests: period, distance and multiple models."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from config.settings import Settings
from database.models import Source
from database.session import Database
from scrapers.base import BaseScraper, RawListing, ScrapeBatch, SearchQuery
from services.orchestrator import ScraperOrchestrator
from services.pipeline import IngestionPipeline

NOW = datetime.now(UTC)


class FakeScraper(BaseScraper):
    name = "fake"
    supports_search = True

    def __init__(self, listings: list[RawListing]) -> None:
        super().__init__(Settings())
        self.listings = listings

    async def fetch(self, cursor, queries) -> ScrapeBatch:
        return ScrapeBatch()

    async def search(self, query: SearchQuery, limit: int = 10) -> list[RawListing]:
        return self.listings[:limit]


def raw(
    title: str,
    text: str,
    price: int,
    city: str,
    published_at: datetime | None,
    suffix: str,
) -> RawListing:
    return RawListing(
        source=Source.VK,
        url=f"https://vk.com/wall-1_{suffix}",
        title=title,
        raw_text=text,
        external_id=f"-1_{suffix}",
        price=price,
        city=city,
        published_at=published_at,
    )


async def test_search_period_models_and_distance(db: Database) -> None:
    listings = [
        raw(
            "BMW X5 2020",
            "Продам BMW X5 2020, 2 900 000 руб., Москва",
            2_900_000,
            "Москва",
            NOW - timedelta(days=2),
            "1",
        ),
        raw(
            "BMW 3 Series 2019",
            "Продам BMW 3 Series 2019, 2 500 000 руб., Подольск",
            2_500_000,
            "Подольск",
            NOW - timedelta(days=10),
            "2",
        ),
        raw(
            "Audi A6 2020",
            "Продам Audi A6 2020, 2 500 000 руб., Москва",
            2_500_000,
            "Москва",
            NOW - timedelta(days=2),
            "3",
        ),
        raw(
            "BMW X5 2018",
            "Продам BMW X5 2018, 2 800 000 руб., Москва",
            2_800_000,
            "Москва",
            NOW - timedelta(days=40),
            "4",
        ),
    ]
    settings = Settings(single_search_limit=10)
    pipeline = IngestionPipeline(db, settings=settings)
    orchestrator = ScraperOrchestrator(
        db=db,
        pipeline=pipeline,
        scrapers=[FakeScraper(listings)],
        settings=settings,
    )

    try:
        query = SearchQuery(
            make="BMW",
            models=("3 Series", "X5"),
            city="Москва",
            max_price=3_000_000,
            max_distance_km=100,
        )
        week = await orchestrator.search_now(query, limit=10, max_age_days=7)
        assert [item.external_id for item in week] == ["-1_1"]

        month = await orchestrator.search_now(query, limit=10, max_age_days=30)
        assert [item.external_id for item in month] == ["-1_1", "-1_2"]

        everything = await orchestrator.search_now(query, limit=10, max_age_days=None)
        assert {item.external_id for item in everything} == {"-1_1", "-1_2", "-1_4"}
    finally:
        await orchestrator.close()

"""City distance helpers."""

from __future__ import annotations

from services.geo import (
    CITY_COORDINATES,
    city_within_radius,
    coordinates_for,
    distance_between_cities,
    has_coordinates,
    haversine_km,
)


def test_moscow_spb_distance_is_reasonable() -> None:
    distance = distance_between_cities("Москва", "СПб")
    assert distance is not None
    assert 600 <= distance <= 700


def test_same_city_distance_is_zero() -> None:
    assert distance_between_cities("Москва", "москва") == 0
    assert haversine_km(55.75, 37.61, 55.75, 37.61) == 0


def test_coordinates_and_support() -> None:
    assert coordinates_for("Санкт-Петербург") is not None
    assert has_coordinates("Санкт-Петербург") is True
    assert has_coordinates("Неизвестный Город") is False
    assert "Москва" in CITY_COORDINATES


def test_radius() -> None:
    assert city_within_radius("Москва", "Подольск", 50) is True
    assert city_within_radius("Москва", "Подольск", 10) is False
    assert city_within_radius("Москва", "Неизвестный Город", 100) is None

"""Phase A security/regression tests."""

from __future__ import annotations

from database.models import Listing, Source
from database.repositories import SubscriptionRepository, UserRepository
from database.session import Database
from services.normalizer import _scrub_phones
from services.notifier import TelegramNotifier


async def test_foreign_subscription_cannot_be_changed(db: Database) -> None:
    async with db.session() as session:
        await UserRepository(session).get_or_create(1, username="owner")
        await UserRepository(session).get_or_create(2, username="stranger")
        repo = SubscriptionRepository(session)
        subscription = await repo.create(user_id=1, make="BMW", model="X5")

        assert await repo.get_owned(subscription.id, 2) is None
        assert await repo.set_active(subscription.id, 2, False) is None
        assert await repo.delete_owned(subscription.id, 2) is False
        assert await repo.get(subscription.id) is not None


def test_phone_is_removed_from_stored_text() -> None:
    text = _scrub_phones("Звонить +7 (999) 123-45-67, цена 55 000 руб.")
    assert "+7 (999) 123-45-67" not in text
    assert "55 000" in text


def test_unknown_link_domain_is_not_rendered() -> None:
    notifier = TelegramNotifier(bot=None, allowed_link_domains=("avito.ru",))  # type: ignore[arg-type]
    listing = Listing(
        hash_id="x",
        source=Source.AVITO,
        title="BMW X5",
        url="https://evil.example/redirect",
        make="BMW",
        model="X5",
        date_approx=True,
    )
    caption = notifier.build_caption(listing)
    assert "evil.example" not in caption
    assert "Дата:</b> приблизительная" in caption


def test_daily_search_limit() -> None:
    from bot.handlers.search import _consume_daily_search, _search_usage

    _search_usage.clear()
    assert _consume_daily_search(7, 2) is True
    assert _consume_daily_search(7, 2) is True
    assert _consume_daily_search(7, 2) is False
    assert _consume_daily_search(7, 0) is True

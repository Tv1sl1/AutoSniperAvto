"""Shared pytest fixtures."""

from __future__ import annotations

import pytest_asyncio

from database.session import Database


@pytest_asyncio.fixture
async def db() -> Database:
    database = Database("sqlite+aiosqlite:///:memory:")
    await database.create_all()
    try:
        yield database
    finally:
        await database.close()

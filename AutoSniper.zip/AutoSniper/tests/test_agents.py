"""Tests for local model/text/quality agents."""

from __future__ import annotations

from database.models import Listing, Source
from scrapers.base import SearchQuery
from services.agents import (
    ModelAgent,
    SearchQualityAgent,
    TextAgent,
)


def test_model_agent_corrects_brand_typos() -> None:
    agent = ModelAgent()
    assert agent.check_make("Тайота").corrected == "Toyota"
    assert agent.check_make("БМВ").corrected == "BMW"
    assert agent.check_make("Мерседес").corrected == "Mercedes-Benz"
    assert agent.check_make("Моямарка").suggestions == ()


def test_model_agent_handles_vaz_and_model_typos() -> None:
    agent = ModelAgent()
    assert agent.check_model("Lada", "ВАЗ-2101").corrected == "2101"
    assert agent.check_model("Lada", "21013").corrected == "21013"
    assert agent.check_model("Toyota", "Камрии").corrected == "Camry"

    check = agent.check_models("Lada", ("2103", "ВАЗ-2102"))
    assert check.make == "Lada"
    assert check.models == ("2103", "2102")


def test_text_agent_corrects_listing_typos_but_not_price() -> None:
    agent = TextAgent()
    result = agent.correct_text(
        "Продам Тайота Камрии 2018, 1 500 000 руб., Екатеринбург"
    )
    assert "Toyota" in result.text
    assert "Camry" in result.text
    assert "1 500 000" in result.text
    assert ("Тайота", "Toyota") in result.changes
    assert ("Камрии", "Camry") in result.changes

    untouched = agent.correct_text("Продам ВАЗ-2101, 55 000 руб.")
    assert untouched.text == "Продам ВАЗ-2101, 55 000 руб."
    assert untouched.changed is False


def test_quality_agent_reports_empty_search() -> None:
    query = SearchQuery(make="Lada", models=("2101",))
    report = SearchQualityAgent().audit(query, [])
    assert report.total == 0
    assert any("0 результатов" in note for note in report.notes)


def test_quality_agent_counts_sources() -> None:
    query = SearchQuery(make="Lada", models=("2101",))
    listing = Listing(
        hash_id="x",
        source=Source.AUTORU,
        title="Lada 2101",
        price=50_000,
        city="Екатеринбург",
        url="https://auto.ru/x",
        make="Lada",
        model="2101",
    )
    report = SearchQualityAgent().audit(query, [listing])
    assert report.total == 1
    assert report.sources == (("AUTORU", 1),)


def test_agent_notes_are_user_facing() -> None:
    from bot.handlers.subscriptions import _make_agent_note, _model_agent_note

    agent = ModelAgent()
    make_note = _make_agent_note(agent.check_make("Тайота"))
    model_note = _model_agent_note(agent.check_models("Toyota", ("Камрии",)))
    assert "Toyota" in make_note
    assert "Camry" in model_note

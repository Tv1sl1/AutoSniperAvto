"""Scraper parser tests (offline fixtures, no network)."""

from __future__ import annotations

import pytest

from config.settings import Settings
from database.models import Source
from scrapers.base import SearchQuery
from scrapers.telegram import _entity_ref
from scrapers.vk import VKScraper
from scrapers.web import (
    AutoRuProvider,
    AvitoProvider,
    DromProvider,
    RssProvider,
    WebScraper,
    parse_targets,
)

DROM_HTML = """
<!doctype html>
<html><body>
<button data-ftid="bulls-list_bull"></button>
<script>
window.__listingData__ = {
  "bullList": {
    "bullsData": [
      {"bulls": [
        {
          "bullId": 569769675,
          "price": 3650000,
          "url": "https://auto.drom.ru/moscow/honda/cr-v/569769675.html",
          "title": "Honda CR-V, 2021",
          "subtitle": "2.4 CVT Executive",
          "date": "3 дня назад",
          "location": "Москва",
          "images": {"items": [
            {"src": "https://s12.auto.drom.ru/photo/1.jpg"},
            {"src2x": "https://s12.auto.drom.ru/photo/2.jpg"}
          ]},
          "attributes": [{"type": "plain", "payload": "2.4 л (186 л.с.)"}]
        }
      ]}
    ]
  }
};
</script>
</body></html>
"""

JSON_LD_HTML = """
<!doctype html>
<html><head>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "BMW 3 Series 2018",
  "url": "/moskva/avtomobili/bmw_3_series_2018_123456",
  "sku": "avito-123456",
  "description": "Продам BMW 3 Series 2018 года, 2 350 000 руб., Москва",
  "image": ["https://cdn.example/photo1.jpg", "https://cdn.example/photo2.jpg"],
  "offers": {"@type": "Offer", "price": "2350000", "priceCurrency": "RUB"},
  "address": {"@type": "PostalAddress", "addressLocality": "Москва"}
}
</script>
</head><body></body></html>
"""

RSS_XML = """<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0">
  <channel>
    <title>Test feed</title>
    <item>
      <title>BMW 3 Series 2018</title>
      <link>https://www.avito.ru/moskva/avtomobili/bmw_123456</link>
      <description>&lt;p&gt;Продам BMW 3 Series, 2 350 000 руб., Москва&lt;/p&gt;</description>
      <pubDate>Mon, 20 Oct 2025 10:00:00 +0300</pubDate>
      <guid>avito-123456</guid>
      <enclosure url="https://cdn.example/photo.jpg" type="image/jpeg"/>
    </item>
    <item>
      <title>Без ссылки</title>
      <description>Игнорируется</description>
    </item>
  </channel>
</rss>
"""


def test_avito_json_ld_parsing() -> None:
    listings = AvitoProvider().parse(JSON_LD_HTML, "https://www.avito.ru/moskva/avtomobili")
    assert len(listings) == 1
    listing = listings[0]
    assert listing.source is Source.AVITO
    assert listing.title == "BMW 3 Series 2018"
    assert listing.price == 2_350_000
    assert listing.city == "Москва"
    assert listing.url.startswith("https://www.avito.ru/moskva/avtomobili/bmw_3_series_2018_123456")
    assert listing.photos == ["https://cdn.example/photo1.jpg", "https://cdn.example/photo2.jpg"]
    assert listing.external_id == "avito-123456"


def test_rss_parsing() -> None:
    listings = RssProvider().parse(RSS_XML, "https://www.avito.ru/rss/feed.xml")
    assert len(listings) == 1
    listing = listings[0]
    assert listing.source is Source.AVITO
    assert listing.title == "BMW 3 Series 2018"
    assert listing.price == 2_350_000
    assert listing.url == "https://www.avito.ru/moskva/avtomobili/bmw_123456"
    assert listing.published_at is not None
    assert "photo.jpg" in listing.photos[0]


def test_drom_embedded_state_parsing() -> None:
    listings = DromProvider().parse(DROM_HTML, "https://auto.drom.ru/moscow/")
    assert len(listings) == 1
    listing = listings[0]
    assert listing.source is Source.DROM
    assert listing.external_id == "569769675"
    assert listing.title == "Honda CR-V, 2021"
    assert listing.price == 3_650_000
    assert listing.city == "Москва"
    assert listing.photos == [
        "https://s12.auto.drom.ru/photo/1.jpg",
        "https://s12.auto.drom.ru/photo/2.jpg",
    ]
    assert listing.published_at is not None
    assert "2.4 CVT Executive" in listing.raw_text
    assert "186" in listing.raw_text


def test_rss_provider_has_no_search() -> None:
    assert RssProvider().supports_search is False


def test_auto_ru_captcha_is_reported() -> None:
    with pytest.raises(Exception, match="CAPTCHA"):
        AutoRuProvider().parse(
            '<html><head><title>Auto.ru</title></head><body>showcaptcha</body></html>',
            "https://auto.ru/moskva/cars/used/",
        )


def test_parse_targets() -> None:
    targets = parse_targets(
        [
            "avito:https://www.avito.ru/moskva/avtomobili",
            "auto.ru:https://auto.ru/cars/used/sale/bmw/3er/moskva/",
            "drom:https://auto.drom.ru/moscow/",
            "rss:https://example.com/feed.xml",
            "broken-entry",
            "unknown:https://example.com",
        ]
    )
    assert [target.provider for target in targets] == ["avito", "auto_ru", "drom", "rss"]


def test_web_scraper_uses_query_parameters() -> None:
    settings = Settings(web_targets=("avito:https://www.avito.ru/moskva/avtomobili",))
    scraper = WebScraper(settings)
    urls = scraper.targets
    assert len(urls) == 1
    provider = AvitoProvider()
    built = provider.build_urls(urls[0].url, [SearchQuery(make="BMW", model="3 Series")])
    assert "q=BMW+3+Series" in built[0]


def test_search_query_expands_multiple_models() -> None:
    query = SearchQuery(make="BMW", models=("3 Series", "X5"))
    expanded = query.expand()
    assert [item.label() for item in expanded] == ["BMW 3 Series", "BMW X5"]
    assert all(len(item.models) == 1 for item in expanded)


def test_search_label_excludes_city_and_uses_vaz_alias() -> None:
    query = SearchQuery(make="Lada", models=("2101",), city="Екатеринбург")
    assert query.search_label() == "ВАЗ 2101"
    assert query.label() == "ВАЗ 2101 Екатеринбург"


def test_vaz_model_urls_for_auto_ru_and_drom() -> None:
    query = SearchQuery(make="Lada", models=("2101",), city="Екатеринбург")
    auto_urls = AutoRuProvider().build_urls(
        "https://auto.ru/moskva/cars/used/?sort=fresh_relevance_1-desc",
        query.expand(),
    )
    drom_urls = DromProvider().build_urls(
        "https://auto.drom.ru/moscow/",
        query.expand(),
    )
    assert auto_urls == [
        "https://auto.ru/ekaterinburg/cars/vaz/2101/used/?sort=fresh_relevance_1-desc"
    ]
    assert drom_urls == ["https://auto.drom.ru/ekaterinburg/lada/2101/"]


def test_auto_ru_builds_brand_url() -> None:
    provider = AutoRuProvider()
    urls = provider.build_urls(
        "https://auto.ru/moskva/cars/used/?sort=fresh_relevance_1-desc",
        [SearchQuery(make="BMW", models=("3 Series", "X5"))],
    )
    assert urls == ["https://auto.ru/moskva/cars/bmw/used/?sort=fresh_relevance_1-desc"]


def test_drom_builds_brand_url() -> None:
    provider = DromProvider()
    urls = provider.build_urls(
        "https://auto.drom.ru/moscow/",
        [SearchQuery(make="Mercedes-Benz", model="E-Class")],
    )
    assert urls == ["https://auto.drom.ru/moscow/mercedes-benz/"]


def test_vk_review_post_is_skipped() -> None:
    scraper = VKScraper(Settings())
    item = {
        "id": 11,
        "owner_id": -123,
        "text": "ВАЗ 2103 на стиле за 20 тысяч рублей. Екатеринбург. Обзор 🚘.mp4",
        "date": 1_700_000_000,
        "attachments": [],
    }
    assert scraper._to_raw_listing(item) is None

    sale = {
        "id": 12,
        "owner_id": -123,
        "text": "Продам ВАЗ 2103, 1979, 55 000 руб., Екатеринбург. Обзор по запросу.",
        "date": 1_700_000_000,
        "attachments": [],
    }
    listing = scraper._to_raw_listing(sale)
    assert listing is not None
    assert listing.price is None


def test_vk_post_mapping() -> None:
    scraper = VKScraper(Settings())
    item = {
        "id": 10,
        "owner_id": -123,
        "text": "Продам BMW X5 2019, 3 500 000 руб., Москва",
        "date": 1_700_000_000,
        "attachments": [
            {
                "type": "photo",
                "photo": {
                    "sizes": [
                        {"url": "https://cdn.example/small.jpg", "width": 100, "height": 100},
                        {"url": "https://cdn.example/big.jpg", "width": 1200, "height": 900},
                    ]
                },
            }
        ],
        "geo": {"place": {"title": "Москва"}},
    }
    listing = scraper._to_raw_listing(item)
    assert listing is not None
    assert listing.url == "https://vk.com/wall-123_10"
    assert listing.external_id == "-123_10"
    assert listing.city == "Москва"
    assert listing.photos == ["https://cdn.example/big.jpg"]


def test_vk_skips_empty_posts() -> None:
    scraper = VKScraper(Settings())
    assert scraper._to_raw_listing({"id": 1, "owner_id": -1, "text": ""}) is None


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("@auto_sale_msk", "auto_sale_msk"),
        ("auto_sale_msk", "auto_sale_msk"),
        ("https://t.me/auto_sale_msk", "auto_sale_msk"),
        ("t.me/auto_sale_msk?x=1", "auto_sale_msk"),
        ("-1001234567890", -1001234567890),
    ],
)
def test_telegram_entity_ref(raw: str, expected: object) -> None:
    assert _entity_ref(raw) == expected

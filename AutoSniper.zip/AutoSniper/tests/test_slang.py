"""Slang/typo normalization and subscription-to-listing matching."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from database.models import Source, Subscription
from scrapers.base import RawListing, SearchQuery, filter_by_queries
from services.agents import ModelAgent
from services.matching import SubscriptionMatcher
from services.normalizer import normalize_raw
from services.parser_engine import parse_listing


@pytest.mark.parametrize(
    ("text", "make", "model", "year"),
    [
        ("Продам 7 ку 2007 год", "Lada", "2107", 2007),
        ("Продам семёрка 2008", "Lada", "2107", 2008),
        ("солярис 2018", "Hyundai", "Solaris", 2018),
        ("буханка 2012", "UAZ", "Bukhanka", 2012),
        ("camry 40 2007", "Toyota", "Camry 40", 2007),
        ("BMW семерка 2015", "BMW", "7 Series", 2015),
    ],
)
def test_slang_listing_is_parsed(text: str, make: str, model: str, year: int) -> None:
    parsed = parse_listing(text)
    assert (parsed.make, parsed.model, parsed.year) == (make, model, year)


def test_slang_extracts_generation_transmission_and_volume() -> None:
    parsed = parse_listing("марк в 90 кузове, 2.5, акпп")
    assert (parsed.make, parsed.model, parsed.generation) == ("Toyota", "Mark II 90", "90")
    assert parsed.transmission == "АКПП"
    assert parsed.engine_volume == 2.5

    focus = parse_listing("мкпп, фокус 2 рест 2008")
    assert focus.make == "Ford"
    assert focus.model == "Focus 2 Restyling"
    assert focus.transmission == "МКПП"


@pytest.mark.parametrize(
    ("make", "raw", "expected"),
    [
        ("Lada", "семёрка", "2107"),
        ("Lada", "четырка", "2104"),
        ("Toyota", "марковник", "Mark II"),
        ("Hyundai", "солярис", "Solaris"),
        ("Ford", "фокус 2 рест", "Focus 2 Restyling"),
        ("Toyota", "camry 40", "Camry 40"),
        ("UAZ", "буханка", "Bukhanka"),
        ("BMW", "тришка", "3 Series"),
    ],
)
def test_slang_subscription_is_normalized(make: str, raw: str, expected: str) -> None:
    assert ModelAgent().check_model(make, raw).corrected == expected


def test_price_with_redundant_thousands_word() -> None:
    parsed = parse_listing("Ваз 2107 2006 года\nЦена срочная 50.000 тысяч\n+79057956167")
    assert parsed.make == "Lada"
    assert parsed.model == "2107"
    assert parsed.year == 2006
    assert parsed.price == 50_000


def test_slang_filter_matches_vk_style_text() -> None:
    query = SearchQuery(make="Lada", models=("2107",))
    assert filter_by_queries("Продам семёрку 2008, 55 000 руб.", [query]) is True
    assert filter_by_queries("Продам семерку на удачу", [query]) is False
    assert filter_by_queries("Продам BMW X5", [query]) is False


def test_slang_listing_matches_subscription() -> None:
    raw = RawListing(
        source=Source.VK,
        url="https://vk.com/wall-1_1",
        title="Продам 7 ку 2007 год",
        raw_text="Продам 7 ку 2007 год, 55 000 руб., Екатеринбург",
        external_id="1_1",
        published_at=datetime.now(UTC),
    )
    listing = normalize_raw(raw).listing
    assert (listing.make, listing.model, listing.year) == ("Lada", "2107", 2007)
    subscription = Subscription(
        make="Lada",
        model="2107",
        models=["2107"],
        max_price=60_000,
        city="Екатеринбург",
        max_distance_km=200,
        max_age_days=7,
    )
    assert SubscriptionMatcher().match(listing, subscription).matched

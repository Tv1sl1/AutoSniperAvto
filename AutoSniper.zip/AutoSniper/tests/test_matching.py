"""Matching policy tests."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

from database.models import Subscription
from services.matching import MatchPolicy, SubscriptionMatcher


def make_subscription(**overrides) -> Subscription:
    values = {
        "user_id": 1,
        "make": "BMW",
        "model": "3 Series",
        "models": ["3 Series"],
        "max_price": 2_500_000,
        "city": "Москва",
        "max_distance_km": None,
        "max_age_days": None,
        "year_min": 2015,
    }
    values.update(overrides)
    return Subscription(**values)


def make_listing(**overrides) -> SimpleNamespace:
    values = {
        "make": "BMW",
        "model": "3 Series",
        "price": 2_350_000,
        "city": "Москва",
        "year": 2018,
        "published_at": None,
    }
    values.update(overrides)
    return SimpleNamespace(**values)


def test_full_match() -> None:
    matcher = SubscriptionMatcher()
    result = matcher.match(make_listing(), make_subscription())
    assert result.matched is True
    assert result.reasons == ("ok",)


def test_make_mismatch() -> None:
    result = SubscriptionMatcher().match(make_listing(make="Audi"), make_subscription())
    assert result.matched is False
    assert any(reason.startswith("make_mismatch") for reason in result.reasons)


def test_model_fuzzy() -> None:
    matcher = SubscriptionMatcher()
    assert matcher.match(make_listing(model="320i"), make_subscription()).matched is True
    assert matcher.match(make_listing(model="X5"), make_subscription()).matched is False


def test_price_above_limit() -> None:
    result = SubscriptionMatcher().match(make_listing(price=3_000_000), make_subscription())
    assert result.matched is False
    assert any(reason.startswith("price_too_high") for reason in result.reasons)


def test_unknown_price_policy() -> None:
    strict = SubscriptionMatcher(MatchPolicy(require_known_price=True))
    lenient = SubscriptionMatcher(MatchPolicy(require_known_price=False))
    listing = make_listing(price=None)
    assert strict.match(listing, make_subscription()).matched is False
    assert lenient.match(listing, make_subscription()).matched is True


def test_unknown_city_policy() -> None:
    listing = make_listing(city=None)
    assert SubscriptionMatcher(MatchPolicy(require_known_city=False)).match(
        listing, make_subscription()
    ).matched is True
    assert SubscriptionMatcher(MatchPolicy(require_known_city=True)).match(
        listing, make_subscription()
    ).matched is False


def test_city_region_and_mismatch() -> None:
    matcher = SubscriptionMatcher()
    assert matcher.match(make_listing(city="Подольск"), make_subscription()).matched is True
    assert matcher.match(make_listing(city="Казань"), make_subscription()).matched is False


def test_year_filter() -> None:
    matcher = SubscriptionMatcher()
    assert matcher.match(make_listing(year=2014), make_subscription()).matched is False
    assert matcher.match(make_listing(year=None), make_subscription()).matched is False


def test_any_model_and_any_city() -> None:
    subscription = make_subscription(model=None, models=[], city=None, max_price=None, year_min=None)
    listing = make_listing(model="X5", city="Сочи", price=None)
    assert SubscriptionMatcher().match(listing, subscription).matched is True


def test_match_all_returns_only_matching() -> None:
    subscriptions = [
        make_subscription(id=1),
        make_subscription(id=2, make="Audi"),
        make_subscription(
            id=3, model=None, models=[], city=None, max_price=None, year_min=None
        ),
    ]
    matched = SubscriptionMatcher().match_all(make_listing(), subscriptions)
    assert [sub.id for sub, _ in matched] == [1, 3]


def test_multiple_models_match_any() -> None:
    subscription = make_subscription(models=["3 Series", "X5"], model="3 Series")
    matcher = SubscriptionMatcher()
    assert matcher.match(make_listing(model="X5"), subscription).matched is True
    assert matcher.match(make_listing(model="320i"), subscription).matched is True
    assert matcher.match(make_listing(model="Camry"), subscription).matched is False


def test_distance_filter() -> None:
    matcher = SubscriptionMatcher()
    nearby = make_subscription(max_distance_km=100)
    assert matcher.match(make_listing(city="Подольск"), nearby).matched is True
    far = matcher.match(make_listing(city="Санкт-Петербург"), nearby)
    assert far.matched is False
    assert any(reason.startswith("distance_too_far") for reason in far.reasons)

    same_city = make_subscription(max_distance_km=0)
    assert matcher.match(make_listing(city="Москва"), same_city).matched is True
    assert matcher.match(make_listing(city="Подольск"), same_city).matched is False


def test_distance_unknown_city() -> None:
    result = SubscriptionMatcher().match(
        make_listing(city=None),
        make_subscription(max_distance_km=100),
    )
    assert result.matched is False
    assert "city_unknown_for_distance" in result.reasons


def test_publication_age_filter() -> None:
    now = datetime(2026, 10, 25, tzinfo=UTC)
    matcher = SubscriptionMatcher()
    fresh = make_subscription(max_age_days=7)

    assert matcher.match(
        make_listing(published_at=now - timedelta(days=2)), fresh, now=now
    ).matched is True
    stale = matcher.match(
        make_listing(published_at=now - timedelta(days=10)), fresh, now=now
    )
    assert stale.matched is False
    assert any(reason.startswith("too_old") for reason in stale.reasons)
    assert matcher.match(make_listing(published_at=None), fresh, now=now).matched is False

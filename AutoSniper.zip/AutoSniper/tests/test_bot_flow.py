"""Full bot wizard test with a fake Telegram session (no network)."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.base import BaseSession
from aiogram.enums import ParseMode
from aiogram.types import CallbackQuery, Chat, Message, Update
from aiogram.types import User as TgUser

import bot.app as bot_app
from bot.app import create_dispatcher
from bot.callbacks import AddSubCB, SubCB
from bot.middlewares import ThrottlingMiddleware
from config.settings import Settings
from database.repositories import SubscriptionRepository, UserRepository
from database.session import Database
from services.orchestrator import ScraperOrchestrator
from services.pipeline import IngestionPipeline

BOT_USER = TgUser(id=1, is_bot=True, first_name="Bot", username="test_bot")
HUMAN = TgUser(id=42, is_bot=False, first_name="Tester", username="tester")
CHAT = Chat(id=42, type="private")
NOW = datetime.now(UTC)


class FakeSession(BaseSession):
    """Records method names and returns a truthy stub for every Bot API call."""

    def __init__(self) -> None:
        super().__init__()
        self.calls: list[str] = []

    async def close(self) -> None:
        return None

    async def make_request(self, bot, method, timeout=None):
        self.calls.append(type(method).__name__)
        return True

    async def stream_content(self, *args, **kwargs):
        yield b""


def _message(message_id: int, text: str = "message") -> Message:
    return Message(message_id=message_id, date=NOW, chat=CHAT, from_user=BOT_USER, text=text)


def _callback(update_id: int, data: str, message_id: int) -> Update:
    return Update(
        update_id=update_id,
        callback_query=CallbackQuery(
            id=f"cb{update_id}",
            from_user=HUMAN,
            chat_instance="chat-instance",
            message=_message(message_id),
            data=data,
        ),
    )


def _text(update_id: int, message_id: int, text: str) -> Update:
    return Update(
        update_id=update_id,
        message=Message(
            message_id=message_id, date=NOW, chat=CHAT, from_user=HUMAN, text=text
        ),
    )


async def test_subscription_wizard_and_management(db: Database, monkeypatch) -> None:
    # The production dispatcher throttles at 0.4s; disable it for a fast test.
    def no_throttle(**_kwargs) -> ThrottlingMiddleware:
        return ThrottlingMiddleware(min_interval=0.0, burst=1000)

    monkeypatch.setattr(bot_app, "ThrottlingMiddleware", no_throttle)

    settings = Settings(bot_token="42:" + "A" * 35)
    bot = Bot(
        token=settings.bot_token,
        session=FakeSession(),
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    pipeline = IngestionPipeline(db, settings=settings)
    orchestrator = ScraperOrchestrator(db=db, pipeline=pipeline, scrapers=[], settings=settings)
    dispatcher = create_dispatcher(
        db=db, settings=settings, orchestrator=orchestrator, notifier=None
    )

    try:
        await dispatcher.feed_update(bot, _text(1, 1, "/start"))
        await dispatcher.feed_update(bot, _callback(2, "menu:add", 2))
        await dispatcher.feed_update(
            bot, _callback(3, AddSubCB(action="brand", value="BMW").pack(), 3)
        )
        await dispatcher.feed_update(
            bot, _text(4, 4, "3 series, X5, X3, X1, X6, 5 series, 7 series, M3, M5, i4")
        )
        await dispatcher.feed_update(
            bot, _callback(5, AddSubCB(action="city", value="Москва").pack(), 5)
        )
        await dispatcher.feed_update(
            bot, _callback(6, AddSubCB(action="distance", value="100").pack(), 6)
        )
        await dispatcher.feed_update(bot, _text(7, 7, "2 500 000"))
        await dispatcher.feed_update(bot, _callback(8, AddSubCB(action="confirm").pack(), 8))
        await asyncio.sleep(0)

        async with db.session() as session:
            user = await UserRepository(session).get(42)
            subscriptions = await SubscriptionRepository(session).list_for_user(42)
            assert user is not None and user.is_active
            assert len(subscriptions) == 1
            subscription = subscriptions[0]
            assert (subscription.make, subscription.model) == ("BMW", "3 Series")
            assert subscription.models == [
                "3 Series",
                "X5",
                "X3",
                "X1",
                "X6",
                "5 Series",
                "7 Series",
                "M3",
                "M5",
                "I4",
            ]
            assert len(subscription.models) == 10
            assert subscription.city == "Москва"
            assert subscription.max_price == 2_500_000
            assert subscription.max_distance_km == 100
            assert subscription.max_age_days == 7
            subscription_id = subscription.id

        assert any(call == "SendMessage" for call in bot.session.calls)
        assert any(call == "AnswerCallbackQuery" for call in bot.session.calls)

        # Pause the subscription via the inline keyboard.
        await dispatcher.feed_update(
            bot,
            _callback(9, SubCB(action="toggle", sub_id=subscription_id, page=0).pack(), 9),
        )
        async with db.session() as session:
            paused = await SubscriptionRepository(session).get(subscription_id)
            assert paused is not None and paused.is_active is False

        # Delete it: first confirmation, then confirm callback.
        await dispatcher.feed_update(
            bot,
            _callback(10, SubCB(action="delete", sub_id=subscription_id, page=0).pack(), 10),
        )
        await dispatcher.feed_update(
            bot,
            _callback(
                11, SubCB(action="confirm_delete", sub_id=subscription_id, page=0).pack(), 10
            ),
        )
        async with db.session() as session:
            assert await SubscriptionRepository(session).count_for_user(42) == 0
    finally:
        await orchestrator.close()
        await bot.session.close()

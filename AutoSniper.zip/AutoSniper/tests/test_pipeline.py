"""End-to-end ingestion pipeline tests (no network, in-memory SQLite)."""

from __future__ import annotations

from sqlalchemy import func, select

from config.settings import Settings
from database.models import Listing, Notification, Source
from database.repositories import (
    NotificationRepository,
    SubscriptionRepository,
    UserRepository,
)
from database.session import Database
from scrapers.base import RawListing
from services.pipeline import DeliveryOutcome, DeliveryResult, IngestionPipeline

RAW_TEXT = (
    "Продам BMW 3 Series 2018 года, пробег 80 000 км, 2 350 000 руб., Москва. "
    "Идеальное состояние, один владелец."
)


class FakeNotifier:
    def __init__(self, outcome: DeliveryOutcome = DeliveryOutcome.SENT) -> None:
        self.outcome = outcome
        self.calls: list[tuple[int, int, int | None]] = []

    async def send_match(self, user_id, listing, subscription=None) -> DeliveryResult:
        self.calls.append((user_id, listing.id, subscription.id if subscription else None))
        return DeliveryResult(self.outcome, None if self.outcome is DeliveryOutcome.SENT else "test")


def make_raw(url: str = "https://t.me/auto_sale_msk/101", external_id: str = "1:101") -> RawListing:
    return RawListing(
        source=Source.TG,
        url=url,
        title="BMW 3 Series 2018",
        raw_text=RAW_TEXT,
        external_id=external_id,
        published_at=None,
    )


async def _seed(db: Database, subscriptions: int = 1, *, warm: bool = True) -> None:
    async with db.session() as session:
        await UserRepository(session).get_or_create(42, username="tester", first_name="Test")
        repo = SubscriptionRepository(session)
        created = [
            await repo.create(
                user_id=42,
                make="BMW",
                model="3 series",
                max_price=2_500_000,
                city="Москва",
            )
        ]
        for _ in range(subscriptions - 1):
            created.append(
                await repo.create(
                    user_id=42,
                    make="BMW",
                    model=None,
                    max_price=3_000_000,
                    city=None,
                )
            )
        if warm:
            for subscription in created:
                subscription.cold_start_done = True


async def test_cold_start_skips_first_cycle_then_notifies(db: Database) -> None:
    await _seed(db, warm=False)
    notifier = FakeNotifier()
    pipeline = IngestionPipeline(db, settings=Settings(), notifier=notifier)

    first = await pipeline.ingest([make_raw()])
    assert first.notifications == 0
    assert notifier.calls == []
    async with db.session() as session:
        subscription = await SubscriptionRepository(session).list_for_user(42)
        assert subscription[0].cold_start_done is True
        assert int(await session.scalar(select(func.count()).select_from(Notification)) or 0) == 0

    second = await pipeline.ingest(
        [make_raw(url="https://t.me/auto_sale_msk/102", external_id="1:102")]
    )
    assert second.notifications == 1
    assert len(notifier.calls) == 1


async def test_ingest_creates_listing_and_notifies_once(db: Database) -> None:
    await _seed(db)
    notifier = FakeNotifier()
    pipeline = IngestionPipeline(db, settings=Settings(), notifier=notifier)

    stats = await pipeline.ingest([make_raw()])
    assert stats.received == 1
    assert stats.created == 1
    assert stats.notifications == 1
    assert stats.delivered == 1
    assert len(notifier.calls) == 1

    async with db.session() as session:
        listing = await session.scalar(select(Listing))
        assert listing is not None
        assert listing.make == "BMW"
        assert listing.model == "3 Series"
        assert listing.price == 2_350_000
        assert listing.city == "Москва"
        assert listing.year == 2018
        assert listing.external_id == "1:101"

        notification = await session.scalar(select(Notification))
        assert notification is not None
        assert notification.sent_at is not None

    # Same post again -> no new row, no second alert.
    stats_again = await pipeline.ingest([make_raw()])
    assert stats_again.created == 0
    assert stats_again.notifications == 0
    assert len(notifier.calls) == 1

    async with db.session() as session:
        assert int(await session.scalar(select(func.count()).select_from(Listing)) or 0) == 1
        assert int(await session.scalar(select(func.count()).select_from(Notification)) or 0) == 1


async def test_one_notification_per_user_even_with_two_matching_filters(db: Database) -> None:
    await _seed(db, subscriptions=2)
    notifier = FakeNotifier()
    pipeline = IngestionPipeline(db, settings=Settings(), notifier=notifier)

    stats = await pipeline.ingest([make_raw()])
    assert stats.created == 1
    assert stats.matched == 2
    assert stats.notifications == 1
    assert len(notifier.calls) == 1


async def test_blocked_user_is_deactivated(db: Database) -> None:
    await _seed(db)
    notifier = FakeNotifier(DeliveryOutcome.BLOCKED)
    pipeline = IngestionPipeline(db, settings=Settings(), notifier=notifier)

    stats = await pipeline.ingest([make_raw()])
    assert stats.blocked == 1

    async with db.session() as session:
        user = await UserRepository(session).get(42)
        assert user is not None
        assert user.is_active is False


async def test_unmatched_listing_is_stored_but_not_notified(db: Database) -> None:
    await _seed(db)
    notifier = FakeNotifier()
    pipeline = IngestionPipeline(db, settings=Settings(), notifier=notifier)

    raw = make_raw(url="https://t.me/auto_sale_msk/999", external_id="1:999")
    raw.raw_text = "Продам Audi A6 2019, 3 100 000 руб., Казань"
    raw.title = "Audi A6 2019"
    stats = await pipeline.ingest([raw])
    assert stats.created == 1
    assert stats.notifications == 0
    assert notifier.calls == []


async def test_pending_notifications_are_retried(db: Database) -> None:
    await _seed(db)
    failing = FakeNotifier(DeliveryOutcome.FAILED)
    pipeline = IngestionPipeline(db, settings=Settings(), notifier=failing)
    await pipeline.ingest([make_raw()])

    async with db.session() as session:
        assert await NotificationRepository(session).count_pending() == 1

    pipeline.notifier = FakeNotifier(DeliveryOutcome.SENT)
    stats = await pipeline.retry_pending()
    assert stats.delivered == 1
    async with db.session() as session:
        assert await NotificationRepository(session).count_pending() == 0

"""Parser engine tests: prices, cities, brands, models, years."""

from __future__ import annotations

import pytest

from services.parser_engine import (
    city_matches,
    detect_city,
    detect_make,
    models_match,
    normalize_city,
    normalize_make,
    normalize_model,
    parse_listing,
    parse_price,
    parse_year,
)


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("Продам BMW 3 Series, 2018 год, 2 350 000 руб., Москва", 2_350_000),
        ("Цена: 1 200 000 ₽", 1_200_000),
        ("BMW X5 2019, цена 1.2 млн, торг", 1_200_000),
        ("срочно 1200k", 1_200_000),
        ("1,2 млн рублей", 1_200_000),
        ("2.350.000 руб", 2_350_000),
        ("1,250,000", 1_250_000),
        ("Пробег 120 000 км, цена 900 000 ₽", 900_000),
        ("За 120 тыс. руб.", 120_000),
        ("отдам за 450000", 450_000),
    ],
)
def test_parse_price(text: str, expected: int) -> None:
    assert parse_price(text) == expected


@pytest.mark.parametrize(
    "text",
    [
        "Пробег 120 000 км",
        "2018 год, 2 владельца",
        "телефон 8 900 123 45 67",
        "расход 8.5 л на 100 км",
        "нет цены, звоните",
    ],
)
def test_parse_price_ignores_non_prices(text: str) -> None:
    assert parse_price(text) is None


def test_parse_year() -> None:
    assert parse_year("BMW 3 Series, 2018 год") == 2018
    assert parse_year("купил в 2015, продаю сейчас") == 2015
    assert parse_year("пробег 120 000 км") is None


def test_city_detection() -> None:
    assert detect_city("Продам BMW, Москва, торг") == "Москва"
    assert detect_city("срочно, СПб") == "Санкт-Петербург"
    assert detect_city("в Питере, самовывоз") == "Санкт-Петербург"
    assert detect_city("город: Казань") == "Казань"
    assert detect_city("что-то непонятное") is None


def test_city_normalization_and_matching() -> None:
    assert normalize_city("мск") == "Москва"
    assert normalize_city("Санкт-Петербург") == "Санкт-Петербург"
    assert city_matches("Москва", "Подольск") is True  # same region
    assert city_matches("Москва", "Казань") is False


def test_make_detection() -> None:
    assert detect_make("продам бмв X5") == "BMW"
    assert detect_make("Продам Ладу Весту") == "Lada"
    assert detect_make("мерседес е-класс") == "Mercedes-Benz"
    assert normalize_make("бмв") == "BMW"
    assert normalize_make("Audi") == "Audi"


def test_model_normalization() -> None:
    assert normalize_model("x5") == "X5"
    assert normalize_model("3 series") == "3 Series"
    assert normalize_model("камри") == "Camry"


def test_models_match() -> None:
    assert models_match("3 Series", "320i") is True
    assert models_match("3 series", "3 Series xDrive") is True
    assert models_match("X5", "X5 M") is True
    assert models_match("Camry", "Камри") is True
    assert models_match("X5", "X6") is False


def test_parse_listing_full() -> None:
    parsed = parse_listing(
        "Продам BMW 3 Series 2018 года, пробег 80 000 км, 2 350 000 руб., Москва. "
        "Идеальное состояние, один владелец."
    )
    assert parsed.make == "BMW"
    assert parsed.model == "3 Series"
    assert parsed.price == 2_350_000
    assert parsed.city == "Москва"
    assert parsed.year == 2018
    assert parsed.confidence >= 0.8


def test_parse_hyphenated_vaz_model() -> None:
    parsed = parse_listing(
        "Продам ВАЗ-2101, 1974 год, 55 000 руб., Екатеринбург. На ходу."
    )
    assert parsed.make == "Lada"
    assert parsed.model == "2101"
    assert parsed.price == 55_000
    assert parsed.city == "Екатеринбург"
    assert parsed.year == 1974


def test_normalize_raw_prefers_structured_price() -> None:
    from database.models import Source
    from scrapers.base import RawListing
    from services.normalizer import normalize_raw

    raw = RawListing(
        source=Source.DROM,
        url="https://auto.drom.ru/ekaterinburg/lada/2101/1.html",
        title="Лада 2101, 1984",
        raw_text="Лада 2101, 1984\n1.2 MT 21013\n1.2 л (59 л.с.)",
        external_id="1",
        price=120_000,
        city="Екатеринбург",
    )
    listing = normalize_raw(raw).listing
    assert listing.model == "2101"
    assert listing.price == 120_000


def test_parse_listing_defaults_win_when_text_is_poor() -> None:
    parsed = parse_listing(
        "продам машину",
        default_city="Сочи",
        default_price=1_500_000,
        default_year=2017,
    )
    assert parsed.city == "Сочи"
    assert parsed.price == 1_500_000
    assert parsed.year == 2017

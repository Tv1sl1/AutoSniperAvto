"""Bot UI unit tests that do not require Telegram connectivity."""

from __future__ import annotations

from bot.callbacks import AddSubCB, MenuCB, SearchCB, SubCB
from bot.keyboards import main_menu_kb, search_period_kb, search_subs_kb, subscriptions_kb
from database.models import Listing, Source, Subscription
from services.formatting import format_subscription_line
from services.notifier import TelegramNotifier, source_label


def make_listing(**overrides) -> Listing:
    values = {
        "hash_id": "a" * 64,
        "source": Source.TG,
        "title": "BMW 3 Series 2018",
        "price": 2_350_000,
        "city": "Москва",
        "url": "https://t.me/auto_sale_msk/101",
        "photos": [],
        "raw_text": "Продам BMW 3 Series 2018 года, пробег 80 000 км, идеальное состояние.",
        "make": "BMW",
        "model": "3 Series",
        "year": 2018,
    }
    values.update(overrides)
    return Listing(**values)


def test_main_menu_has_all_required_buttons() -> None:
    keyboard = main_menu_kb()
    texts = [button.text for row in keyboard.inline_keyboard for button in row]
    assert "➕ Добавить подписку" in texts
    assert "📋 Мои подписки" in texts
    assert "⚙️ Настройки" in texts
    assert "🔍 Разовый поиск сейчас" in texts
    assert "❓ Помощь / Статус" in texts


def test_callback_data_fits_telegram_limit() -> None:
    payloads = [
        MenuCB(action="search").pack(),
        AddSubCB(action="brand", value="Mercedes-Benz").pack(),
        AddSubCB(action="city", value="Санкт-Петербург").pack(),
        SubCB(action="confirm_delete", sub_id=123, page=2).pack(),
        SearchCB(action="run", sub_id=123).pack(),
    ]
    for payload in payloads:
        assert len(payload.encode("utf-8")) <= 64


def test_subscription_buttons_are_numbered() -> None:
    subscriptions = [
        Subscription(id=1, user_id=42, make="BMW", model="3 Series", is_active=True),
        Subscription(id=2, user_id=42, make="Audi", model="A4", is_active=False),
    ]
    keyboard = subscriptions_kb(subscriptions, page=0, pages=1)
    texts = [button.text for row in keyboard.inline_keyboard for button in row]
    assert any(text.startswith("1.") for text in texts)
    assert any(text.startswith("2.") for text in texts)


def test_search_keyboard_lists_subscriptions() -> None:
    subscriptions = [Subscription(id=7, user_id=42, make="Kia", model="Rio", city="Москва")]
    keyboard = search_subs_kb(subscriptions)
    payloads = [button.callback_data for row in keyboard.inline_keyboard for button in row]
    assert any(payload and payload.startswith("search:") for payload in payloads)


def test_search_period_keyboard_has_month_and_week() -> None:
    keyboard = search_period_kb(7)
    payloads = [button.callback_data for row in keyboard.inline_keyboard for button in row]
    assert SearchCB(action="period", sub_id=7, days=30).pack() in payloads
    assert SearchCB(action="period", sub_id=7, days=7).pack() in payloads


def test_subscription_line_shows_models_and_distance() -> None:
    subscription = Subscription(
        id=1,
        user_id=42,
        make="BMW",
        model="3 Series",
        models=["3 Series", "X5"],
        city="Москва",
        max_distance_km=100,
        max_price=2_500_000,
    )
    line = format_subscription_line(subscription)
    assert "3 Series, X5" in line
    assert "до 100 км" in line


def test_caption_contains_all_fields() -> None:
    notifier = TelegramNotifier(bot=None)  # type: ignore[arg-type]
    caption = notifier.build_caption(make_listing())
    assert "НАЙДЕН АВТОМОБИЛЬ" in caption
    assert "BMW 3 Series" in caption
    assert "2 350 000 ₽" in caption
    assert "Москва" in caption
    assert "Telegram (@auto_sale_msk)" in caption
    assert 'href="https://t.me/auto_sale_msk/101"' in caption
    assert len(caption) <= 1024


def test_caption_is_html_escaped_and_truncated() -> None:
    notifier = TelegramNotifier(bot=None)  # type: ignore[arg-type]
    listing = make_listing(
        title="<script>alert('xss')</script>",
        make=None,
        model=None,
        raw_text="Очень длинное описание " * 500,
    )
    caption = notifier.build_caption(listing)
    assert "&lt;script&gt;" in caption
    assert "<script>" not in caption
    assert len(caption) <= 1024


def test_source_labels() -> None:
    assert source_label(make_listing(source=Source.VK, url="https://vk.com/wall-1_2")) == "VKontakte"
    assert source_label(make_listing(source=Source.AVITO, url="https://avito.ru/x")) == "Avito"
    assert source_label(make_listing(source=Source.AUTORU, url="https://auto.ru/x")) == "Auto.ru"
    assert source_label(make_listing(source=Source.DROM, url="https://auto.drom.ru/x")) == "Drom.ru"
    assert source_label(make_listing(source=Source.RSS, url="https://example.com/feed")) == "RSS"
    assert source_label(make_listing(source=Source.TG, url="https://t.me/c/123/1")) == "Telegram"

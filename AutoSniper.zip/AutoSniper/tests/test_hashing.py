"""Deduplication hash tests."""

from __future__ import annotations

from services.hashing import compute_hash_id, normalize_title, normalize_url


def test_hash_stable_for_same_listing() -> None:
    first = compute_hash_id("BMW 3 Series 2018", 2_350_000, "https://t.me/auto/1")
    second = compute_hash_id("  bmw   3 series 2018 ", 2_350_000, "https://t.me/auto/1")
    assert first == second
    assert len(first) == 64


def test_hash_changes_with_price_and_url() -> None:
    base = compute_hash_id("BMW X5", 2_000_000, "https://t.me/auto/1")
    assert base != compute_hash_id("BMW X5", 2_100_000, "https://t.me/auto/1")
    assert base != compute_hash_id("BMW X5", 2_000_000, "https://t.me/auto/2")


def test_url_tracking_parameters_are_ignored() -> None:
    clean = normalize_url("https://www.avito.ru/moskva/avtomobili/bmw_123")
    dirty = normalize_url(
        "https://www.avito.ru/moskva/avtomobili/bmw_123?utm_source=telegram&utm_medium=cpc"
    )
    assert clean == dirty
    assert compute_hash_id("BMW", 1_000_000, "https://a.ru/x?utm_source=tg") == compute_hash_id(
        "BMW", 1_000_000, "https://a.ru/x"
    )


def test_title_normalization() -> None:
    assert normalize_title("  BMW 3-Series, 2018!!!  ") == "bmw 3 series 2018"

"""Scraper package.

Scraper modules are imported lazily (Telethon/Playwright are heavy and optional),
so importing :mod:`scrapers` stays cheap.
"""

from scrapers.base import BaseScraper, RawListing, ScrapeBatch, SearchQuery

__all__ = ["BaseScraper", "RawListing", "ScrapeBatch", "SearchQuery", "build_scrapers"]


def build_scrapers(settings):  # type: ignore[no-untyped-def]
    from scrapers.registry import build_scrapers as _build

    return _build(settings)

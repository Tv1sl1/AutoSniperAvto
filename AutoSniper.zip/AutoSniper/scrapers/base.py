"""Base contracts shared by every scraper."""

from __future__ import annotations

import abc
import re
from collections.abc import Sequence
from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import TYPE_CHECKING, Any, ClassVar

from config.logger import get_logger
from database.models import Source
from services.agents import model_agent
from services.parser_engine import BRAND_ALIASES, normalize_make
from services.synonyms_dict import slang_matches_query

if TYPE_CHECKING:  # pragma: no cover - typing only
    from config.settings import Settings
    from database.models import Subscription

__all__ = ["BaseScraper", "RawListing", "ScrapeBatch", "SearchQuery"]


@dataclass(frozen=True, slots=True)
class SearchQuery:
    """One user criterion, used to target scraping."""

    make: str
    model: str | None = None
    city: str | None = None
    max_price: int | None = None
    models: tuple[str, ...] = ()
    max_distance_km: int | None = None

    @classmethod
    def from_subscription(cls, subscription: Subscription) -> SearchQuery:
        models = tuple(getattr(subscription, "model_list", []) or [])
        check = model_agent.check_models(subscription.make, models)
        return cls(
            make=check.make or subscription.make,
            model=check.models[0] if check.models else subscription.model,
            city=subscription.city,
            max_price=subscription.max_price,
            models=check.models,
            max_distance_km=getattr(subscription, "max_distance_km", None),
        )

    def all_models(self) -> tuple[str, ...]:
        if self.models:
            return self.models
        return (self.model,) if self.model else ()

    def keywords(self) -> list[str]:
        words = [self.make, *self.all_models()]
        return [word.lower() for word in words if word]

    def expand(self) -> list[SearchQuery]:
        """One query per model, so scrapers can build separate search URLs."""
        models = self.all_models()
        if len(models) <= 1:
            return [self]
        return [
            replace(self, model=model, models=(model,))
            for model in dict.fromkeys(models)
        ]

    def search_label(self) -> str:
        """Make + models, without the city (VK/web search text)."""
        # VK and Avito understand the Russian VAZ alias much better than "Lada".
        make = {"Lada": "ВАЗ"}.get(self.make, self.make)
        parts = [make]
        models = self.all_models()
        if models:
            parts.append(" / ".join(models))
        return " ".join(parts)

    def label(self) -> str:
        parts = [self.search_label()]
        if self.city:
            parts.append(self.city)
        return " ".join(parts)


@dataclass(slots=True)
class RawListing:
    """Transport-level listing, before normalization."""

    source: Source
    url: str
    title: str
    raw_text: str = ""
    external_id: str | None = None
    price: int | None = None
    city: str | None = None
    year: int | None = None
    photos: list[str] = field(default_factory=list)
    published_at: datetime | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.title = (self.title or "").strip()
        self.raw_text = self.raw_text or ""
        if not self.title:
            first_line = next((line.strip() for line in self.raw_text.splitlines() if line.strip()), "")
            self.title = first_line[:300] or "Автомобиль"


@dataclass(slots=True)
class ScrapeBatch:
    listings: list[RawListing] = field(default_factory=list)
    cursor: dict[str, Any] = field(default_factory=dict)
    fetched_urls: int = 0

    def __len__(self) -> int:
        return len(self.listings)

    def extend(self, other: ScrapeBatch) -> None:
        self.listings.extend(other.listings)
        self.fetched_urls += other.fetched_urls
        if other.cursor:
            self.cursor.update(other.cursor)


class BaseScraper(abc.ABC):
    """Abstract scraper: fetch a batch and return the next cursor."""

    name: ClassVar[str] = "base"
    supports_search: ClassVar[bool] = False
    # Whether ad-hoc search needs one request per model (web/VK) or can use
    # a single make-level query (Telegram).
    expand_search_queries: ClassVar[bool] = True

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.log = get_logger(f"scraper.{self.name}")

    @property
    def enabled(self) -> bool:
        return True

    @abc.abstractmethod
    async def fetch(
        self,
        cursor: dict[str, Any] | None,
        queries: Sequence[SearchQuery],
    ) -> ScrapeBatch:
        """Return newly found listings and the cursor for the next run."""

    async def search(self, query: SearchQuery, limit: int = 10) -> list[RawListing]:
        """On-demand search that must not advance the background cursor."""
        raise NotImplementedError(f"{self.name} does not support ad-hoc search")

    async def close(self) -> None:
        """Release network resources."""
        return None

    async def __aenter__(self) -> BaseScraper:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.close()

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"<{type(self).__name__} name={self.name}>"


def _contains_word(haystack: str, needle: str) -> bool:
    if not needle:
        return False
    return re.search(
        rf"(?<![а-яёa-z0-9]){re.escape(needle)}(?![а-яёa-z0-9])", haystack, re.IGNORECASE
    ) is not None


def filter_by_queries(text: str, queries: Sequence[SearchQuery]) -> bool:
    """Cheap relevance check before expensive parsing/storage.

    Brand aliases are honoured, so a "BMW" subscription also keeps "бмв" posts.
    """
    if not queries:
        return True
    lowered = text.lower()
    for query in queries:
        make = normalize_make(query.make) or query.make
        models = list(query.all_models())
        if slang_matches_query(text, make, models):
            return True
        for candidate in (make, *BRAND_ALIASES.get(make, ())):
            if _contains_word(lowered, candidate):
                return True
    return False

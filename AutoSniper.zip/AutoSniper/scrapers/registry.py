"""Scraper registry — builds only the scrapers that are actually configured."""

from __future__ import annotations

from config.logger import get_logger
from config.settings import Settings
from scrapers.base import BaseScraper

logger = get_logger(__name__)

__all__ = ["build_scrapers"]


def build_scrapers(settings: Settings) -> list[BaseScraper]:
    scrapers: list[BaseScraper] = []

    if settings.telegram_ready:
        try:
            from scrapers.telegram import TelegramScraper

            scrapers.append(TelegramScraper(settings))
        except ImportError as exc:  # pragma: no cover - optional at runtime
            logger.error("Telegram scraper is unavailable: %s", exc)
    elif settings.telegram_enabled:
        logger.info("Telegram scraper skipped: credentials or channel list are missing")

    if settings.vk_ready:
        try:
            from scrapers.vk import VKScraper

            scrapers.append(VKScraper(settings))
        except ImportError as exc:  # pragma: no cover
            logger.error("VK scraper is unavailable: %s", exc)

    if settings.web_enabled:
        try:
            from scrapers.web import WebScraper

            web = WebScraper(settings)
            if web.targets:
                scrapers.append(web)
            else:
                logger.warning("Web scraper skipped: no valid WEB_TARGETS")
        except ImportError as exc:  # pragma: no cover
            logger.error("Web scraper is unavailable: %s", exc)

    if not scrapers:
        logger.warning(
            "No scrapers are active. The bot will run, but no new listings will arrive."
        )
    return scrapers

"""Modular web scraper: Avito, Auto.ru and RSS feeds.

The parser is schema-first: modern marketplaces embed JSON-LD (``schema.org``)
which is far more stable than CSS selectors. If JSON-LD is missing a
best-effort anchor fallback is used. Heavy JS protection can be handled by
enabling Playwright (see :mod:`scrapers.browser`).

Respect the target site's Terms of Service and ``robots.txt``; prefer official
APIs where they exist.
"""

from __future__ import annotations

import asyncio
import html as html_module
import json
import re
import xml.etree.ElementTree as ET
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from typing import Any, ClassVar
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

from config.logger import get_logger
from config.settings import Settings
from database.models import Source
from scrapers.base import BaseScraper, RawListing, ScrapeBatch, SearchQuery
from scrapers.browser import BrowserFetcher
from services.geo import city_from_slug, slug_for_city
from services.net import (
    DEFAULT_USER_AGENTS,
    HttpClient,
    NetworkError,
    RateLimiter,
    ScraperError,
)
from services.parser_engine import normalize_make, normalize_model, parse_price

try:  # pragma: no cover - optional import guard
    from bs4 import BeautifulSoup
except ImportError:  # pragma: no cover
    BeautifulSoup = None  # type: ignore[assignment]

logger = get_logger(__name__)

_JSON_LD_RE = re.compile(
    r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
    re.IGNORECASE | re.DOTALL,
)
_PRICE_IN_TEXT_RE = re.compile(r"(\d[\d\s\u00a0]{4,})\s*(?:₽|руб)")
_HTML_TAG_RE = re.compile(r"<[^>]+>")
_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}")


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------


def _make_soup(html: str) -> Any:
    if BeautifulSoup is None:  # pragma: no cover - dependency guard
        raise ScraperError("beautifulsoup4 is not installed: pip install beautifulsoup4 lxml")
    try:
        return BeautifulSoup(html, "lxml")
    except Exception:  # pragma: no cover - lxml missing
        return BeautifulSoup(html, "html.parser")


def _strip_html(value: str | None) -> str:
    if not value:
        return ""
    text = _HTML_TAG_RE.sub(" ", value)
    return re.sub(r"\s+", " ", html_module.unescape(text)).strip()


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _iter_json_ld(html: str) -> Iterable[dict[str, Any]]:
    for match in _JSON_LD_RE.finditer(html):
        raw = html_module.unescape(match.group(1)).strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except ValueError:
            continue
        yield from _walk_json(data)


def _walk_json(node: Any) -> Iterable[dict[str, Any]]:
    if isinstance(node, list):
        for item in node:
            yield from _walk_json(item)
        return
    if not isinstance(node, dict):
        return
    yield node
    for key in ("@graph", "itemListElement", "item", "mainEntity", "offers", "makesOffer"):
        if key in node:
            yield from _walk_json(node[key])


def _types(node: dict[str, Any]) -> set[str]:
    return {str(item).lower() for item in _as_list(node.get("@type"))}


def _is_product(node: dict[str, Any]) -> bool:
    types = _types(node)
    if types & {"product", "vehicle", "car", "vehicleoffer"}:
        return True
    return "offers" in node and ("name" in node or "url" in node)


def _first_offer(node: dict[str, Any]) -> dict[str, Any]:
    offers = node.get("offers")
    if isinstance(offers, list) and offers:
        offers = offers[0]
    return offers if isinstance(offers, dict) else {}


def _extract_price(node: dict[str, Any]) -> int | None:
    offer = _first_offer(node)
    for value in (
        offer.get("price"),
        offer.get("lowPrice"),
        node.get("price"),
        node.get("priceValue"),
    ):
        if value is None:
            continue
        if isinstance(value, (int, float)):
            price = int(value)
            return price if 20_000 <= price <= 100_000_000 else None
        parsed = parse_price(str(value))
        if parsed:
            return parsed
    return None


def _extract_year(node: dict[str, Any]) -> int | None:
    for key in ("vehicleModelDate", "modelDate", "productionDate", "dateVehicleFirstRegistered", "year"):
        value = node.get(key)
        if value is None:
            continue
        match = re.search(r"(19[5-9]\d|20[0-4]\d)", str(value))
        if match:
            return int(match.group(1))
    return None


def _extract_images(node: dict[str, Any]) -> list[str]:
    images: list[str] = []
    for value in (
        node.get("image"),
        node.get("photo"),
        node.get("thumbnailUrl"),
        _first_offer(node).get("image"),
    ):
        for item in _as_list(value):
            if isinstance(item, str) and item.startswith("http"):
                images.append(item)
            elif isinstance(item, dict):
                candidate = item.get("url") or item.get("contentUrl")
                if isinstance(candidate, str) and candidate.startswith("http"):
                    images.append(candidate)
    return list(dict.fromkeys(images))[:3]


def _extract_city(value: Any) -> str | None:
    if isinstance(value, str):
        return value.strip() or None
    if isinstance(value, dict):
        for key in ("addressLocality", "name", "address", "areaServed"):
            if key in value:
                found = _extract_city(value[key])
                if found:
                    return found
    if isinstance(value, list):
        for item in value:
            found = _extract_city(item)
            if found:
                return found
    return None


def _parse_datetime(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except ValueError:
        return None


def _brand_name(node: dict[str, Any]) -> str:
    brand = node.get("brand")
    if isinstance(brand, dict):
        return str(brand.get("name") or "")
    if isinstance(brand, str):
        return brand
    return ""


def _node_to_raw(node: dict[str, Any], base_url: str, source: Source) -> RawListing | None:
    name = str(node.get("name") or "").strip()
    brand = _brand_name(node)
    model = node.get("model") or node.get("vehicleModel")
    if not name and brand:
        name = f"{brand} {model or ''}".strip()
    elif brand and brand.lower() not in name.lower():
        name = f"{brand} {name}".strip()
    if not name:
        return None

    raw_url = node.get("url") or node.get("@id") or ""
    if not isinstance(raw_url, str):
        raw_url = ""
    url = urljoin(base_url, raw_url) if raw_url else base_url
    if not url.startswith("http"):
        return None

    description = _strip_html(str(node.get("description") or ""))
    raw_text = f"{name}\n{description}".strip()
    published = _parse_datetime(
        node.get("datePosted") or node.get("datePublished") or node.get("publicationDate")
    )
    external_id = node.get("sku") or node.get("productID") or node.get("@id")
    if not isinstance(external_id, str):
        external_id = url

    return RawListing(
        source=source,
        url=url,
        title=name[:300],
        raw_text=raw_text,
        external_id=str(external_id)[:128],
        price=_extract_price(node),
        city=_extract_city(
            node.get("areaServed")
            or _first_offer(node).get("availableAtOrFrom")
            or node.get("address")
        ),
        year=_extract_year(node),
        photos=_extract_images(node),
        published_at=published,
        meta={"parser": "json-ld"},
    )


def _pick_image(container: Any) -> Any:
    """First content image, skipping tiny service icons without alt text."""
    if container is None:
        return None
    images = container.find_all("img")
    for image in images:
        src = image.get("src") or image.get("data-src") or image.get("data-original")
        if image.get("alt") and src:
            return image
    for image in images:
        if image.get("src") or image.get("data-src") or image.get("data-original"):
            return image
    return None


def _image_title(image: Any) -> str | None:
    """Extract a clean car title from an image alt (Auto.ru/Avito)."""
    if image is None:
        return None
    alt = image.get("alt") or image.get("title") or ""
    if not isinstance(alt, str):
        return None
    text = re.sub(r"^(?:ещё|еще)\s+\d+\s+фото\s*", "", alt.strip(), flags=re.I)
    text = re.sub(r"^\d{4}\s+", "", text)
    text = re.split(
        r",\s*(?:вид\s*\d+|\d[\d\s]{3,}\s*рублей|ч[её]рный|белый|серый|серебристый|"
        r"синий|красный|зел[её]ный|коричневый|бежевый|ж[её]лтый|оранжевый|"
        r"фиолетовый|голубой)\b",
        text,
        maxsplit=1,
        flags=re.I,
    )[0]
    text = text.strip(" ,")
    return text if len(text) >= 8 else None


def _anchor_title_score(anchor: Any) -> int:
    """Prefer real listing titles over "photo"/price/spec service links."""
    text = anchor.get_text(" ", strip=True)
    lowered = text.lower()
    bad = (
        "фото",
        "история",
        "ещё",
        "еще",
        "смотреть",
        "все объявления",
        "подробнее",
        "показать",
        "проверить",
    )
    if any(word in lowered for word in bad):
        return -1
    score = len(text)
    classes = " ".join(anchor.get("class") or []).lower()
    if "title" in classes:
        score += 100
    if "₽" in text or "руб" in lowered:
        score -= 200
    if re.search(r"\d+\s*(?:л\.?\s*с|км|at\b|mt\b)", lowered):
        score -= 40
    return score


def _dedupe(listings: Sequence[RawListing]) -> list[RawListing]:
    seen: set[str] = set()
    unique: list[RawListing] = []
    for listing in listings:
        key = listing.url or listing.external_id or listing.title
        if key in seen:
            continue
        seen.add(key)
        unique.append(listing)
    return unique


def _with_query(base_url: str, key: str, value: str) -> str:
    parts = urlsplit(base_url)
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True) if k != key]
    query.append((key, value))
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def _city_from_url(url: str) -> str | None:
    for segment in [part for part in urlsplit(url).path.split("/") if part][:4]:
        city = city_from_slug(segment)
        if city:
            return city
    return None


_AUTO_MAKE_SLUGS: dict[str, str] = {
    "Lada": "vaz",
    "Mercedes-Benz": "mercedes",
    "Land Rover": "land-rover",
    "Great Wall": "great-wall",
    "Alfa Romeo": "alfa-romeo",
}
_DROM_MAKE_SLUGS: dict[str, str] = {
    "Mercedes-Benz": "mercedes-benz",
    "Land Rover": "land-rover",
    "Great Wall": "great-wall",
    "Alfa Romeo": "alfa-romeo",
}


def _make_slug(make: str, overrides: dict[str, str]) -> str:
    canonical = normalize_make(make) or make
    if canonical in overrides:
        return overrides[canonical]
    return re.sub(r"[^a-z0-9]+", "-", canonical.lower()).strip("-")


def _url_city_slug(url: str, fallback: str) -> str:
    for segment in [part for part in urlsplit(url).path.split("/") if part][:4]:
        if city_from_slug(segment):
            return segment
    return fallback


def _model_path_slug(model: str | None) -> str:
    """Safe short slug for numeric/simple model paths (2101, X5, M3)."""
    if not model:
        return ""
    normalized = normalize_model(model)
    if not normalized:
        return ""
    lowered = normalized.lower()
    if re.search(r"[^a-z0-9]", lowered):
        return ""
    value = re.sub(r"[^a-z0-9]+", "", lowered)
    return value if 1 <= len(value) <= 8 else ""


def _source_for_feed(url: str) -> Source:
    host = urlsplit(url).netloc.lower()
    if "avito" in host:
        return Source.AVITO
    if "auto.ru" in host or "autoru" in host:
        return Source.AUTORU
    return Source.RSS


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------


class BaseWebProvider:
    key: ClassVar[str] = "base"
    source: ClassVar[Source] = Source.RSS
    url_param: ClassVar[str] = "q"
    listing_pattern: ClassVar[str | None] = None
    supports_search: ClassVar[bool] = True

    def build_urls(self, base_url: str, queries: Sequence[SearchQuery]) -> list[str]:
        if not queries or not self.supports_search:
            return [base_url]
        urls = [_with_query(base_url, self.url_param, query.search_label()) for query in queries[:10]]
        return list(dict.fromkeys(urls))

    def parse(self, html: str, url: str) -> list[RawListing]:
        raise NotImplementedError


class JsonLdProvider(BaseWebProvider):
    """Parses schema.org JSON-LD, with an anchor-based fallback."""

    def parse(self, html: str, url: str) -> list[RawListing]:
        source = self.source_for(url)
        listings: list[RawListing] = []
        for node in _iter_json_ld(html):
            if not _is_product(node):
                continue
            raw = _node_to_raw(node, url, source)
            if raw is not None:
                listings.append(raw)
        listings = _dedupe(listings)
        if not listings:
            listings = self._parse_anchors(html, url, source)
        return listings

    def source_for(self, url: str) -> Source:
        return self.source

    def _parse_anchors(self, html: str, url: str, source: Source) -> list[RawListing]:
        soup = _make_soup(html)
        results: list[RawListing] = []
        groups: dict[str, list[Any]] = {}
        for anchor in soup.find_all("a", href=True):
            href = str(anchor.get("href") or "")
            if not href or href.startswith(("#", "javascript:", "mailto:")):
                continue
            full_url = urljoin(url, href)
            if self.listing_pattern and not re.search(self.listing_pattern, full_url):
                continue
            groups.setdefault(full_url, []).append(anchor)

        for full_url, anchors in groups.items():
            anchor = max(anchors, key=_anchor_title_score)
            title = anchor.get_text(" ", strip=True)

            container = anchor.parent or anchor
            text = ""
            for _ in range(6):
                if container is None:
                    break
                candidate = container.get_text(" ", strip=True)[:800]
                if _PRICE_IN_TEXT_RE.search(candidate):
                    text = candidate
                    break
                container = container.parent
            if not text:
                continue

            image = _pick_image(container) if container is not None else None
            image_title = _image_title(image)
            if image_title and (_anchor_title_score(anchor) < 8 or len(image_title) > len(title)):
                title = image_title
            if len(title) < 8:
                continue

            photo = None
            if image is not None:
                photo = image.get("src") or image.get("data-src") or image.get("data-original")
                if isinstance(photo, str) and photo.startswith("//"):
                    photo = "https:" + photo
            results.append(
                RawListing(
                    source=source,
                    url=full_url,
                    title=title[:300],
                    raw_text=f"{title}\n{text}",
                    external_id=full_url,
                    price=parse_price(text),
                    city=_city_from_url(full_url) or _city_from_url(url),
                    photos=[str(photo)] if photo else [],
                    meta={"parser": "anchors"},
                )
            )
            if len(results) >= 40:
                break
        return results


class AvitoProvider(JsonLdProvider):
    key = "avito"
    source = Source.AVITO
    url_param = "q"
    listing_pattern = r"avito\.ru/.+/\d{6,}"

    def build_urls(self, base_url: str, queries: Sequence[SearchQuery]) -> list[str]:
        if not queries:
            return [base_url]
        parts = urlsplit(base_url)
        base_city = _url_city_slug(base_url, "ekaterinburg")
        urls: list[str] = []
        for query in queries[:10]:
            city = slug_for_city(query.city) or base_city
            search = [(key, value) for key, value in parse_qsl(parts.query) if key != "q"]
            search.append(("q", query.search_label()))
            urls.append(
                urlunsplit(
                    (
                        parts.scheme,
                        parts.netloc,
                        f"/{city}/avtomobili",
                        urlencode(search),
                        "",
                    )
                )
            )
        # A query URL is often blocked while the category page still opens.
        # Keep one no-query fallback per target; the matcher filters locally.
        fallback = urlunsplit(
            (parts.scheme, parts.netloc, f"/{base_city}/avtomobili", "", "")
        )
        urls.append(fallback)
        return list(dict.fromkeys(urls)) or [base_url]


class AutoRuProvider(JsonLdProvider):
    key = "auto_ru"
    source = Source.AUTORU
    url_param = "text"
    listing_pattern = r"auto\.ru/cars/used/sale/"

    def build_urls(self, base_url: str, queries: Sequence[SearchQuery]) -> list[str]:
        if not queries:
            return [base_url]
        parts = urlsplit(base_url)
        query = [(key, value) for key, value in parse_qsl(parts.query) if key not in {"text", "q"}]
        urls: list[str] = []
        for item in queries[:10]:
            make = _make_slug(item.make, _AUTO_MAKE_SLUGS)
            if not make:
                continue
            city = slug_for_city(item.city) or _url_city_slug(base_url, "moskva")
            model = _model_path_slug(item.model or (item.models[0] if item.models else None))
            model_path = f"{model}/" if model else ""
            urls.append(
                urlunsplit(
                    (
                        parts.scheme,
                        parts.netloc,
                        f"/{city}/cars/{make}/{model_path}used/",
                        urlencode(query),
                        "",
                    )
                )
            )
        return list(dict.fromkeys(urls)) or [base_url]

    def parse(self, html: str, url: str) -> list[RawListing]:
        head = html[:50_000].lower()
        if "showcaptcha" in head or "smartcaptcha" in head:
            raise ScraperError(
                "Auto.ru вернул CAPTCHA: нужен браузер/резидентный IP; "
                "автоматический обход не поддерживается."
            )
        return super().parse(html, url)

    def _parse_anchors(self, html: str, url: str, source: Source) -> list[RawListing]:
        listings = super()._parse_anchors(html, url, source)
        for listing in listings:
            if listing.published_at is None:
                # Auto.ru does not render the publication date in search cards.
                # The target URL is sorted by freshness, so use the fetch time
                # as an approximation instead of dropping every listing.
                listing.published_at = datetime.now(UTC)
                listing.meta["date_assumed"] = True
            else:
                listing.published_at = _parse_drom_date(listing.raw_text) or listing.published_at
        return listings


_DROM_MONTHS: dict[str, int] = {
    "января": 1,
    "февраля": 2,
    "марта": 3,
    "апреля": 4,
    "мая": 5,
    "июня": 6,
    "июля": 7,
    "августа": 8,
    "сентября": 9,
    "октября": 10,
    "ноября": 11,
    "декабря": 12,
}
_DROM_BULLS_RE = re.compile(r'"bullsData"\s*:\s*')


def _parse_drom_date(value: Any, now: datetime | None = None) -> datetime | None:
    """Parse Drom's relative dates ("сегодня", "3 дня назад", "10 октября")."""
    if not isinstance(value, str):
        return None
    text = value.strip().lower().replace("ё", "е")
    if not text:
        return None
    reference = now or datetime.now(UTC)
    if "сегодня" in text:
        return reference
    if "вчера" in text:
        return reference - timedelta(days=1)

    relative = re.search(r"(\d+)\s*(минут|час|дн|день|дня|дней|недел|мес)", text)
    if relative:
        amount = int(relative.group(1))
        unit = relative.group(2)
        if unit.startswith("минут"):
            return reference - timedelta(minutes=amount)
        if unit.startswith("час"):
            return reference - timedelta(hours=amount)
        if unit.startswith("недел"):
            return reference - timedelta(weeks=amount)
        if unit.startswith("мес"):
            return reference - timedelta(days=30 * amount)
        return reference - timedelta(days=amount)

    absolute = re.search(r"(\d{1,2})\s+([а-я]+)", text)
    if absolute:
        day = int(absolute.group(1))
        word = absolute.group(2)
        month = _DROM_MONTHS.get(word)
        if month is None:
            for name, number in _DROM_MONTHS.items():
                if word.startswith(name[:3]):
                    month = number
                    break
        if month:
            try:
                candidate = datetime(reference.year, month, day, tzinfo=UTC)
            except ValueError:
                return None
            if candidate > reference + timedelta(days=1):
                candidate = candidate.replace(year=reference.year - 1)
            return candidate
    return None


def _drom_attribute_text(attribute: Any) -> str:
    if not isinstance(attribute, dict):
        return ""
    payload = attribute.get("payload")
    if isinstance(payload, str):
        return payload
    if isinstance(payload, dict):
        return str(payload.get("text") or payload.get("content") or "")
    return ""


def _find_bulls_data(node: Any) -> Any:
    if isinstance(node, dict):
        if "bullsData" in node:
            return node["bullsData"]
        for value in node.values():
            found = _find_bulls_data(value)
            if found is not None:
                return found
    elif isinstance(node, list):
        for value in node:
            found = _find_bulls_data(value)
            if found is not None:
                return found
    return None


class DromProvider(JsonLdProvider):
    """Drom.ru: the listing page embeds a JSON state with all card fields."""

    key = "drom"
    source = Source.DROM
    url_param = "q"
    listing_pattern = r"auto\.drom\.ru/.+/\d+\.html"

    def build_urls(self, base_url: str, queries: Sequence[SearchQuery]) -> list[str]:
        if not queries:
            return [base_url]
        parts = urlsplit(base_url)
        urls: list[str] = []
        for item in queries[:10]:
            make = _make_slug(item.make, _DROM_MAKE_SLUGS)
            if not make:
                continue
            city = slug_for_city(item.city) or _url_city_slug(base_url, "moscow")
            model = _model_path_slug(item.model or (item.models[0] if item.models else None))
            path = f"/{city}/{make}/{model}/" if model else f"/{city}/{make}/"
            urls.append(urlunsplit((parts.scheme, parts.netloc, path, "", "")))
        return list(dict.fromkeys(urls)) or [base_url]

    def parse(self, html: str, url: str) -> list[RawListing]:
        listings = self._parse_embedded(html, url)
        if not listings:
            listings = self._parse_offers(html, url)
        if not listings:
            listings = self._parse_anchors(html, url, self.source)
        return _dedupe(listings)

    def _parse_embedded(self, html: str, url: str) -> list[RawListing]:
        payload: Any = None
        match = _DROM_BULLS_RE.search(html)
        if match:
            try:
                payload, _ = json.JSONDecoder().raw_decode(html[match.end() :])
            except ValueError:
                payload = None
        if payload is None:
            try:
                payload = json.loads(html)
            except ValueError:
                return []

        data = _find_bulls_data(payload) if isinstance(payload, dict) else payload
        if data is None:
            data = payload
        groups = data if isinstance(data, list) else [data]

        listings: list[RawListing] = []
        for group in groups:
            if not isinstance(group, dict):
                continue
            bulls = group.get("bulls")
            if not isinstance(bulls, list):
                continue
            for bull in bulls:
                if not isinstance(bull, dict):
                    continue
                listing = self._bull_to_raw(bull, url)
                if listing is not None:
                    listings.append(listing)
        return listings

    def _bull_to_raw(self, bull: dict[str, Any], base_url: str) -> RawListing | None:
        bull_id = bull.get("bullId")
        raw_url = bull.get("url")
        title = str(bull.get("title") or "").strip()
        if bull_id is None or not isinstance(raw_url, str) or not raw_url:
            return None
        if not title:
            title = f"Drom listing {bull_id}"
        full_url = urljoin(base_url, raw_url)

        price: int | None = None
        raw_price = bull.get("price")
        if isinstance(raw_price, (int, float)):
            price = int(raw_price)
        elif raw_price is not None:
            price = parse_price(str(raw_price))

        photos: list[str] = []
        images = bull.get("images")
        if isinstance(images, dict):
            for item in images.get("items") or []:
                if not isinstance(item, dict):
                    continue
                candidate = item.get("src2x") or item.get("src")
                if isinstance(candidate, str) and candidate.startswith("http"):
                    photos.append(candidate)
                if len(photos) >= 3:
                    break

        attributes = [
            _drom_attribute_text(attribute)
            for attribute in (bull.get("attributes") or [])
        ]
        subtitle = str(bull.get("subtitle") or "").strip()
        description = str(bull.get("description") or "").strip()
        raw_text = "\n".join(
            part for part in [title, subtitle, description, *attributes] if part
        )

        published = _parse_drom_date(bull.get("date"))
        return RawListing(
            source=Source.DROM,
            url=full_url,
            title=title[:300],
            raw_text=raw_text,
            external_id=str(bull_id),
            price=price,
            city=str(bull.get("location") or "").strip() or _city_from_url(full_url),
            photos=photos,
            published_at=published,
            meta={"parser": "drom-state", "bull_id": bull_id},
        )

    def _parse_offers(self, html: str, url: str) -> list[RawListing]:
        """Fallback for pages that only expose schema.org AggregateOffer."""
        listings: list[RawListing] = []
        for node in _iter_json_ld(html):
            offers = node.get("offers")
            if not isinstance(offers, dict):
                continue
            items = offers.get("offers")
            if not isinstance(items, list):
                continue
            for offer in items:
                if not isinstance(offer, dict):
                    continue
                offer_url = offer.get("url")
                title = str(offer.get("name") or "").strip()
                if not isinstance(offer_url, str) or not title:
                    continue
                price = offer.get("price")
                try:
                    value = int(float(price)) if price is not None else None
                except (TypeError, ValueError):
                    value = parse_price(str(price)) if price is not None else None
                external = re.search(r"(\d+)\.html", offer_url)
                listings.append(
                    RawListing(
                        source=Source.DROM,
                        url=urljoin(url, offer_url),
                        title=title[:300],
                        raw_text=title,
                        external_id=external.group(1) if external else offer_url,
                        price=value,
                        meta={"parser": "drom-offers"},
                    )
                )
        return listings


class RssProvider(BaseWebProvider):
    key = "rss"
    supports_search = False

    def build_urls(self, base_url: str, queries: Sequence[SearchQuery]) -> list[str]:
        return [base_url]

    def parse(self, html: str, url: str) -> list[RawListing]:
        try:
            root = ET.fromstring(html)
        except ET.ParseError as exc:
            raise ScraperError(f"Invalid RSS/Atom feed {url}: {exc}") from exc

        source = _source_for_feed(url)
        items = list(root.iter("item"))
        if not items:
            items = [
                element
                for element in root.iter()
                if str(element.tag).endswith("}entry") or element.tag == "entry"
            ]

        results: list[RawListing] = []
        for item in items:
            title = _child_text(item, "title")
            link = _child_text(item, "link")
            if not link:
                link_element = next(
                    (child for child in item if str(child.tag).endswith("link") and child.get("href")),
                    None,
                )
                link = link_element.get("href") if link_element is not None else ""
            if not title or not link:
                continue

            description = _child_text(item, "description") or _child_text(item, "summary")
            content = _child_text(item, "encoded") or _child_text(item, "content")
            text = _strip_html(description or content)

            guid = _child_text(item, "guid") or _child_text(item, "id") or link
            published = _parse_feed_date(
                _child_text(item, "pubDate")
                or _child_text(item, "published")
                or _child_text(item, "updated")
            )

            photos: list[str] = []
            for child in item:
                tag = str(child.tag).lower()
                if tag.endswith("enclosure") or tag.endswith("content"):
                    photo_url = child.get("url")
                    if photo_url:
                        photos.append(photo_url)
            image_match = re.search(r'<img[^>]+src=["\']([^"\']+)', description or "", re.I)
            if image_match:
                photos.insert(0, image_match.group(1))

            results.append(
                RawListing(
                    source=source,
                    url=link,
                    title=_strip_html(title)[:300],
                    raw_text=f"{_strip_html(title)}\n{text}".strip(),
                    external_id=guid[:128],
                    price=parse_price(text) or parse_price(title),
                    photos=list(dict.fromkeys(photos))[:3],
                    published_at=published,
                    meta={"parser": "rss"},
                )
            )
        return _dedupe(results)


def _child_text(element: ET.Element, local_name: str) -> str:
    for child in element:
        tag = str(child.tag)
        if tag == local_name or tag.endswith(f"}}{local_name}"):
            return (child.text or "").strip()
    return ""


def _parse_feed_date(value: str) -> datetime | None:
    if not value:
        return None
    try:
        parsed = parsedate_to_datetime(value)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except (TypeError, ValueError):
        pass
    if _ISO_DATE_RE.match(value):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
        except ValueError:
            return None
    return None


PROVIDERS: dict[str, BaseWebProvider] = {
    "avito": AvitoProvider(),
    "auto_ru": AutoRuProvider(),
    "drom": DromProvider(),
    "rss": RssProvider(),
}


@dataclass(frozen=True, slots=True)
class WebTarget:
    provider: str
    url: str


def parse_targets(entries: Sequence[str]) -> list[WebTarget]:
    targets: list[WebTarget] = []
    for entry in entries:
        provider, separator, url = entry.partition(":")
        key = provider.strip().lower().replace(".", "_").replace("-", "_")
        aliases = {
            "auto_ru": "auto_ru",
            "autoru": "auto_ru",
            "avito_ru": "avito",
            "drom_ru": "drom",
        }
        key = aliases.get(key, key)
        if not separator or not url.startswith(("http://", "https://")):
            logger.warning("Skipping malformed WEB_TARGETS entry: %r (expected provider:url)", entry)
            continue
        if key not in PROVIDERS:
            logger.warning("Unknown web provider %r in %r; supported: %s", key, entry, ", ".join(PROVIDERS))
            continue
        targets.append(WebTarget(provider=key, url=url))
    return targets


class WebScraper(BaseScraper):
    name = "web"
    supports_search = True

    def __init__(self, settings: Settings) -> None:
        super().__init__(settings)
        self.targets = parse_targets(settings.web_targets)
        self._http: HttpClient | None = None
        self._browser: BrowserFetcher | None = None
        self._browser_lock = asyncio.Lock()

    @property
    def enabled(self) -> bool:
        return self.settings.web_enabled and bool(self.targets)

    async def _client(self) -> HttpClient:
        if self._http is None:
            self._http = HttpClient(
                timeout=self.settings.request_timeout_seconds,
                max_retries=self.settings.max_retries,
                backoff_base=self.settings.backoff_base_seconds,
                backoff_max=self.settings.backoff_max_seconds,
                proxies=self.settings.proxies,
                user_agents=self.settings.web_user_agents,
                rate_limiter=RateLimiter(self.settings.web_rate_limit_per_second),
                default_headers={"Accept-Language": "ru-RU,ru;q=0.9"},
            )
        return self._http

    async def _browser_fetcher(self) -> BrowserFetcher:
        async with self._browser_lock:
            if self._browser is None:
                self._browser = BrowserFetcher(self.settings)
            return self._browser

    async def close(self) -> None:
        if self._http is not None:
            await self._http.close()
            self._http = None
        if self._browser is not None:
            await self._browser.close()
            self._browser = None

    async def _fetch_html(self, target: WebTarget, url: str) -> str:
        if target.provider == "rss":
            return await (await self._client()).get_text(url)
        if self.settings.web_use_playwright:
            browser = await self._browser_fetcher()
            return await browser.fetch(url, user_agent=DEFAULT_USER_AGENTS[0])
        return await (await self._client()).get_text(url)

    async def fetch(
        self,
        cursor: dict[str, Any] | None,
        queries: Sequence[SearchQuery],
    ) -> ScrapeBatch:
        batch = ScrapeBatch(cursor={})
        attempts = 0
        errors = 0
        seen_urls: set[str] = set()
        per_target_limit = max(
            1, self.settings.web_batch_limit // max(1, len(self.targets))
        )

        for target in self.targets:
            provider = PROVIDERS[target.provider]
            expanded_queries = [expanded for query in queries for expanded in query.expand()]
            urls = provider.build_urls(target.url, expanded_queries)
            max_urls = max(1, self.settings.web_max_pages) * max(
                1, min(len(expanded_queries), 10)
            )
            urls = [url for url in urls if url not in seen_urls][:max_urls]
            target_collected = 0
            for url in urls:
                if target_collected >= per_target_limit:
                    break
                seen_urls.add(url)
                attempts += 1
                try:
                    html = await self._fetch_html(target, url)
                except (NetworkError, ScraperError) as exc:
                    errors += 1
                    self.log.warning("Web fetch failed for %s: %s", url, exc)
                    continue
                try:
                    listings = provider.parse(html, url)
                except ScraperError as exc:
                    errors += 1
                    self.log.warning("Web parse failed for %s: %s", url, exc)
                    continue
                except Exception as exc:  # defensive against markup changes
                    errors += 1
                    self.log.warning("Unexpected parse error for %s: %s", url, exc)
                    continue

                batch.fetched_urls += 1
                remaining = per_target_limit - target_collected
                if remaining <= 0:
                    break
                chunk = listings[:remaining]
                batch.listings.extend(chunk)
                target_collected += len(chunk)
                if len(batch.listings) >= self.settings.web_batch_limit:
                    batch.listings = batch.listings[: self.settings.web_batch_limit]
                    return batch

        if attempts and errors == attempts:
            raise NetworkError(f"All {attempts} web request(s) failed")
        return batch

    async def search(self, query: SearchQuery, limit: int = 10) -> list[RawListing]:
        results: list[RawListing] = []
        for target in self.targets:
            provider = PROVIDERS[target.provider]
            if not provider.supports_search:
                continue
            for url in provider.build_urls(target.url, [query])[:1]:
                try:
                    html = await self._fetch_html(target, url)
                    listings = provider.parse(html, url)
                except (NetworkError, ScraperError) as exc:
                    self.log.warning("Web search failed for %s: %s", url, exc)
                    continue
                results.extend(listings)
                if len(results) >= limit * 3:
                    return results[: limit * 3]
        return results


__all__ = [
    "AutoRuProvider",
    "AvitoProvider",
    "BaseWebProvider",
    "DromProvider",
    "PROVIDERS",
    "RssProvider",
    "WebScraper",
    "WebTarget",
    "parse_targets",
]

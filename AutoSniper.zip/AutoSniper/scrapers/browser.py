"""Optional Playwright renderer for heavily protected marketplaces (Avito).

Install once::

    pip install playwright
    playwright install chromium

Enable with ``WEB_USE_PLAYWRIGHT=true``.
"""

from __future__ import annotations

from typing import Any

from config.logger import get_logger
from config.settings import Settings
from services.net import DEFAULT_USER_AGENTS, ScraperError

logger = get_logger(__name__)


class BrowserFetcher:
    """Reuses a single headless Chromium instance across requests."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._playwright: Any | None = None
        self._browser: Any | None = None

    async def _ensure_browser(self) -> Any:
        if self._browser is not None:
            return self._browser
        try:
            from playwright.async_api import async_playwright
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise ScraperError(
                "WEB_USE_PLAYWRIGHT=true but Playwright is not installed. "
                "Run: pip install playwright && playwright install chromium"
            ) from exc

        self._playwright = await async_playwright().start()
        launch_args: dict[str, Any] = {"headless": True}
        proxy = self.settings.proxy_url
        if proxy:
            launch_args["proxy"] = {"server": proxy}
        try:
            self._browser = await self._playwright.chromium.launch(**launch_args)
        except Exception as exc:  # pragma: no cover - browser binaries missing
            await self._playwright.stop()
            self._playwright = None
            raise ScraperError(
                f"Cannot start Chromium: {exc}. Run `playwright install chromium`."
            ) from exc
        logger.info("Playwright Chromium started")
        return self._browser

    async def fetch(self, url: str, *, user_agent: str | None = None) -> str:
        browser = await self._ensure_browser()
        context = await browser.new_context(
            user_agent=user_agent or DEFAULT_USER_AGENTS[0],
            locale="ru-RU",
            viewport={"width": 1440, "height": 900},
            java_script_enabled=True,
        )
        try:
            page = await context.new_page()
            await page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=int(self.settings.request_timeout_seconds * 1000),
            )
            # Give client-side rendered listings a moment to appear.
            await page.wait_for_timeout(2500)
            return await page.content()
        except Exception as exc:
            raise ScraperError(f"Playwright failed for {url}: {exc}") from exc
        finally:
            await context.close()

    async def close(self) -> None:
        if self._browser is not None:
            try:
                await self._browser.close()
            finally:
                self._browser = None
        if self._playwright is not None:
            try:
                await self._playwright.stop()
            finally:
                self._playwright = None


__all__ = ["BrowserFetcher"]

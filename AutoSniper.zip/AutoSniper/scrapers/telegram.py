"""Telegram channel/chat scraper built on Telethon.

Requires a *user* session (not a bot token): join the sale channels with the
account once, then this scraper reads new messages from them.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from datetime import UTC
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from config.logger import get_logger
from config.settings import Settings
from database.models import Source
from scrapers.base import BaseScraper, RawListing, ScrapeBatch, SearchQuery, filter_by_queries

logger = get_logger(__name__)

try:  # pragma: no cover - import guard, exercised in production only
    from telethon import TelegramClient, errors
except ImportError:  # pragma: no cover
    TelegramClient = None  # type: ignore[assignment]
    errors = None  # type: ignore[assignment]


class TelegramScraper(BaseScraper):
    name = "telegram"
    supports_search = True
    expand_search_queries = False

    def __init__(self, settings: Settings) -> None:
        super().__init__(settings)
        self._client: Any | None = None
        self._media_dir = Path(settings.media_dir).expanduser().resolve()
        self._photo_budget = 0

    @property
    def enabled(self) -> bool:
        return self.settings.telegram_ready

    # ------------------------------------------------------------------
    # Client lifecycle
    # ------------------------------------------------------------------
    async def _ensure_client(self) -> Any:
        if self._client is not None:
            return self._client
        if TelegramClient is None:
            raise RuntimeError("Telethon is not installed: pip install telethon")
        if not self.settings.telegram_ready:
            raise RuntimeError(
                "Telegram scraper is not configured (TELEGRAM_API_ID / HASH / CHANNELS)."
            )

        self._media_dir.mkdir(parents=True, exist_ok=True)
        session_path = Path(self.settings.telegram_session)
        session_path.parent.mkdir(parents=True, exist_ok=True)

        client = TelegramClient(
            str(session_path),
            self.settings.telegram_api_id,
            self.settings.telegram_api_hash,
            proxy=self._telethon_proxy(),
            flood_sleep_threshold=60,
            device_model="AutoSniper",
            system_version="1.0",
            app_version="1.0",
            lang_code="ru",
        )
        try:
            await client.connect()
        except Exception as exc:  # network / proxy / socks missing
            await client.disconnect()
            raise RuntimeError(
                f"Cannot connect to Telegram: {exc}. "
                "If you use a SOCKS proxy install `python-socks[asyncio]`."
            ) from exc

        if not await client.is_user_authorized():
            await client.disconnect()
            raise RuntimeError(
                "Telegram session is not authorized. Run `python scripts/tg_login.py` once "
                "and confirm the login code in Telegram."
            )

        self._client = client
        self.log.info("Telegram client connected as user session")
        return client

    def _telethon_proxy(self) -> dict[str, Any] | None:
        proxy_url = self.settings.proxy_url
        if not proxy_url:
            return None
        parts = urlsplit(proxy_url)
        if not parts.hostname or not parts.port:
            self.log.warning("Ignoring malformed proxy URL: %s", proxy_url)
            return None
        proxy_type = {"socks5": "socks5", "socks5h": "socks5", "socks4": "socks4", "http": "http"}.get(
            parts.scheme.lower()
        )
        if proxy_type is None:
            self.log.warning("Unsupported Telegram proxy scheme: %s", parts.scheme)
            return None
        return {
            "proxy_type": proxy_type,
            "addr": parts.hostname,
            "port": int(parts.port),
            "username": parts.username,
            "password": parts.password,
            "rdns": True,
        }

    async def close(self) -> None:
        if self._client is not None:
            try:
                await self._client.disconnect()
            except Exception:  # pragma: no cover - shutdown best effort
                pass
            finally:
                self._client = None

    # ------------------------------------------------------------------
    # Fetching
    # ------------------------------------------------------------------
    async def fetch(
        self,
        cursor: dict[str, Any] | None,
        queries: Sequence[SearchQuery],
    ) -> ScrapeBatch:
        client = await self._ensure_client()
        cursor = dict(cursor or {})
        channel_cursors: dict[str, int] = {
            str(channel): int(value) for channel, value in (cursor.get("channels") or {}).items()
        }
        batch = ScrapeBatch(cursor={"channels": channel_cursors})
        self._photo_budget = max(0, self.settings.telegram_max_photos_per_cycle)

        for raw_channel in self.settings.telegram_channels:
            channel = raw_channel.strip()
            if not channel:
                continue
            try:
                entity = await client.get_entity(_entity_ref(channel))
            except Exception as exc:
                self.log.warning("Cannot resolve Telegram channel %s: %s", channel, exc)
                continue

            min_id = channel_cursors.get(channel, 0)
            limit = (
                self.settings.telegram_lookback_limit
                if min_id <= 0
                else self.settings.telegram_batch_limit
            )
            try:
                messages = await client.get_messages(
                    entity,
                    limit=max(1, limit),
                    min_id=min_id,
                )
            except Exception as exc:
                if errors is not None and isinstance(exc, errors.FloodWaitError):
                    seconds = int(getattr(exc, "seconds", 0) or 0)
                    self.log.warning(
                        "FloodWait on %s: Telegram asks for %ss; skipping this cycle", channel, seconds
                    )
                else:
                    self.log.warning("Cannot fetch messages from %s: %s", channel, exc)
                continue

            if not messages:
                continue

            highest_id = min_id
            for message in sorted(messages, key=lambda item: item.id):
                highest_id = max(highest_id, message.id)
                text = (message.message or "").strip()
                if not text:
                    continue
                if queries and not filter_by_queries(text, queries):
                    continue

                photos: list[str] = []
                photo_path = await self._maybe_download_photo(client, message, entity)
                if photo_path:
                    photos.append(photo_path)

                published_at = message.date
                if published_at is not None and published_at.tzinfo is None:
                    published_at = published_at.replace(tzinfo=UTC)

                batch.listings.append(
                    RawListing(
                        source=Source.TG,
                        url=_message_url(entity, message.id),
                        title=_first_line(text),
                        raw_text=text,
                        external_id=f"{entity.id}:{message.id}",
                        photos=photos,
                        published_at=published_at,
                        meta={"channel": channel, "channel_title": getattr(entity, "title", None)},
                    )
                )

            channel_cursors[channel] = highest_id
            batch.cursor = {"channels": channel_cursors}
            await asyncio.sleep(0.2)

        return batch

    async def search(self, query: SearchQuery, limit: int = 10) -> list[RawListing]:
        """Read recent channel history without touching the background cursor."""
        client = await self._ensure_client()
        results: list[RawListing] = []

        for raw_channel in self.settings.telegram_channels:
            channel = raw_channel.strip()
            if not channel:
                continue
            try:
                entity = await client.get_entity(_entity_ref(channel))
                messages = await client.get_messages(entity, limit=100)
            except Exception as exc:
                self.log.warning("Search failed for %s: %s", channel, exc)
                continue

            for message in messages or []:
                text = (message.message or "").strip()
                if not text:
                    continue
                if not filter_by_queries(text, [query]):
                    continue
                published_at = message.date
                if published_at is not None and published_at.tzinfo is None:
                    published_at = published_at.replace(tzinfo=UTC)
                results.append(
                    RawListing(
                        source=Source.TG,
                        url=_message_url(entity, message.id),
                        title=_first_line(text),
                        raw_text=text,
                        external_id=f"{entity.id}:{message.id}",
                        published_at=published_at,
                        meta={"channel": channel},
                    )
                )
                if len(results) >= limit:
                    return results
        return results

    async def _maybe_download_photo(self, client: Any, message: Any, entity: Any) -> str | None:
        if not self.settings.telegram_download_photos or self._photo_budget <= 0:
            return None
        if not getattr(message, "photo", None):
            return None
        file_info = getattr(message, "file", None)
        size = getattr(file_info, "size", None)
        if size and size > self.settings.telegram_max_photo_mb * 1024 * 1024:
            self.log.debug("Skipping oversized photo (%s bytes) in %s", size, entity.id)
            return None

        path = self._media_dir / f"tg_{entity.id}_{message.id}.jpg"
        if path.exists() and path.stat().st_size > 0:
            self._photo_budget -= 1
            return str(path)
        try:
            downloaded = await client.download_media(message, file=str(path))
        except Exception as exc:  # photo is optional, never fail the listing
            self.log.debug("Photo download failed for %s/%s: %s", entity.id, message.id, exc)
            return None
        self._photo_budget -= 1
        return str(downloaded) if downloaded else None


def _entity_ref(channel: str) -> str | int:
    """Accept ``@name``, ``name``, ``t.me/name`` and numeric ids."""
    cleaned = channel.strip()
    for prefix in ("https://t.me/", "http://t.me/", "t.me/"):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix) :]
    cleaned = cleaned.split("?")[0].strip("/")
    if cleaned.startswith("@"):
        cleaned = cleaned[1:]
    if cleaned.lstrip("-").isdigit():
        return int(cleaned)
    return cleaned


def _message_url(entity: Any, message_id: int) -> str:
    username = getattr(entity, "username", None)
    if username:
        return f"https://t.me/{username}/{message_id}"
    return f"https://t.me/c/{entity.id}/{message_id}"


def _first_line(text: str) -> str:
    for line in text.splitlines():
        cleaned = line.strip(" \t•·-—*#")
        if cleaned:
            return cleaned[:300]
    return text[:300]


__all__ = ["TelegramScraper"]

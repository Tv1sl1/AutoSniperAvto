"""VKontakte scraper — public community walls + global newsfeed search."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any

from config.logger import get_logger
from config.settings import Settings
from database.models import Source
from scrapers.base import BaseScraper, RawListing, ScrapeBatch, SearchQuery, filter_by_queries
from services.net import AuthError, HttpClient, NetworkError, RateLimiter, ScraperError
from services.parser_engine import canonical_city

logger = get_logger(__name__)

VK_API_URL = "https://api.vk.com/method"
_MAX_GROUPS_PER_CYCLE = 40
_MAX_GROUPS_FOR_SEARCH = 40
_MAX_QUERIES_PER_CYCLE = 10
_SEARCH_LOOKBACK_DAYS = 30


class VKScraper(BaseScraper):
    name = "vk"
    supports_search = True
    expand_search_queries = False

    def __init__(self, settings: Settings) -> None:
        super().__init__(settings)
        self._http: HttpClient | None = None
        self._limiter = RateLimiter(settings.vk_rate_limit_per_second)
        self._group_ids: dict[str, int] = {}
        self._group_cities: dict[int, str | None] = {}
        self._group_meta_loaded = False

    @property
    def enabled(self) -> bool:
        return self.settings.vk_ready

    async def _client(self) -> HttpClient:
        if self._http is None:
            self._http = HttpClient(
                timeout=self.settings.request_timeout_seconds,
                max_retries=self.settings.max_retries,
                backoff_base=self.settings.backoff_base_seconds,
                backoff_max=self.settings.backoff_max_seconds,
                proxies=self.settings.proxies,
                user_agents=self.settings.web_user_agents,
                rate_limiter=self._limiter,
            )
        return self._http

    async def close(self) -> None:
        if self._http is not None:
            await self._http.close()
            self._http = None

    # ------------------------------------------------------------------
    async def fetch(
        self,
        cursor: dict[str, Any] | None,
        queries: Sequence[SearchQuery],
    ) -> ScrapeBatch:
        cursor = dict(cursor or {})
        since = int(cursor.get("since") or 0)
        if since <= 0:
            since = int(time.time()) - max(1, self.settings.vk_initial_lookback_hours) * 3600

        batch = ScrapeBatch(cursor={"since": since})
        max_seen = since
        groups = [group.strip() for group in self.settings.vk_groups if group.strip()]

        if groups:
            await self._load_group_meta()
            for group in groups[:_MAX_GROUPS_PER_CYCLE]:
                try:
                    owner_id = await self._resolve_group(group)
                    items = await self._wall_get(owner_id)
                except AuthError:
                    raise
                except (NetworkError, ScraperError) as exc:
                    self.log.warning("VK group %s failed: %s", group, exc)
                    continue

                for item in items:
                    published = int(item.get("date") or 0)
                    if published < since:
                        continue
                    # Advance the cursor even if the post is filtered out below.
                    max_seen = max(max_seen, published)
                    text = (item.get("text") or "").strip()
                    if not text:
                        continue
                    if queries and not filter_by_queries(text, queries):
                        continue
                    listing = self._to_raw_listing(item)
                    if listing is None:
                        continue
                    if not listing.city:
                        listing.city = self._group_cities.get(owner_id)
                    batch.listings.append(listing)
        else:
            # No communities configured: search the global VK newsfeed.
            expanded_queries = [expanded for query in queries for expanded in query.expand()]
            unique_queries: list[SearchQuery] = []
            seen_labels: set[str] = set()
            for query in expanded_queries:
                label = query.label().lower()
                if label in seen_labels:
                    continue
                seen_labels.add(label)
                unique_queries.append(query)
            for query in unique_queries[:_MAX_QUERIES_PER_CYCLE]:
                try:
                    items = await self._newsfeed_search(query)
                except AuthError:
                    raise
                except (NetworkError, ScraperError) as exc:
                    self.log.warning("VK search for %r failed: %s", query.label(), exc)
                    continue
                for item in items:
                    published = int(item.get("date") or 0)
                    if published < since:
                        continue
                    max_seen = max(max_seen, published)
                    listing = self._to_raw_listing(item)
                    if listing is None:
                        continue
                    batch.listings.append(listing)

        batch.cursor = {"since": max_seen}
        return batch

    async def search(self, query: SearchQuery, limit: int = 10) -> list[RawListing]:
        results: list[RawListing] = []
        seen: set[str] = set()
        candidate_limit = max(limit, 100)
        since = int(time.time()) - _SEARCH_LOOKBACK_DAYS * 86_400
        terms = self._query_terms(query)

        # Global search is best for a concrete model; group walls are scanned
        # separately for fresh regional posts.
        items: list[dict[str, Any]] = []
        seen_posts: set[tuple[int, int]] = set()
        for term in terms[:4]:
            try:
                batch = await self._newsfeed_search(
                    query, count=min(candidate_limit, 200), text=term
                )
            except AuthError:
                raise
            except (NetworkError, ScraperError) as exc:
                self.log.warning("VK global search %r failed: %s", term, exc)
                continue
            for item in batch:
                key = (int(item.get("owner_id") or 0), int(item.get("id") or 0))
                if key in seen_posts or int(item.get("date") or 0) < since:
                    continue
                seen_posts.add(key)
                items.append(item)

        await self._load_owner_cities(
            [item.get("owner_id") for item in items if int(item.get("owner_id") or 0) < 0]
        )
        for item in items:
            listing = self._to_raw_listing(item)
            if listing is None or listing.external_id in seen:
                continue
            if not listing.city:
                listing.city = self._group_cities.get(int(item.get("owner_id") or 0))
            seen.add(listing.external_id or listing.url)
            results.append(listing)
            if len(results) >= candidate_limit:
                break

        groups = [group.strip() for group in self.settings.vk_groups if group.strip()]
        if not groups:
            return results

        await self._load_group_meta()
        for group in groups[:_MAX_GROUPS_FOR_SEARCH]:
            if len(results) >= candidate_limit:
                break
            try:
                owner_id = await self._resolve_group(group)
                items = await self._wall_get(owner_id, count=100)
            except AuthError:
                raise
            except (NetworkError, ScraperError) as exc:
                self.log.warning("VK group search %s failed: %s", group, exc)
                continue

            for item in items:
                published = int(item.get("date") or 0)
                if published < since:
                    continue
                text = (item.get("text") or "").strip()
                if not text or not filter_by_queries(text, [query]):
                    continue
                listing = self._to_raw_listing(item)
                if listing is None or listing.external_id in seen:
                    continue
                if not listing.city:
                    listing.city = self._group_cities.get(owner_id)
                seen.add(listing.external_id or listing.url)
                results.append(listing)
                if len(results) >= candidate_limit:
                    break
        return results

    def _query_terms(self, query: SearchQuery) -> tuple[str, ...]:
        models = list(query.all_models())
        if len(models) <= 1:
            terms = [query.search_label()]
            if models:
                terms.append(models[0])
        else:
            terms = [
                SearchQuery(make=query.make, model=model).search_label()
                for model in models
            ]
            terms.extend(models)
        return tuple(dict.fromkeys(term for term in terms if term))

    # ------------------------------------------------------------------
    # API plumbing
    # ------------------------------------------------------------------
    async def _api(self, method: str, params: dict[str, Any]) -> Any:
        if not self.settings.vk_token:
            raise AuthError("VK_TOKEN is not configured")

        payload = {
            **params,
            "access_token": self.settings.vk_token,
            "v": self.settings.vk_api_version,
        }
        url = f"{VK_API_URL}/{method}"

        for attempt in range(1, 4):
            http = await self._client()
            data = await http.get_json(url, params=payload)
            if "error" not in data:
                return data.get("response")

            error = data.get("error") or {}
            code = int(error.get("error_code") or 0)
            message = error.get("error_msg") or "unknown VK error"

            if code == 6:  # too many requests per second
                await asyncio.sleep(1.5 * attempt)
                continue
            if code in {5, 28}:  # invalid / expired token
                raise AuthError(f"VK authorization failed: {message}")
            if code == 15:  # access denied (private community)
                raise ScraperError(f"VK access denied: {message}")
            raise ScraperError(f"VK API error {code}: {message}")

        raise ScraperError("VK API rate limit was not lifted after 3 attempts")

    async def _resolve_group(self, group: str) -> int:
        cached = self._group_ids.get(group)
        if cached is not None:
            return cached

        cleaned = group.strip().rstrip("/")
        for prefix in ("https://vk.com/", "http://vk.com/", "vk.com/"):
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix) :]
        if cleaned.startswith("-") and cleaned[1:].isdigit():
            owner_id = int(cleaned)
        elif cleaned.isdigit():
            owner_id = -int(cleaned)
        elif cleaned.startswith(("club", "public")) and cleaned[4:].isdigit():
            owner_id = -int(cleaned[4:])
        else:
            response = await self._api("utils.resolveScreenName", {"screen_name": cleaned})
            if not response:
                raise ScraperError(f"Cannot resolve VK community {group!r}")
            owner_id = -int(response["object_id"])

        self._group_ids[group] = owner_id
        return owner_id

    async def _load_owner_cities(self, owner_ids: Sequence[Any]) -> None:
        """Resolve public community cities by owner_id (negative for groups)."""
        ids = sorted({abs(int(owner_id)) for owner_id in owner_ids if owner_id})
        pending = [group_id for group_id in ids if -group_id not in self._group_cities]
        if not pending:
            return
        try:
            response = await self._api(
                "groups.getById",
                {
                    "group_ids": ",".join(str(group_id) for group_id in pending[:100]),
                    "fields": "city,screen_name",
                },
            )
        except AuthError:
            raise
        except ScraperError as exc:
            self.log.warning("Cannot load VK owner metadata: %s", exc)
            return

        groups_data = response.get("groups") if isinstance(response, dict) else None
        for group in groups_data or []:
            if not isinstance(group, dict) or group.get("id") is None:
                continue
            owner_id = -int(group["id"])
            city = (group.get("city") or {}).get("title") if isinstance(group.get("city"), dict) else None
            if not city:
                city = canonical_city(group.get("name") or "")
            self._group_cities[owner_id] = city

    async def _load_group_meta(self) -> None:
        """Resolve configured community cities once, so posts without geo can use them."""
        if self._group_meta_loaded:
            return
        groups = [group.strip() for group in self.settings.vk_groups if group.strip()]
        owner_ids: list[int] = []
        for group in groups:
            try:
                owner_ids.append(await self._resolve_group(group))
            except (AuthError, NetworkError, ScraperError) as exc:
                self.log.warning("Cannot resolve VK group %s for metadata: %s", group, exc)
        if owner_ids:
            await self._load_owner_cities(owner_ids)
        self._group_meta_loaded = True
        self.log.info(
            "VK group metadata loaded: %s group(s), %s with city",
            len(owner_ids),
            sum(1 for city in self._group_cities.values() if city),
        )

    async def _wall_get(
        self, owner_id: int, *, count: int | None = None, offset: int = 0
    ) -> list[dict[str, Any]]:
        response = await self._api(
            "wall.get",
            {
                "owner_id": owner_id,
                "count": max(1, min(count or self.settings.vk_batch_limit, 100)),
                "offset": max(0, offset),
                "filter": "owner",
                "extended": 0,
            },
        )
        if not isinstance(response, dict):
            return []
        return list(response.get("items") or [])

    async def _wall_search(
        self, owner_id: int, query: str, *, count: int = 100, offset: int = 0
    ) -> list[dict[str, Any]]:
        response = await self._api(
            "wall.search",
            {
                "owner_id": owner_id,
                "query": query,
                "count": max(1, min(count, 100)),
                "offset": max(0, offset),
                "extended": 0,
            },
        )
        if not isinstance(response, dict):
            return []
        return list(response.get("items") or [])

    async def _newsfeed_search(
        self, query: SearchQuery, count: int = 30, *, text: str | None = None
    ) -> list[dict[str, Any]]:
        response = await self._api(
            "newsfeed.search",
            {
                "q": text or query.search_label(),
                "count": max(1, min(count, 200)),
                "extended": 0,
            },
        )
        if not isinstance(response, dict):
            return []
        return list(response.get("items") or [])

    # ------------------------------------------------------------------
    # Mapping
    # ------------------------------------------------------------------
    def _to_raw_listing(self, item: dict[str, Any]) -> RawListing | None:
        post_id = item.get("id")
        owner_id = item.get("owner_id")
        if post_id is None or owner_id is None:
            return None
        text = (item.get("text") or "").strip()
        if not text or _is_review_post(text):
            return None

        photos: list[str] = []
        for attachment in item.get("attachments") or []:
            if not isinstance(attachment, dict) or attachment.get("type") != "photo":
                continue
            photo = attachment.get("photo") or {}
            sizes = photo.get("sizes") or []
            if not sizes:
                continue
            best = max(
                sizes,
                key=lambda size: int(size.get("width") or 0) * int(size.get("height") or 0),
            )
            url = best.get("url")
            if url:
                photos.append(str(url))

        city = None
        geo = item.get("geo") or {}
        place = geo.get("place") or {}
        if isinstance(place, dict):
            city = place.get("title")

        published = item.get("date")
        published_at = (
            datetime.fromtimestamp(int(published), tz=UTC) if published else None
        )

        return RawListing(
            source=Source.VK,
            url=f"https://vk.com/wall{owner_id}_{post_id}",
            title=_first_line(text),
            raw_text=text,
            external_id=f"{owner_id}_{post_id}",
            city=city,
            photos=photos,
            published_at=published_at,
            meta={"owner_id": owner_id, "post_id": post_id},
        )


def _first_line(text: str) -> str:
    for line in text.splitlines():
        cleaned = line.strip(" \t•·-—*#")
        if cleaned:
            return cleaned[:300]
    return text[:300]


def _is_review_post(text: str) -> bool:
    """Skip video reviews/clips that mention a model and a price but sell nothing."""
    lowered = text.lower()
    if "обзор" not in lowered:
        return False
    sale_markers = ("продам", "продаю", "продаётся", "продается", "торг", "цена")
    return not any(marker in lowered for marker in sale_markers)


__all__ = ["VKScraper"]

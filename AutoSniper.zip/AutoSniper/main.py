"""Application entrypoint.

Usage::

    python main.py                 # bot + background scraping
    python main.py --once          # run a single scraping cycle and exit
    python main.py --doctor        # validate configuration, DB and bot token
    python main.py --init-db       # create tables (development convenience)
    python main.py --migrate       # alembic upgrade head
"""

from __future__ import annotations

import argparse
import asyncio
import dataclasses
import signal
import subprocess
import sys

from sqlalchemy import inspect

from bot.app import create_bot, create_dispatcher, set_bot_commands
from config.logger import get_logger, setup_logging
from config.settings import (
    PROJECT_ROOT,
    ConfigError,
    Settings,
    normalize_database_url,
)
from database.session import Database
from scrapers.registry import build_scrapers
from services.notifier import TelegramNotifier
from services.orchestrator import ScraperOrchestrator
from services.pipeline import IngestionPipeline

logger = get_logger("main")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="autosniper",
        description="Async car-listing scraper with an interactive Telegram bot.",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env (default: ./.env)")
    parser.add_argument("--log-level", default=None, help="Override LOG_LEVEL (DEBUG/INFO/WARNING)")
    parser.add_argument("--init-db", action="store_true", help="Create tables without migrations")
    parser.add_argument("--migrate", action="store_true", help="Run `alembic upgrade head`")
    parser.add_argument("--once", action="store_true", help="Run one scraping cycle and exit")
    parser.add_argument("--no-notify", action="store_true", help="Do not send Telegram notifications (with --once)")
    parser.add_argument("--doctor", action="store_true", help="Check configuration, database and bot token")
    return parser.parse_args(argv)


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------
def _apply_log_level(settings: Settings, override: str | None) -> Settings:
    if override:
        settings = dataclasses.replace(settings, log_level=override.upper())
    return settings


def _configure_logging(settings: Settings) -> None:
    setup_logging(
        level=settings.log_level,
        log_file=settings.log_file,
        max_bytes=settings.log_max_bytes,
        backup_count=settings.log_backup_count,
    )


def _mask_dsn(url: str) -> str:
    if "@" not in url:
        return url
    scheme, _, rest = url.partition("://")
    _, _, host = rest.rpartition("@")
    return f"{scheme}://***@{host}"


async def _table_names(db: Database) -> list[str]:
    async with db.engine.connect() as connection:
        return await connection.run_sync(lambda sync_conn: inspect(sync_conn).get_table_names())


async def _ensure_schema(db: Database, settings: Settings) -> None:
    tables = await _table_names(db)
    if "listings" in tables and "users" in tables:
        return
    if settings.auto_create_tables:
        logger.warning("AUTO_CREATE_TABLES=true — creating schema with metadata.create_all()")
        await db.create_all()
        return
    raise ConfigError(
        "Database schema is missing. Run `python main.py --init-db` for development "
        "or `alembic upgrade head` for migrations."
    )


# ---------------------------------------------------------------------------
# Doctor
# ---------------------------------------------------------------------------
async def run_doctor(settings: Settings) -> int:
    print("AutoSniper configuration check")
    print("=" * 52)
    print(f"Project root : {PROJECT_ROOT}")
    print(f"Database     : {_mask_dsn(normalize_database_url(settings.database_url))}")
    print(f"Scrapers     : {', '.join(settings.scrapers_enabled) or 'none'}")
    print()

    errors, warnings = settings.validate()
    for warning in warnings:
        print(f"[WARN] {warning}")
    for error in errors:
        print(f"[FAIL] {error}")

    db_ok = False
    db = Database.from_settings(settings)
    try:
        db_ok = await db.healthcheck()
        if db_ok:
            print("[OK]   Database connection")
            tables = await _table_names(db)
            if tables:
                print(f"[OK]   Tables: {', '.join(sorted(tables))}")
            else:
                print("[WARN] Database is reachable but has no tables (run --init-db or --migrate)")
        else:
            print("[FAIL] Database connection failed")
    except Exception as exc:
        print(f"[FAIL] Database error: {exc}")
    finally:
        await db.close()
    print()

    if settings.bot_token:
        bot = create_bot(settings)
        try:
            me = await asyncio.wait_for(bot.get_me(), timeout=15)
            print(f"[OK]   Bot token valid: @{me.username} ({me.id})")
        except Exception as exc:
            print(f"[FAIL] Bot token check failed: {exc}")
            errors.append(str(exc))
        finally:
            await bot.session.close()
    else:
        print("[WARN] BOT_TOKEN is empty — only the scraping engine could run")

    print()
    if settings.telegram_ready:
        print(f"[OK]   Telegram scraper: {len(settings.telegram_channels)} channel(s) configured")
    else:
        print("[WARN] Telegram scraper is not configured")
    if settings.vk_ready:
        print(f"[OK]   VK scraper: {len(settings.vk_groups)} group(s), token present")
    else:
        print("[WARN] VK scraper is not configured")
    if settings.web_ready:
        print(f"[OK]   Web scraper: {len(settings.web_targets)} target(s)")
    else:
        print("[WARN] Web scraper is not configured")

    ok = db_ok and not errors
    print()
    print("Result:", "READY" if ok else "NOT READY")
    return 0 if ok else 1


# ---------------------------------------------------------------------------
# Migrations
# ---------------------------------------------------------------------------
def run_migrations() -> int:
    logger.info("Running `alembic upgrade head` in %s", PROJECT_ROOT)
    result = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
    )
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    return result.returncode


# ---------------------------------------------------------------------------
# Runtime
# ---------------------------------------------------------------------------
async def run_once(orchestrator: ScraperOrchestrator) -> int:
    logger.info("Running a single scraping cycle")
    report = await orchestrator.run_cycle()
    print(f"Cycle finished in {report.duration:.1f}s")
    for outcome in report.outcomes:
        if outcome.skipped:
            status = "SKIPPED"
        elif outcome.ok:
            status = "OK"
        else:
            status = "FAILED"
        line = (
            f"  {outcome.name:<10} {status:<8} found={outcome.found} "
            f"new={outcome.created} queued={outcome.notifications}"
        )
        if outcome.error:
            line += f" error={outcome.error}"
        print(line)
    print(
        f"Total: found={report.total_found} new={report.total_created} "
        f"queued={report.total_notifications}"
    )
    return 0 if not report.failures else 1


def _install_stop_handlers(stop_event: asyncio.Event) -> None:
    loop = asyncio.get_running_loop()

    def _set_stop(*_args: object) -> None:
        stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _set_stop)
        except (NotImplementedError, RuntimeError, ValueError):
            # Windows: asyncio does not support add_signal_handler.
            try:
                signal.signal(sig, lambda *_a: loop.call_soon_threadsafe(_set_stop))
            except (ValueError, OSError):  # pragma: no cover - non-main thread
                pass


async def run_application(
    settings: Settings,
    db: Database,
    orchestrator: ScraperOrchestrator,
    notifier: TelegramNotifier,
) -> int:
    bot = notifier.bot
    dispatcher = create_dispatcher(
        db=db,
        settings=settings,
        orchestrator=orchestrator,
        notifier=notifier,
    )

    me = await bot.get_me()
    logger.info("Bot @%s (%s) is starting", me.username, me.id)
    await set_bot_commands(bot, settings)

    stop_event = asyncio.Event()
    _install_stop_handlers(stop_event)

    polling_task = asyncio.create_task(
        dispatcher.start_polling(
            bot,
            allowed_updates=dispatcher.resolve_used_update_types(),
            handle_signals=False,
        ),
        name="aiogram-polling",
    )
    scraping_task = asyncio.create_task(orchestrator.run_forever(), name="scraper-loop")
    stop_task = asyncio.create_task(stop_event.wait(), name="stop-signal")

    logger.info("AutoSniper is running — press Ctrl+C to stop")
    try:
        done, pending = await asyncio.wait(
            {polling_task, scraping_task, stop_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in done:
            if task is stop_task:
                logger.info("Shutdown signal received")
                continue
            if task.cancelled():
                continue
            exception = task.exception()
            if exception is not None:
                logger.error("Task %s stopped with error: %s", task.get_name(), exception)
            else:
                logger.info("Task %s finished", task.get_name())
    finally:
        orchestrator.stop()
        for task in (polling_task, scraping_task, stop_task):
            if not task.done():
                task.cancel()
        await asyncio.gather(polling_task, scraping_task, stop_task, return_exceptions=True)
        logger.info("AutoSniper stopped")
    return 0


async def amain(args: argparse.Namespace) -> int:
    settings = _apply_log_level(Settings.load(args.env_file), args.log_level)
    settings.ensure_directories()
    _configure_logging(settings)

    if args.migrate:
        return run_migrations()

    if args.init_db:
        db = Database.from_settings(settings)
        try:
            await db.create_all()
            print(f"Schema created in {_mask_dsn(settings.database_url)}")
        finally:
            await db.close()
        return 0

    if args.doctor:
        return await run_doctor(settings)

    errors, warnings = settings.validate()
    if args.once and args.no_notify:
        errors = [error for error in errors if not error.startswith("BOT_TOKEN")]
    for warning in warnings:
        logger.warning(warning)
    if errors:
        for error in errors:
            logger.error(error)
        logger.error("Configuration is invalid — fix .env and run `python main.py --doctor`.")
        return 2

    db = Database.from_settings(settings)
    try:
        if not await db.healthcheck():
            logger.error("Database is unreachable: %s", _mask_dsn(settings.database_url))
            return 2
        await _ensure_schema(db, settings)

        scrapers = build_scrapers(settings)
        notifier: TelegramNotifier | None = None
        bot = None
        if args.once and args.no_notify:
            logger.info("Notification delivery disabled (--no-notify)")
        else:
            bot = create_bot(settings)
            notifier = TelegramNotifier(
                bot,
                rate_per_second=settings.notify_rate_per_second,
                allowed_link_domains=settings.allowed_link_domains,
            )

        pipeline = IngestionPipeline(db, settings=settings, notifier=notifier)
        orchestrator = ScraperOrchestrator(
            db=db,
            pipeline=pipeline,
            scrapers=scrapers,
            settings=settings,
        )

        try:
            if args.once:
                return await run_once(orchestrator)
            assert notifier is not None
            return await run_application(settings, db, orchestrator, notifier)
        finally:
            await orchestrator.close()
            if bot is not None:
                await bot.session.close()
    finally:
        await db.close()


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        return asyncio.run(amain(args))
    except KeyboardInterrupt:
        print("\nStopped by user.")
        return 130
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # pragma: no cover - last resort
        logger.exception("Fatal error: %s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

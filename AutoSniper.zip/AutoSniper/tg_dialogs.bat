@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoSniper - Telegram dialogs

set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"

"%PYTHON%" --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    pause
    exit /b 1
)

echo Channels and groups of the scraper account, with IDs.
echo Copy an ID or @username into TELEGRAM_CHANNELS in .env.
echo.
"%PYTHON%" scripts\tg_dialogs.py
echo.
echo Press any key to close.
pause >nul

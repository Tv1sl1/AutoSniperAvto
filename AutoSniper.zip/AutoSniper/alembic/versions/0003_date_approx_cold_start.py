"""approximate listing dates and cold-start subscriptions

Revision ID: 0003
Revises: 0002
Create Date: 2026-10-26

Adds ``listings.date_approx`` and ``subscriptions.cold_start_done``.
Existing subscriptions are marked as already warmed up; only new rows start
with ``cold_start_done = false``.
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("subscriptions", schema=None) as batch_op:
        batch_op.add_column(
            sa.Column(
                "cold_start_done",
                sa.Boolean(),
                server_default=sa.text("true"),
                nullable=False,
            )
        )
    with op.batch_alter_table("listings", schema=None) as batch_op:
        batch_op.add_column(
            sa.Column(
                "date_approx",
                sa.Boolean(),
                server_default=sa.text("false"),
                nullable=False,
            )
        )


def downgrade() -> None:
    with op.batch_alter_table("listings", schema=None) as batch_op:
        batch_op.drop_column("date_approx")
    with op.batch_alter_table("subscriptions", schema=None) as batch_op:
        batch_op.drop_column("cold_start_done")

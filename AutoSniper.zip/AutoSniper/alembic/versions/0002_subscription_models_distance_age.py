"""subscription models, distance and publication age

Revision ID: 0002
Revises: 0001
Create Date: 2026-10-25

Adds multi-model search, a city-radius filter and the per-subscription
publication-age limit.
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

JSON_TYPE = sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), "postgresql")


def upgrade() -> None:
    with op.batch_alter_table("subscriptions", schema=None) as batch_op:
        batch_op.add_column(
            sa.Column(
                "models",
                JSON_TYPE,
                server_default=sa.text("'[]'"),
                nullable=False,
            )
        )
        batch_op.add_column(sa.Column("max_distance_km", sa.Integer(), nullable=True))
        batch_op.add_column(
            sa.Column(
                "max_age_days",
                sa.Integer(),
                server_default=sa.text("7"),
                nullable=True,
            )
        )
        batch_op.create_check_constraint(
            "ck_subscriptions_max_distance_range",
            "max_distance_km IS NULL OR (max_distance_km >= 0 AND max_distance_km <= 5000)",
        )
        batch_op.create_check_constraint(
            "ck_subscriptions_max_age_range",
            "max_age_days IS NULL OR (max_age_days >= 0 AND max_age_days <= 3650)",
        )


def downgrade() -> None:
    with op.batch_alter_table("subscriptions", schema=None) as batch_op:
        batch_op.drop_constraint("ck_subscriptions_max_age_range", type_="check")
        batch_op.drop_constraint("ck_subscriptions_max_distance_range", type_="check")
        batch_op.drop_column("max_age_days")
        batch_op.drop_column("max_distance_km")
        batch_op.drop_column("models")

"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-10-25

Creates the five core tables: users, subscriptions, listings, notifications and
scraper_states. The ``source`` column is stored as VARCHAR(16) on every backend
(native Enum only on PostgreSQL would complicate migrations).
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

JSON_TYPE = sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), "postgresql")


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("user_id", sa.BigInteger(), autoincrement=False, nullable=False),
        sa.Column("username", sa.String(length=64), nullable=True),
        sa.Column("first_name", sa.String(length=128), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("user_id"),
    )
    op.create_index("ix_users_is_active", "users", ["is_active"], unique=False)

    op.create_table(
        "subscriptions",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("make", sa.String(length=64), nullable=False),
        sa.Column("model", sa.String(length=64), nullable=True),
        sa.Column("max_price", sa.Integer(), nullable=True),
        sa.Column("city", sa.String(length=64), nullable=True),
        sa.Column("year_min", sa.Integer(), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.CheckConstraint(
            "max_price IS NULL OR max_price > 0",
            name="ck_subscriptions_max_price_positive",
        ),
        sa.CheckConstraint(
            "year_min IS NULL OR (year_min >= 1950 AND year_min <= 2100)",
            name="ck_subscriptions_year_min_range",
        ),
        sa.ForeignKeyConstraint(["user_id"], ["users.user_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_subscriptions_user_id", "subscriptions", ["user_id"], unique=False)
    op.create_index("ix_subscriptions_make", "subscriptions", ["make"], unique=False)
    op.create_index("ix_subscriptions_is_active", "subscriptions", ["is_active"], unique=False)
    op.create_index(
        "ix_subscriptions_user_active", "subscriptions", ["user_id", "is_active"], unique=False
    )
    op.create_index(
        "ix_subscriptions_active_make", "subscriptions", ["is_active", "make"], unique=False
    )

    op.create_table(
        "listings",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("hash_id", sa.String(length=64), nullable=False),
        sa.Column(
            "source",
            sa.Enum(
                "TG",
                "VK",
                "AVITO",
                "AUTORU",
                "RSS",
                name="source",
                native_enum=False,
                length=16,
            ),
            nullable=False,
        ),
        sa.Column("external_id", sa.String(length=128), nullable=True),
        sa.Column("title", sa.String(length=512), nullable=False),
        sa.Column("price", sa.Integer(), nullable=True),
        sa.Column("city", sa.String(length=64), nullable=True),
        sa.Column("url", sa.String(length=1024), nullable=False),
        sa.Column("photos", JSON_TYPE, nullable=False),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("raw_text", sa.Text(), nullable=False),
        sa.Column("make", sa.String(length=64), nullable=True),
        sa.Column("model", sa.String(length=64), nullable=True),
        sa.Column("year", sa.Integer(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("source", "external_id", name="uq_listings_source_external_id"),
    )
    op.create_index("ix_listings_hash_id", "listings", ["hash_id"], unique=True)
    op.create_index("ix_listings_source", "listings", ["source"], unique=False)
    op.create_index("ix_listings_price", "listings", ["price"], unique=False)
    op.create_index("ix_listings_city", "listings", ["city"], unique=False)
    op.create_index("ix_listings_published_at", "listings", ["published_at"], unique=False)
    op.create_index("ix_listings_make", "listings", ["make"], unique=False)
    op.create_index("ix_listings_created_at", "listings", ["created_at"], unique=False)
    op.create_index(
        "ix_listings_source_published", "listings", ["source", "published_at"], unique=False
    )
    op.create_index("ix_listings_make_model", "listings", ["make", "model"], unique=False)

    op.create_table(
        "notifications",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("listing_id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=True),
        sa.Column("sent_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("attempts", sa.Integer(), server_default=sa.text("0"), nullable=False),
        sa.Column("last_error", sa.String(length=512), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["user_id"], ["users.user_id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["listing_id"], ["listings.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["subscription_id"], ["subscriptions.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("user_id", "listing_id", name="uq_notifications_user_listing"),
    )
    op.create_index("ix_notifications_user_id", "notifications", ["user_id"], unique=False)
    op.create_index("ix_notifications_listing_id", "notifications", ["listing_id"], unique=False)
    op.create_index("ix_notifications_sent_at", "notifications", ["sent_at"], unique=False)
    op.create_index(
        "ix_notifications_pending", "notifications", ["sent_at", "created_at"], unique=False
    )

    op.create_table(
        "scraper_states",
        sa.Column("name", sa.String(length=64), nullable=False),
        sa.Column("cursor", JSON_TYPE, nullable=False),
        sa.Column("last_run_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_success_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column(
            "consecutive_failures", sa.Integer(), server_default=sa.text("0"), nullable=False
        ),
        sa.Column("total_listings", sa.Integer(), server_default=sa.text("0"), nullable=False),
        sa.PrimaryKeyConstraint("name"),
    )


def downgrade() -> None:
    op.drop_table("scraper_states")

    op.drop_index("ix_notifications_pending", table_name="notifications")
    op.drop_index("ix_notifications_sent_at", table_name="notifications")
    op.drop_index("ix_notifications_listing_id", table_name="notifications")
    op.drop_index("ix_notifications_user_id", table_name="notifications")
    op.drop_table("notifications")

    op.drop_index("ix_listings_make_model", table_name="listings")
    op.drop_index("ix_listings_source_published", table_name="listings")
    op.drop_index("ix_listings_created_at", table_name="listings")
    op.drop_index("ix_listings_make", table_name="listings")
    op.drop_index("ix_listings_published_at", table_name="listings")
    op.drop_index("ix_listings_city", table_name="listings")
    op.drop_index("ix_listings_price", table_name="listings")
    op.drop_index("ix_listings_source", table_name="listings")
    op.drop_index("ix_listings_hash_id", table_name="listings")
    op.drop_table("listings")

    op.drop_index("ix_subscriptions_active_make", table_name="subscriptions")
    op.drop_index("ix_subscriptions_user_active", table_name="subscriptions")
    op.drop_index("ix_subscriptions_is_active", table_name="subscriptions")
    op.drop_index("ix_subscriptions_make", table_name="subscriptions")
    op.drop_index("ix_subscriptions_user_id", table_name="subscriptions")
    op.drop_table("subscriptions")

    op.drop_index("ix_users_is_active", table_name="users")
    op.drop_table("users")

"""listing generation, transmission and engine volume

Revision ID: 0004
Revises: 0003
Create Date: 2026-10-26

These fields are normalized from free-form ads (slang, typos) and exposed to
future filters; matching still uses make/model/year.
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0004"
down_revision: Union[str, None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("listings", schema=None) as batch_op:
        batch_op.add_column(sa.Column("generation", sa.String(length=32), nullable=True))
        batch_op.add_column(sa.Column("transmission", sa.String(length=16), nullable=True))
        batch_op.add_column(sa.Column("engine_volume", sa.Float(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("listings", schema=None) as batch_op:
        batch_op.drop_column("engine_volume")
        batch_op.drop_column("transmission")
        batch_op.drop_column("generation")

@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoSniper - diagnostics

set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"

"%PYTHON%" --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    pause
    exit /b 1
)

"%PYTHON%" main.py --doctor
echo.
echo Press any key to close.
pause >nul

@echo off
title AutoSniper Bot - System Check
echo ========================================
echo TELEGRAM BOT OPTIMIZATION CHECK
echo Project: D:\AutoSniper
echo Date: %date% %time%
echo ========================================
echo.

REM 1. ОЦЕНКА ТВОЁГО ЖЕЛЕЗА (RAM, GPU)
echo 1. Checking system hardware (for model optimization)...
wmic OS get FreePhysicalMemory /value > temp.txt 2>&1
set /p RAM_MEGA=temp.txt "%"FreePhysicalMemory"%"
set /a RAM_GB=%RAM_MEGA%/1024
echo System RAM: %RAM_GB% GB

REM Check graphics card VRAM (if available)
wmic Path Win32_VideoController get VideoProcessorAdapter,DisplayAdapterVRAM
echo.

REM 2. Проверка доступных моделей в Ollama
echo 2. Checking Ollama models...
ollama list | findstr "qwen" > models_available.txt
echo Available models saved in D:\AutoSniper\models_available.txt
echo.

REM 3. Установка оптимальной модели под твое железо
echo 3. Installing/recommending best model based on your hardware:
REM    - If RAM >= 16GB → Use qwen2.5:7b-instruct (4.7GB) for better quality
REM    - If RAM < 16GB → Use qwen3.5:4b (3.3GB) for faster performance!

REM Download if needed
ollama pull qwen3.5:4b > install_status.txt 2>&1
echo Model status saved in D:\AutoSniper\install_status.txt
echo.

REM 4. Проверка Goose и Python
echo 4. Checking Python and Goose version...
python --version | findstr "Python"
goose doctor | findstr "ready" > goose_status.txt
echo Goose status: %errorlevel% (0 = ready)
echo.

REM 5. Финальная проверка контекста
echo 5. Loading project context from D:\AutoSniper\context.md...
type D:\AutoSniper\context.md | findstr "MODELS CONFIGURATION"
echo.
echo ========================================
echo ✅ System check complete!
echo Ready for production work with qwen3.5:4b
echo Open config-goose.bat to apply optimal settings
echo ========================================
del temp.txt >nul 2>&1
pause

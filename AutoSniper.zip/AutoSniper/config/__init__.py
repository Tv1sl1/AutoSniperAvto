"""Configuration package: environment-driven settings and logging helpers."""

from config.logger import get_logger, setup_logging
from config.settings import (
    PROJECT_ROOT,
    ConfigError,
    Settings,
    get_settings,
    normalize_database_url,
    set_settings,
)

__all__ = [
    "ConfigError",
    "PROJECT_ROOT",
    "Settings",
    "get_logger",
    "get_settings",
    "normalize_database_url",
    "set_settings",
    "setup_logging",
]

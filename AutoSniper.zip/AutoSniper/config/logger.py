"""Logging configuration: console + rotating file, UTF-8 safe on Windows."""

from __future__ import annotations

import logging
import logging.handlers
import re
import sys
from pathlib import Path

LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-28s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
_CONFIGURED = False

_BOT_TOKEN_RE = re.compile(r"\b\d{8,12}:[A-Za-z0-9_-]{25,}\b")
_VK_TOKEN_RE = re.compile(r"\bvk1\.[A-Za-z0-9._-]{20,}\b")
_SECRET_KV_RE = re.compile(
    r"(?i)\b(token|access_token|api_hash|secret|authorization)\b(\s*[=:]\s*)(\S+)"
)


class RedactingFormatter(logging.Formatter):
    """Hide common credentials even if a third-party logger leaks them."""

    def format(self, record: logging.LogRecord) -> str:
        text = super().format(record)
        text = _BOT_TOKEN_RE.sub("<bot-token>", text)
        text = _VK_TOKEN_RE.sub("<vk-token>", text)
        return _SECRET_KV_RE.sub(r"\1\2<redacted>", text)

# Chatty third-party loggers that would otherwise flood the log file.
_NOISY_LOGGERS = {
    "aiogram.event": logging.WARNING,
    "aiogram.dispatcher": logging.WARNING,
    "telethon.network.mtprotosender": logging.WARNING,
    "telethon.client.updates": logging.WARNING,
    "aiohttp.access": logging.WARNING,
    "asyncio": logging.WARNING,
}


def setup_logging(
    *,
    level: str = "INFO",
    log_file: str | Path | None = "logs/autosniper.log",
    max_bytes: int = 5_000_000,
    backup_count: int = 5,
    console: bool = True,
) -> None:
    """Configure the root logger once per process."""
    global _CONFIGURED
    numeric_level = getattr(logging, str(level).upper(), logging.INFO)

    root = logging.getLogger()
    if _CONFIGURED:
        root.setLevel(numeric_level)
        return

    # Windows consoles default to cp1251 in some setups and choke on emoji.
    if console and hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
        except (ValueError, OSError):  # pragma: no cover - environment dependent
            pass

    formatter = RedactingFormatter(LOG_FORMAT, datefmt=DATE_FORMAT)
    handlers: list[logging.Handler] = []

    if console:
        stream_handler = logging.StreamHandler(stream=sys.stdout)
        stream_handler.setFormatter(formatter)
        handlers.append(stream_handler)

    if log_file:
        path = Path(log_file)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.handlers.RotatingFileHandler(
                path,
                maxBytes=max_bytes,
                backupCount=backup_count,
                encoding="utf-8",
            )
            file_handler.setFormatter(formatter)
            handlers.append(file_handler)
        except OSError as exc:  # pragma: no cover - permissions dependent
            logging.getLogger(__name__).warning("Cannot open log file %s: %s", path, exc)

    for handler in handlers:
        root.addHandler(handler)
    root.setLevel(numeric_level)

    for name, noisy_level in _NOISY_LOGGERS.items():
        logging.getLogger(name).setLevel(noisy_level)

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced logger."""
    return logging.getLogger(name)


__all__ = ["get_logger", "setup_logging"]

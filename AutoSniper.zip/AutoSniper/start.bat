@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoSniper

set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"

"%PYTHON%" --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    echo Install Python 3.11+ from https://www.python.org/downloads/
    echo and enable "Add python.exe to PATH".
    pause
    exit /b 1
)

echo Starting AutoSniper...
echo.
"%PYTHON%" main.py
echo.
echo AutoSniper stopped. Press any key to close.
pause >nul

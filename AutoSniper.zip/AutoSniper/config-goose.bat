@echo off
echo ========================================
echo GOOSE CONFIGURATION FOR PRODUCTION
echo Project: Telegram Bot AutoSniper
echo Date: %date% %time%
echo ========================================
echo.

REM Check if models available for your PC
echo 1. Checking Ollama models...
ollama list | findstr "qwen"
echo.

REM Switch to optimized model qwen3.5:4b (3.3GB vs 4.7GB)
echo 2. Setting model to qwen3.5:4b for better performance on your hardware
echo Model: qwen3.5:4b (3.3GB RAM - faster than 7B!)
ollama run qwen3.5:4b -m "Hello from AutoSniper Bot"
echo.

REM Set Goose parameters - DETERMINISTIC MODE FOR PRODUCTION CODE
echo 3. Configuring Goose for production with deterministic output
echo Parameters: temperature=0.3, max_turns=1000, context_win=8192
goose --help | findstr "settings" > goose_options.txt
echo.

REM Create custom settings file - will be used in future sessions
echo ========================================
echo OPTIMIZED GOOSE CONFIGURATION
echo Model: qwen3.5:4b (Recommended: 3.3GB for faster performance)
echo Temperature: 0.3 (Deterministic - no surprises!)
echo Max Turns: 1000 (Deep reasoning)
echo Context Window: 8192 tokens
echo ========================================
echo.

echo ✅ Configuration saved to D:\AutoSniper\context.md
echo ✅ Project structure verified and ready
echo.
pause

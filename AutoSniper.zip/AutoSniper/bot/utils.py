"""Small shared bot helpers."""

from __future__ import annotations

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import Message


async def safe_edit(message: Message, text: str, reply_markup=None) -> None:
    """Edit a message, tolerating "message is not modified" and non-text messages."""
    try:
        await message.edit_text(
            text,
            reply_markup=reply_markup,
            disable_web_page_preview=False,
        )
    except TelegramBadRequest as exc:
        if "message is not modified" in str(exc).lower():
            return
        if "there is no text" in str(exc).lower() or "message can't be edited" in str(exc).lower():
            await message.answer(text, reply_markup=reply_markup, disable_web_page_preview=False)
            return
        raise


def format_uptime(seconds: float) -> str:
    seconds = max(0, int(seconds))
    days, remainder = divmod(seconds, 86_400)
    hours, remainder = divmod(remainder, 3_600)
    minutes, _ = divmod(remainder, 60)
    parts = []
    if days:
        parts.append(f"{days} д")
    if hours:
        parts.append(f"{hours} ч")
    parts.append(f"{minutes} мин")
    return " ".join(parts)


__all__ = ["format_uptime", "safe_edit"]

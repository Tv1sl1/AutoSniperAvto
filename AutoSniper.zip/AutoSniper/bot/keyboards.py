"""Inline keyboards and callback wiring."""

from __future__ import annotations

from collections.abc import Sequence

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.callbacks import (
    AddSubCB,
    MenuCB,
    PageCB,
    SearchCB,
    SettingsCB,
    SubCB,
)
from database.models import Subscription
from services.formatting import format_subscription_line

POPULAR_BRANDS: tuple[str, ...] = (
    "BMW",
    "Mercedes-Benz",
    "Toyota",
    "Kia",
    "Hyundai",
    "Lada",
    "Audi",
    "Volkswagen",
    "Skoda",
    "Nissan",
    "Mazda",
    "Renault",
)

POPULAR_CITIES: tuple[str, ...] = (
    "Москва",
    "Санкт-Петербург",
    "Екатеринбург",
    "Новосибирск",
    "Краснодар",
    "Казань",
)

DISTANCE_OPTIONS: tuple[tuple[int, str], ...] = (
    (0, "Только этот город"),
    (50, "до 50 км"),
    (100, "до 100 км"),
    (200, "до 200 км"),
    (300, "до 300 км"),
    (500, "до 500 км"),
)

PAGE_SIZE = 5


def agent_choice_kb(kind: str, values: Sequence[str]) -> InlineKeyboardMarkup:
    """Accept a corrected entity or keep the user's spelling."""
    builder = InlineKeyboardBuilder()
    for value in list(values)[:3]:
        builder.row(
            InlineKeyboardButton(
                text=f"✅ {value[:40]}",
                callback_data=AddSubCB(action=f"apply_{kind}", value=value).pack(),
            )
        )
    keep_action = "keep_make" if kind == "make" else "keep_models"
    builder.row(
        InlineKeyboardButton(
            text="Оставить как есть",
            callback_data=AddSubCB(action=keep_action).pack(),
        )
    )
    return builder.as_markup()


def delete_me_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="🗑 Удалить аккаунт и данные",
            callback_data=SettingsCB(action="confirm_delete_me").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(text="Отмена", callback_data=MenuCB(action="home").pack())
    )
    return builder.as_markup()


def main_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="➕ Добавить подписку",
            callback_data=MenuCB(action="add").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="📋 Мои подписки", callback_data=MenuCB(action="subs").pack()
        ),
        InlineKeyboardButton(
            text="⚙️ Настройки", callback_data=MenuCB(action="settings").pack()
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text="🔍 Разовый поиск сейчас", callback_data=MenuCB(action="search").pack()
        ),
        InlineKeyboardButton(
            text="❓ Помощь / Статус", callback_data=MenuCB(action="help").pack()
        ),
    )
    return builder.as_markup()


def cancel_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="❌ Отмена", callback_data=AddSubCB(action="cancel").pack())
    )
    return builder.as_markup()


def brand_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for brand in POPULAR_BRANDS:
        builder.button(text=brand, callback_data=AddSubCB(action="brand", value=brand))
    builder.adjust(3, 3, 3, 3)
    builder.row(
        InlineKeyboardButton(
            text="✍️ Ввести вручную", callback_data=AddSubCB(action="manual").pack()
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ Отмена", callback_data=AddSubCB(action="cancel").pack())
    )
    return builder.as_markup()


def model_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="⏭ Любая модель", callback_data=AddSubCB(action="skip_model").pack()
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ Отмена", callback_data=AddSubCB(action="cancel").pack())
    )
    return builder.as_markup()


def city_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for city in POPULAR_CITIES:
        builder.button(text=city, callback_data=AddSubCB(action="city", value=city))
    builder.adjust(2, 2, 2)
    builder.row(
        InlineKeyboardButton(
            text="🌍 Любой город", callback_data=AddSubCB(action="skip_city").pack()
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ Отмена", callback_data=AddSubCB(action="cancel").pack())
    )
    return builder.as_markup()


def distance_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for kilometers, label in DISTANCE_OPTIONS:
        builder.button(
            text=label,
            callback_data=AddSubCB(action="distance", value=str(kilometers)),
        )
    builder.adjust(2, 2, 2)
    builder.row(
        InlineKeyboardButton(
            text="🌍 Любое расстояние",
            callback_data=AddSubCB(action="distance", value="any").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ Отмена", callback_data=AddSubCB(action="cancel").pack())
    )
    return builder.as_markup()


def price_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="♾ Без ограничения", callback_data=AddSubCB(action="skip_price").pack()
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ Отмена", callback_data=AddSubCB(action="cancel").pack())
    )
    return builder.as_markup()


def confirm_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Подтвердить", callback_data=AddSubCB(action="confirm").pack()
        ),
        InlineKeyboardButton(
            text="❌ Отмена", callback_data=AddSubCB(action="cancel").pack()
        ),
    )
    return builder.as_markup()


def subscriptions_kb(
    subscriptions: Sequence[Subscription],
    page: int,
    pages: int,
    *,
    offset: int = 0,
) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for index, subscription in enumerate(subscriptions, start=offset + 1):
        toggle_text = "⏸" if subscription.is_active else "▶️"
        builder.row(
            InlineKeyboardButton(
                text=f"{index}. {toggle_text} Пауза" if subscription.is_active else f"{index}. ▶️ Включить",
                callback_data=SubCB(
                    action="toggle", sub_id=subscription.id, page=page
                ).pack(),
            ),
            InlineKeyboardButton(
                text=f"{index}. 🗑 Удалить",
                callback_data=SubCB(
                    action="delete", sub_id=subscription.id, page=page
                ).pack(),
            ),
        )

    if pages > 1:
        nav_row = [
            InlineKeyboardButton(
                text="⬅️",
                callback_data=PageCB(page=max(0, page - 1)).pack(),
            ),
            InlineKeyboardButton(text=f"{page + 1}/{pages}", callback_data="noop"),
            InlineKeyboardButton(
                text="➡️",
                callback_data=PageCB(page=min(pages - 1, page + 1)).pack(),
            ),
        ]
        builder.row(*nav_row)

    builder.row(
        InlineKeyboardButton(
            text="➕ Добавить подписку", callback_data=MenuCB(action="add").pack()
        )
    )
    builder.row(
        InlineKeyboardButton(text="🏠 В меню", callback_data=MenuCB(action="home").pack())
    )
    return builder.as_markup()


def delete_confirm_kb(subscription_id: int, page: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Да, удалить",
            callback_data=SubCB(
                action="confirm_delete", sub_id=subscription_id, page=page
            ).pack(),
        ),
        InlineKeyboardButton(
            text="↩️ Оставить",
            callback_data=PageCB(page=page).pack(),
        ),
    )
    return builder.as_markup()


def settings_kb(notifications_enabled: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    toggle_text = (
        "🔕 Выключить уведомления" if notifications_enabled else "🔔 Включить уведомления"
    )
    builder.row(
        InlineKeyboardButton(
            text=toggle_text, callback_data=SettingsCB(action="toggle").pack()
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="🗑 Удалить все подписки",
            callback_data=SettingsCB(action="clear_all").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(text="🏠 В меню", callback_data=MenuCB(action="home").pack())
    )
    return builder.as_markup()


def clear_all_confirm_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Да, удалить всё", callback_data=SettingsCB(action="confirm_clear").pack()
        ),
        InlineKeyboardButton(
            text="↩️ Отмена", callback_data=MenuCB(action="settings").pack()
        ),
    )
    return builder.as_markup()


def search_subs_kb(subscriptions: Sequence[Subscription]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for subscription in subscriptions:
        label = format_subscription_line(subscription)
        builder.row(
            InlineKeyboardButton(
                text=f"🔍 {label[:56]}",
                callback_data=SearchCB(action="select", sub_id=subscription.id).pack(),
            )
        )
    builder.row(
        InlineKeyboardButton(text="🏠 В меню", callback_data=MenuCB(action="home").pack())
    )
    return builder.as_markup()


def search_period_kb(subscription_id: int) -> InlineKeyboardMarkup:
    """Choose how fresh listings must be for an ad-hoc search."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="📅 За месяц",
            callback_data=SearchCB(action="period", sub_id=subscription_id, days=30).pack(),
        ),
        InlineKeyboardButton(
            text="📆 За неделю",
            callback_data=SearchCB(action="period", sub_id=subscription_id, days=7).pack(),
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text="🕐 За сутки",
            callback_data=SearchCB(action="period", sub_id=subscription_id, days=1).pack(),
        ),
        InlineKeyboardButton(
            text="♾ За всё время",
            callback_data=SearchCB(action="period", sub_id=subscription_id, days=0).pack(),
        ),
    )
    builder.row(
        InlineKeyboardButton(
            text="↩️ К подпискам", callback_data=MenuCB(action="search").pack()
        )
    )
    return builder.as_markup()


def back_kb(action: str = "home") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="🏠 В меню", callback_data=MenuCB(action=action).pack()
        )
    )
    return builder.as_markup()


__all__ = [
    "DISTANCE_OPTIONS",
    "PAGE_SIZE",
    "POPULAR_BRANDS",
    "POPULAR_CITIES",
    "back_kb",
    "brand_kb",
    "cancel_kb",
    "city_kb",
    "distance_kb",
    "clear_all_confirm_kb",
    "confirm_kb",
    "delete_confirm_kb",
    "main_menu_kb",
    "model_kb",
    "price_kb",
    "search_period_kb",
    "search_subs_kb",
    "settings_kb",
    "subscriptions_kb",
]

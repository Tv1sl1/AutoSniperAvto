"""Ad-hoc ("search right now") flow."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot.callbacks import MenuCB, SearchCB
from bot.keyboards import back_kb, main_menu_kb, search_period_kb, search_subs_kb
from bot.texts import period_label, search_results_header
from bot.utils import safe_edit
from config.logger import get_logger
from config.settings import Settings
from database.models import Subscription, User
from database.repositories import SubscriptionRepository
from scrapers.base import SearchQuery
from services.net import ScraperError

logger = get_logger(__name__)
router = Router(name="search")

NO_ACTIVE_SUBS = (
    "🔍 <b>Разовый поиск</b>\n\n"
    "У вас нет активных подписок. Создайте подписку — и я смогу искать по ней."
)

_search_usage: dict[tuple[int, str], int] = {}


def _consume_daily_search(user_id: int, limit: int) -> bool:
    if limit <= 0:
        return True
    day = datetime.now(UTC).date().isoformat()
    key = (user_id, day)
    used = _search_usage.get(key, 0)
    if used >= limit:
        return False
    _search_usage[key] = used + 1
    return True


@router.message(Command("search"))
async def cmd_search(message: Message, session, user: User) -> None:
    text, markup = await _search_menu(session, user)
    await message.answer(text, reply_markup=markup)


@router.callback_query(MenuCB.filter(F.action == "search"))
async def show_search_menu(callback: CallbackQuery, state: FSMContext, session, user: User) -> None:
    await state.clear()
    text, markup = await _search_menu(session, user)
    await callback.answer()
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


async def _search_menu(session, user: User):
    repo = SubscriptionRepository(session)
    subscriptions = await repo.list_active_for_user(user.user_id)
    if not subscriptions:
        return NO_ACTIVE_SUBS, main_menu_kb()
    text = (
        "🔍 <b>Разовый поиск</b>\n\n"
        "Выберите подписку — я проверю источники прямо сейчас.\n"
        "Результаты не сохраняются в базе и не влияют на уведомления."
    )
    return text, search_subs_kb(subscriptions)


@router.callback_query(SearchCB.filter(F.action == "select"))
async def select_search_subscription(
    callback: CallbackQuery,
    callback_data: SearchCB,
    session,
    user: User,
) -> None:
    subscription = await SubscriptionRepository(session).get_owned(
        callback_data.sub_id, user.user_id
    )
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return
    if not subscription.is_active:
        await callback.answer("Подписка на паузе — включите её для поиска", show_alert=True)
        return
    await callback.answer()
    if callback.message is not None:
        await safe_edit(
            callback.message,
            f"🔍 <b>Разовый поиск:</b> {_subscription_label(subscription)}\n\n"
            "За какой период искать объявления?",
            search_period_kb(subscription.id),
        )


@router.callback_query(SearchCB.filter(F.action == "period"))
async def run_search(
    callback: CallbackQuery,
    callback_data: SearchCB,
    session,
    user: User,
    settings: Settings,
    orchestrator,
    notifier,
) -> None:
    if callback.message is None:
        await callback.answer()
        return

    subscription = await SubscriptionRepository(session).get_owned(
        callback_data.sub_id, user.user_id
    )
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return
    if not subscription.is_active:
        await callback.answer("Подписка на паузе — включите её для поиска", show_alert=True)
        return

    days = max(0, min(callback_data.days, 3650))
    if not _consume_daily_search(user.user_id, settings.single_search_daily_limit):
        await callback.answer(
            "Лимит разовых поисков на сегодня исчерпан. Попробуйте завтра.",
            show_alert=True,
        )
        return
    await callback.answer("Запускаю поиск…")
    await _run_search(
        callback,
        subscription,
        days,
        session=session,
        user=user,
        settings=settings,
        orchestrator=orchestrator,
        notifier=notifier,
    )


async def _run_search(
    callback: CallbackQuery,
    subscription: Subscription,
    days: int,
    *,
    session,
    user: User,
    settings: Settings,
    orchestrator,
    notifier,
) -> None:
    if callback.message is None:
        return
    label = _subscription_label(subscription)
    period = period_label(days)
    await safe_edit(
        callback.message,
        f"🔍 <b>Ищу:</b> {label}\n"
        f"Период: <b>{period}</b>\n\n"
        "Опрашиваю источники, это может занять до минуты…",
        None,
    )
    # Release the read transaction before the long network operation.
    await session.commit()

    query = SearchQuery.from_subscription(subscription)
    try:
        results = await asyncio.wait_for(
            orchestrator.search_now(
                query,
                limit=settings.single_search_limit,
                max_age_days=days or None,
            ),
            timeout=settings.single_search_timeout_seconds + 20,
        )
    except TimeoutError:
        logger.warning("Ad-hoc search timed out for user %s", user.user_id)
        await safe_edit(
            callback.message,
            "⏱ Поиск занял слишком много времени. Попробуйте позже — "
            "фоновый мониторинг продолжает работать.",
            back_kb(),
        )
        return
    except ScraperError as exc:
        logger.warning("Ad-hoc search failed: %s", exc)
        await safe_edit(callback.message, f"⚠️ Поиск недоступен: {exc}", back_kb())
        return
    except Exception:
        logger.exception("Unexpected ad-hoc search error")
        await safe_edit(callback.message, "⚠️ Не удалось выполнить поиск. Попробуйте позже.", back_kb())
        return

    if not results:
        message = (
            f"🔍 <b>Поиск:</b> {label}\n"
            f"Период: <b>{period}</b>\n\n"
            "😔 Сейчас ничего не нашлось. Я продолжаю следить за источниками "
            "и пришлю уведомление, когда появится подходящее объявление."
        )
        report = getattr(orchestrator, "last_quality", None)
        if report is not None and report.notes:
            message += "\n\n🤖 <i>Проверка:</i> " + "; ".join(report.notes[:3])
        await safe_edit(callback.message, message, back_kb())
        return

    await safe_edit(
        callback.message,
        f"{search_results_header(len(results), days)}\n\n<b>Фильтр:</b> {label}",
        back_kb(),
    )

    delivered = 0
    for listing in results:
        try:
            await notifier.send_listing(
                callback.message.chat.id,
                listing,
                header="🔍 <b>РЕЗУЛЬТАТ РАЗОВОГО ПОИСКА</b>",
                footer=f"<i>Разовый поиск · {period}</i>",
            )
            delivered += 1
        except Exception as exc:  # do not abort remaining cards
            logger.warning("Cannot send search result to %s: %s", user.user_id, exc)
        await asyncio.sleep(0.2)

    if delivered == 0:
        await callback.message.answer(
            "⚠️ Не удалось отправить карточки. Попробуйте ещё раз позже.",
            reply_markup=back_kb(),
        )


def _subscription_label(subscription: Subscription) -> str:
    from html import escape

    parts = [subscription.make]
    models = subscription.model_list
    parts.append(", ".join(models) if models else "любая модель")
    if subscription.city:
        parts.append(subscription.city)
    return escape(" ".join(parts))


__all__ = ["router"]

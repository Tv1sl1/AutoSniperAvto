"""Help and system status."""

from __future__ import annotations

from datetime import UTC, datetime

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from bot.callbacks import MenuCB
from bot.keyboards import back_kb
from bot.texts import HELP, status_text
from bot.utils import format_uptime, safe_edit
from config.settings import Settings
from database.models import User
from database.repositories import StatsRepository

router = Router(name="help")


@router.message(Command("help"))
async def cmd_help(message: Message, session, settings: Settings, user: User, orchestrator) -> None:
    text = await _build_help(session, settings, user, orchestrator)
    await message.answer(text, reply_markup=back_kb())


@router.message(Command("status"))
async def cmd_status(message: Message, session, settings: Settings, user: User, orchestrator) -> None:
    text = await _build_status(session, settings, user, orchestrator)
    await message.answer(text, reply_markup=back_kb())


@router.callback_query(MenuCB.filter(F.action == "help"))
async def show_help(
    callback: CallbackQuery, session, settings: Settings, user: User, orchestrator
) -> None:
    text = await _build_help(session, settings, user, orchestrator)
    await callback.answer()
    if callback.message is not None:
        await safe_edit(callback.message, text, back_kb())


async def _build_help(session, settings: Settings, user: User, orchestrator) -> str:
    header = HELP.format(interval=settings.poll_interval_seconds)
    return f"{header}\n\n———\n\n{await _build_status(session, settings, user, orchestrator)}"


async def _build_status(session, settings: Settings, user: User, orchestrator) -> str:
    overview = await StatsRepository(session).overview()
    scrapers = await orchestrator.status_snapshot()

    started_at = orchestrator.started_at
    if started_at is None:
        uptime = "только что запущен"
    else:
        if started_at.tzinfo is None:
            started_at = started_at.replace(tzinfo=UTC)
        uptime = format_uptime((datetime.now(UTC) - started_at).total_seconds())

    return status_text(
        overview=overview,
        scrapers=scrapers,
        interval=settings.poll_interval_seconds,
        uptime=uptime,
        timezone_name=settings.timezone,
        is_admin=user.user_id in settings.admin_ids,
    )


__all__ = ["router"]

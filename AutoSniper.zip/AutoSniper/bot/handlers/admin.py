"""Admin router. Phase A: access control and a minimal menu."""

from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.filters import AdminFilter
from bot.keyboards import main_menu_kb
from config.settings import Settings
from database.models import User

router = Router(name="admin")
router.message.filter(AdminFilter())


@router.message(Command("admin"))
async def cmd_admin(message: Message, user: User, settings: Settings) -> None:
    await message.answer(
        "🛠 <b>Админ-меню</b>\n\n"
        f"Ваш ID: <code>{user.user_id}</code>\n"
        "Доступ подтверждён. Расширенные функции появятся в следующих фазах.",
        reply_markup=main_menu_kb(),
    )


__all__ = ["router"]

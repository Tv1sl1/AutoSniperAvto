"""Subscription wizard, list management and settings."""

from __future__ import annotations

import math
import re
from html import escape
from typing import Any

from aiogram import F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot.callbacks import AddSubCB, MenuCB, PageCB, SettingsCB, SubCB
from bot.keyboards import (
    PAGE_SIZE,
    agent_choice_kb,
    brand_kb,
    cancel_kb,
    city_kb,
    clear_all_confirm_kb,
    confirm_kb,
    delete_confirm_kb,
    distance_kb,
    main_menu_kb,
    model_kb,
    price_kb,
    settings_kb,
    subscriptions_kb,
)
from bot.states import AddSubscriptionState
from bot.texts import (
    ASK_MAKE,
    CONFIRM,
    ask_city_text,
    ask_distance_text,
    ask_model_text,
    ask_price_text,
    settings_text,
    subscription_list_text,
    welcome_text,
)
from bot.utils import safe_edit
from config.settings import Settings
from database.models import Subscription, User
from database.repositories import SubscriptionRepository
from services.agents import EntityFix, ModelCheck, model_agent
from services.formatting import format_subscription_line, format_subscription_summary
from services.geo import has_coordinates
from services.parser_engine import (
    normalize_city,
    normalize_make,
    normalize_model,
    parse_price,
)

router = Router(name="subscriptions")

MIN_PRICE = 30_000
MAX_PRICE = 100_000_000
_LETTERS_RE = re.compile(r"[A-Za-zА-Яа-яЁё]")


# ---------------------------------------------------------------------------
# Rendering helpers
# ---------------------------------------------------------------------------
async def render_subscription_list(
    session, user: User, page: int = 0
) -> tuple[str, Any]:
    repo = SubscriptionRepository(session)
    total = await repo.count_for_user(user.user_id)
    pages = max(1, math.ceil(total / PAGE_SIZE))
    page = min(max(page, 0), pages - 1)
    subscriptions = await repo.list_for_user(
        user.user_id, limit=PAGE_SIZE, offset=page * PAGE_SIZE
    )
    text = subscription_list_text(subscriptions, page, pages, total)
    if not subscriptions:
        builder_markup = main_menu_kb()
    else:
        builder_markup = subscriptions_kb(
            subscriptions, page, pages, offset=page * PAGE_SIZE
        )
    return text, builder_markup


async def render_settings(session, user: User) -> tuple[str, Any]:
    repo = SubscriptionRepository(session)
    total = await repo.count_for_user(user.user_id)
    active = await repo.count_for_user(user.user_id, active_only=True)
    return settings_text(total, active, user.is_active), settings_kb(user.is_active)


# ---------------------------------------------------------------------------
# Wizard: step 1 — make
# ---------------------------------------------------------------------------
@router.message(Command("add"))
async def cmd_add(
    message: Message,
    state: FSMContext,
    session,
    user: User,
    settings: Settings,
) -> None:
    count = await SubscriptionRepository(session).count_for_user(user.user_id)
    if count >= settings.max_subscriptions_per_user:
        await message.answer(
            f"Достигнут лимит: {settings.max_subscriptions_per_user} подписок. "
            "Удалите одну из существующих в разделе «Мои подписки»."
        )
        return
    await state.clear()
    await state.set_state(AddSubscriptionState.make)
    await state.update_data(
        make=None,
        model=None,
        models=[],
        city=None,
        max_distance_km=None,
        max_price=None,
        max_age_days=settings.subscription_max_age_days,
        year_min=None,
    )
    await message.answer(ASK_MAKE, reply_markup=brand_kb())


@router.callback_query(MenuCB.filter(F.action == "add"))
async def add_subscription_start(
    callback: CallbackQuery,
    state: FSMContext,
    session,
    user: User,
    settings: Settings,
) -> None:
    count = await SubscriptionRepository(session).count_for_user(user.user_id)
    if count >= settings.max_subscriptions_per_user:
        await callback.answer(
            f"Достигнут лимит: {settings.max_subscriptions_per_user} подписок. "
            "Удалите одну из существующих.",
            show_alert=True,
        )
        return

    await state.clear()
    await state.set_state(AddSubscriptionState.make)
    await state.update_data(
        make=None,
        model=None,
        models=[],
        city=None,
        max_distance_km=None,
        max_price=None,
        max_age_days=settings.subscription_max_age_days,
        year_min=None,
    )
    await callback.answer()
    if callback.message is not None:
        await safe_edit(callback.message, ASK_MAKE, brand_kb())


@router.callback_query(AddSubCB.filter(F.action == "brand"), StateFilter(AddSubscriptionState.make))
async def brand_selected(callback: CallbackQuery, callback_data: AddSubCB, state: FSMContext) -> None:
    make = normalize_make(callback_data.value) or callback_data.value
    await state.update_data(make=make)
    await state.set_state(AddSubscriptionState.model)
    await callback.answer(f"Марка: {make}")
    if callback.message is not None:
        await safe_edit(callback.message, ask_model_text(make), model_kb())


@router.callback_query(AddSubCB.filter(F.action == "manual"), StateFilter(AddSubscriptionState.make))
async def brand_manual(callback: CallbackQuery) -> None:
    await callback.answer("Напишите марку сообщением, например: BMW", show_alert=False)


@router.message(StateFilter(AddSubscriptionState.make), F.text)
async def make_entered(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text.startswith("/"):
        await message.answer("Сначала завершите добавление подписки или отправьте /cancel.")
        return
    if not _LETTERS_RE.search(text) or len(text) > 40:
        await message.answer(
            "Похоже, это не марка. Напишите название марки, например <b>BMW</b> или <b>Лада</b>.",
            reply_markup=cancel_kb(),
        )
        return
    make_fix = model_agent.check_make(text)
    make = make_fix.corrected or text.title()
    if make_fix.suggestions and not make_fix.changed:
        await state.update_data(pending_make=text)
        await state.set_state(AddSubscriptionState.make)
        await message.answer(
            "🤖 Возможно, вы имели в виду другую марку. Выберите вариант:",
            reply_markup=agent_choice_kb("make", make_fix.suggestions),
        )
        return
    await state.update_data(make=make)
    await state.set_state(AddSubscriptionState.model)
    prompt = ask_model_text(make)
    note = _make_agent_note(make_fix)
    if note:
        prompt += "\n\n" + note
    await message.answer(prompt, reply_markup=model_kb())


@router.callback_query(
    AddSubCB.filter(F.action == "apply_make"), StateFilter(AddSubscriptionState.make)
)
async def apply_make(callback: CallbackQuery, callback_data: AddSubCB, state: FSMContext) -> None:
    make = normalize_make(callback_data.value) or callback_data.value
    await state.update_data(make=make)
    await state.set_state(AddSubscriptionState.model)
    await callback.answer(f"Марка: {make}")
    if callback.message is not None:
        await safe_edit(callback.message, ask_model_text(make), model_kb())


@router.callback_query(
    AddSubCB.filter(F.action == "keep_make"), StateFilter(AddSubscriptionState.make)
)
async def keep_make(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    make = normalize_make(data.get("pending_make") or data.get("make")) or data.get("make") or ""
    await state.update_data(make=make)
    await state.set_state(AddSubscriptionState.model)
    await callback.answer("Оставляем как есть")
    if callback.message is not None:
        await safe_edit(callback.message, ask_model_text(make), model_kb())


# ---------------------------------------------------------------------------
# Step 2 — model
# ---------------------------------------------------------------------------
@router.callback_query(AddSubCB.filter(F.action == "skip_model"), StateFilter(AddSubscriptionState.model))
async def model_skipped(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    make = data.get("make") or ""
    await state.update_data(model=None, models=[])
    await state.set_state(AddSubscriptionState.city)
    await callback.answer("Ищем все модели")
    if callback.message is not None:
        await safe_edit(callback.message, ask_city_text(make, []), city_kb())


@router.message(StateFilter(AddSubscriptionState.model), F.text)
async def model_entered(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text.startswith("/"):
        await message.answer("Сначала завершите добавление подписки или отправьте /cancel.")
        return
    if len(text) > 500:
        await message.answer("Слишком длинный список моделей. Укажите до 10 моделей через запятую.")
        return

    models: list[str] = []
    raw_parts = [part.strip() for part in re.split(r"[,;\n]+", text) if part.strip()]
    data = await state.get_data()
    make = data.get("make") or ""
    check = model_agent.check_models(make, raw_parts)
    if check.make and check.make != make:
        make = check.make
        await state.update_data(make=make)
    models = list(check.models)
    if not models:
        await message.answer("Не понял модель. Напишите, например: <b>3 Series</b> или <b>X5, 5 Series</b>.")
        return
    if len(models) > 10:
        await message.answer("Можно выбрать не больше 10 моделей за одну подписку.")
        return
    if any(len(model) > 60 for model in models):
        await message.answer("Название модели слишком длинное (максимум 60 символов).")
        return

    if check.suggestions and len(raw_parts) == 1:
        await state.update_data(pending_models=raw_parts, pending_make=make)
        await state.set_state(AddSubscriptionState.model)
        await message.answer(
            "🤖 Возможно, вы имели в виду другую модель. Выберите вариант:",
            reply_markup=agent_choice_kb("model", check.suggestions),
        )
        return

    await _set_models_and_go_city(
        message, state, make, models, note=_model_agent_note(check)
    )


async def _set_models_and_go_city(
    message: Message, state: FSMContext, make: str, models: list[str], *, note: str = ""
) -> None:
    await state.update_data(model=models[0], models=models)
    await state.set_state(AddSubscriptionState.city)
    prompt = ask_city_text(make, models)
    if note:
        prompt += "\n\n" + note
    await message.answer(prompt, reply_markup=city_kb())


@router.callback_query(
    AddSubCB.filter(F.action == "apply_model"), StateFilter(AddSubscriptionState.model)
)
async def apply_model(callback: CallbackQuery, callback_data: AddSubCB, state: FSMContext) -> None:
    data = await state.get_data()
    make = data.get("make") or ""
    model = normalize_model(callback_data.value) or callback_data.value
    await callback.answer(f"Модель: {model}")
    if callback.message is not None:
        await _set_models_and_go_city(callback.message, state, make, [model])


@router.callback_query(
    AddSubCB.filter(F.action == "keep_models"), StateFilter(AddSubscriptionState.model)
)
async def keep_models(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    make = data.get("make") or ""
    models = [
        normalize_model(item) or item
        for item in (data.get("pending_models") or [])
        if (normalize_model(item) or item)
    ]
    await callback.answer("Оставляем как есть")
    if callback.message is not None and models:
        await _set_models_and_go_city(callback.message, state, make, models)


# ---------------------------------------------------------------------------
# Step 3 — city and step 4 — distance
# ---------------------------------------------------------------------------
@router.callback_query(AddSubCB.filter(F.action == "city"), StateFilter(AddSubscriptionState.city))
async def city_selected(callback: CallbackQuery, callback_data: AddSubCB, state: FSMContext) -> None:
    await _set_city(callback, state, callback_data.value)
    await callback.answer(f"Город: {callback_data.value}")


@router.callback_query(AddSubCB.filter(F.action == "skip_city"), StateFilter(AddSubscriptionState.city))
async def city_skipped(callback: CallbackQuery, state: FSMContext) -> None:
    await _set_city(callback, state, None)
    await callback.answer("Город не важен")


async def _prepare_after_city(state: FSMContext, city: str | None) -> tuple[str, Any]:
    data = await state.get_data()
    make = data.get("make") or ""
    models = data.get("models") or []
    await state.update_data(city=city, max_distance_km=None)

    if city and has_coordinates(city):
        await state.set_state(AddSubscriptionState.distance)
        return ask_distance_text(make, models, city), distance_kb()

    await state.set_state(AddSubscriptionState.price)
    text = ask_price_text(make, models, city, None)
    if city:
        text += "\n\n<i>Для этого города выбор расстояния пока недоступен.</i>"
    return text, price_kb()


async def _set_city(callback: CallbackQuery, state: FSMContext, city: str | None) -> None:
    text, markup = await _prepare_after_city(state, city)
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


@router.message(StateFilter(AddSubscriptionState.city), F.text)
async def city_entered(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text.startswith("/"):
        await message.answer("Сначала завершите добавление подписки или отправьте /cancel.")
        return
    if len(text) > 60:
        await message.answer("Название города слишком длинное (максимум 60 символов).")
        return
    city = normalize_city(text)
    if not city:
        await message.answer("Не удалось распознать город. Попробуйте ещё раз, например: Москва.")
        return
    prompt, markup = await _prepare_after_city(state, city)
    await message.answer(prompt, reply_markup=markup)


@router.callback_query(
    AddSubCB.filter(F.action == "distance"), StateFilter(AddSubscriptionState.distance)
)
async def distance_selected(
    callback: CallbackQuery, callback_data: AddSubCB, state: FSMContext
) -> None:
    value = callback_data.value.strip().lower()
    if value in {"any", "none", "любое", "без"}:
        max_distance: int | None = None
    else:
        try:
            max_distance = max(0, min(int(value), 5000))
        except ValueError:
            await callback.answer("Не понял расстояние", show_alert=True)
            return
    await _set_distance(callback, state, max_distance)
    await callback.answer("Расстояние учтено")


async def _set_distance(
    target: CallbackQuery | Message, state: FSMContext, max_distance: int | None
) -> None:
    data = await state.get_data()
    make = data.get("make") or ""
    models = data.get("models") or []
    city = data.get("city")
    await state.update_data(max_distance_km=max_distance)
    await state.set_state(AddSubscriptionState.price)
    prompt = ask_price_text(make, models, city, max_distance)
    if isinstance(target, CallbackQuery):
        if target.message is not None:
            await safe_edit(target.message, prompt, price_kb())
    else:
        await target.answer(prompt, reply_markup=price_kb())


@router.message(StateFilter(AddSubscriptionState.distance), F.text)
async def distance_entered(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip().lower()
    if text.startswith("/"):
        await message.answer("Сначала завершите добавление подписки или отправьте /cancel.")
        return
    if text in {"любое", "без", "нет", "any"}:
        await _set_distance(message, state, None)
        return
    match = re.search(r"\d+", text)
    if not match:
        await message.answer(
            "Напишите расстояние числом в километрах, например <b>100</b>, "
            "или нажмите кнопку ниже.",
            reply_markup=distance_kb(),
        )
        return
    value = int(match.group())
    if value > 5000:
        await message.answer("Максимальное расстояние — 5000 км.", reply_markup=distance_kb())
        return
    await _set_distance(message, state, value)


# ---------------------------------------------------------------------------
# Step 4 — price
# ---------------------------------------------------------------------------
@router.callback_query(AddSubCB.filter(F.action == "skip_price"), StateFilter(AddSubscriptionState.price))
async def price_skipped(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(max_price=None)
    await _show_confirmation(callback, state)
    await callback.answer("Без ограничения цены")


@router.message(StateFilter(AddSubscriptionState.price), F.text)
async def price_entered(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text.startswith("/"):
        await message.answer("Сначала завершите добавление подписки или отправьте /cancel.")
        return
    normalized = text.lower().replace(" ", "")
    if normalized in {"0", "нет", "без", "безлимит", "любая"}:
        await state.update_data(max_price=None)
        await _show_confirmation_message(message, state)
        return

    price = parse_price(text)
    if price is None:
        await message.answer(
            "Не понял цену 🤔\nНапишите сумму числом, например <b>2 500 000</b> "
            "или <b>2,5 млн</b>.",
            reply_markup=price_kb(),
        )
        return
    if price < MIN_PRICE or price > MAX_PRICE:
        await message.answer(
            f"Цена выглядит нереальной. Укажите сумму от {MIN_PRICE:,} до {MAX_PRICE:,} ₽.".replace(
                ",", " "
            ),
            reply_markup=price_kb(),
        )
        return
    await state.update_data(max_price=price)
    await _show_confirmation_message(message, state)


def _make_agent_note(fix: EntityFix) -> str:
    if fix.changed:
        return (
            "🤖 <b>Проверил марку:</b> "
            f"«{escape(fix.original)}» → «{escape(fix.corrected)}»."
        )
    if fix.suggestions:
        variants = ", ".join(f"«{escape(item)}»" for item in fix.suggestions[:3])
        return f"🤖 <b>Возможно, вы имели в виду:</b> {variants}."
    return ""


def _model_agent_note(check: ModelCheck) -> str:
    lines: list[str] = []
    if check.corrections:
        pairs = ", ".join(
            f"«{escape(fix.original)}» → «{escape(fix.corrected)}»"
            for fix in check.corrections[:5]
        )
        lines.append(f"🤖 <b>Проверил модели:</b> {pairs}.")
    if check.suggestions:
        variants = ", ".join(f"«{escape(item)}»" for item in check.suggestions[:3])
        lines.append(f"🤖 <b>Возможно:</b> {variants}. Если нет — продолжайте.")
    return "\n".join(lines)


def _temporary_subscription(data: dict[str, Any]) -> Subscription:
    models = list(data.get("models") or [])
    if not models and data.get("model"):
        models = [data["model"]]
    return Subscription(
        make=data.get("make") or "",
        model=models[0] if models else data.get("model"),
        models=models,
        city=data.get("city"),
        max_price=data.get("max_price"),
        max_distance_km=data.get("max_distance_km"),
        max_age_days=data.get("max_age_days"),
        year_min=data.get("year_min"),
    )


async def _show_confirmation(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    temporary = _temporary_subscription(data)
    await state.set_state(AddSubscriptionState.confirm)
    if callback.message is not None:
        await safe_edit(callback.message, CONFIRM.format(summary=format_subscription_summary(temporary)), confirm_kb())


async def _show_confirmation_message(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    temporary = _temporary_subscription(data)
    await state.set_state(AddSubscriptionState.confirm)
    await message.answer(
        CONFIRM.format(summary=format_subscription_summary(temporary)),
        reply_markup=confirm_kb(),
    )


# ---------------------------------------------------------------------------
# Step 5 — confirmation
# ---------------------------------------------------------------------------
@router.callback_query(AddSubCB.filter(F.action == "confirm"), StateFilter(AddSubscriptionState.confirm))
async def confirm_subscription(
    callback: CallbackQuery,
    state: FSMContext,
    session,
    user: User,
    settings: Settings,
) -> None:
    data = await state.get_data()
    make = data.get("make")
    if not make:
        await state.clear()
        await callback.answer("Сессия устарела, начните заново", show_alert=True)
        return

    repo = SubscriptionRepository(session)
    if await repo.count_for_user(user.user_id) >= settings.max_subscriptions_per_user:
        await callback.answer("Достигнут лимит подписок", show_alert=True)
        return

    model = data.get("model")
    models = list(data.get("models") or [])
    if not models and model:
        models = [model]
    model = models[0] if models else model
    city = data.get("city")
    max_price = data.get("max_price")
    max_distance = data.get("max_distance_km")
    duplicate = await repo.find_duplicate(
        user_id=user.user_id,
        make=make,
        model=model,
        max_price=max_price,
        city=city,
        max_distance_km=max_distance,
        year_min=data.get("year_min"),
    )
    if duplicate is not None:
        await callback.answer(
            "Такая подписка уже есть — измените параметры или отмените добавление.",
            show_alert=True,
        )
        return

    subscription = await repo.create(
        user_id=user.user_id,
        make=make,
        model=model,
        models=models,
        max_price=max_price,
        city=city,
        max_distance_km=max_distance,
        max_age_days=data.get("max_age_days", settings.subscription_max_age_days),
        year_min=data.get("year_min"),
    )
    await session.commit()
    await state.clear()

    await callback.answer("Подписка сохранена ✅")
    if callback.message is not None:
        await safe_edit(
            callback.message,
            "✅ <b>Подписка добавлена!</b>\n\n"
            f"{format_subscription_summary(subscription)}\n\n"
            "Я пришлю уведомление, как только появится подходящее объявление.",
            main_menu_kb(),
        )


@router.callback_query(AddSubCB.filter(F.action == "cancel"))
async def cancel_wizard(callback: CallbackQuery, state: FSMContext, user: User) -> None:
    await state.clear()
    await callback.answer("Отменено")
    if callback.message is not None:
        await safe_edit(callback.message, welcome_text(user.first_name), main_menu_kb())


# ---------------------------------------------------------------------------
# List / pause / delete
# ---------------------------------------------------------------------------
@router.message(Command("subs"))
async def cmd_subs(message: Message, state: FSMContext, session, user: User) -> None:
    await state.clear()
    text, markup = await render_subscription_list(session, user, 0)
    await message.answer(text, reply_markup=markup)


@router.callback_query(MenuCB.filter(F.action == "subs"))
async def show_subscriptions(callback: CallbackQuery, state: FSMContext, session, user: User) -> None:
    await state.clear()
    text, markup = await render_subscription_list(session, user, 0)
    await callback.answer()
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


@router.callback_query(PageCB.filter(F.kind == "subs"))
async def paginate_subscriptions(
    callback: CallbackQuery, callback_data: PageCB, session, user: User
) -> None:
    text, markup = await render_subscription_list(session, user, callback_data.page)
    await callback.answer()
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


@router.callback_query(SubCB.filter(F.action == "toggle"))
async def toggle_subscription(
    callback: CallbackQuery, callback_data: SubCB, session, user: User
) -> None:
    repo = SubscriptionRepository(session)
    subscription = await repo.get_owned(callback_data.sub_id, user.user_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return
    updated = await repo.set_active(subscription.id, user.user_id, not subscription.is_active)
    await session.commit()
    state_text = "включена" if updated and updated.is_active else "поставлена на паузу"
    await callback.answer(f"Подписка {state_text}")
    text, markup = await render_subscription_list(session, user, callback_data.page)
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


@router.callback_query(SubCB.filter(F.action == "delete"))
async def ask_delete_subscription(
    callback: CallbackQuery, callback_data: SubCB, session, user: User
) -> None:
    subscription = await SubscriptionRepository(session).get_owned(callback_data.sub_id, user.user_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return
    await callback.answer()
    if callback.message is not None:
        await safe_edit(
            callback.message,
            "🗑 <b>Удалить подписку?</b>\n\n"
            f"{format_subscription_line(subscription)}\n\n"
            "Это действие нельзя отменить.",
            delete_confirm_kb(subscription.id, callback_data.page),
        )


@router.callback_query(SubCB.filter(F.action == "confirm_delete"))
async def delete_subscription(
    callback: CallbackQuery, callback_data: SubCB, session, user: User
) -> None:
    deleted = await SubscriptionRepository(session).delete_owned(callback_data.sub_id, user.user_id)
    await session.commit()
    await callback.answer("Удалено" if deleted else "Подписка не найдена", show_alert=not deleted)
    text, markup = await render_subscription_list(session, user, callback_data.page)
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
@router.message(Command("settings"))
async def cmd_settings(message: Message, state: FSMContext, session, user: User) -> None:
    await state.clear()
    text, markup = await render_settings(session, user)
    await message.answer(text, reply_markup=markup)


@router.callback_query(MenuCB.filter(F.action == "settings"))
async def show_settings(callback: CallbackQuery, state: FSMContext, session, user: User) -> None:
    await state.clear()
    text, markup = await render_settings(session, user)
    await callback.answer()
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


@router.callback_query(SettingsCB.filter(F.action == "toggle"))
async def toggle_notifications(callback: CallbackQuery, session, user: User) -> None:
    user.is_active = not user.is_active
    await session.commit()
    await callback.answer(
        "Уведомления включены" if user.is_active else "Уведомления выключены"
    )
    text, markup = await render_settings(session, user)
    if callback.message is not None:
        await safe_edit(callback.message, text, markup)


@router.callback_query(SettingsCB.filter(F.action == "clear_all"))
async def ask_clear_all(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message is not None:
        await safe_edit(
            callback.message,
            "🗑 <b>Удалить все подписки?</b>\n\n"
            "Все ваши фильтры будут удалены. Объявления в базе останутся, "
            "но уведомления приходить перестанут.",
            clear_all_confirm_kb(),
        )


@router.callback_query(SettingsCB.filter(F.action == "confirm_clear"))
async def clear_all(callback: CallbackQuery, session, user: User) -> None:
    removed = await SubscriptionRepository(session).delete_all_for_user(user.user_id)
    await session.commit()
    await callback.answer(f"Удалено подписок: {removed}")
    if callback.message is not None:
        await safe_edit(
            callback.message,
            "✅ <b>Все подписки удалены.</b>\n\n"
            "Можете создать новые в любой момент.",
            main_menu_kb(),
        )


__all__ = ["render_subscription_list", "render_settings", "router"]

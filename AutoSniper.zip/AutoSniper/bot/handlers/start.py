"""Entry points: /start, /menu, /cancel and the main menu callback."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot.callbacks import MenuCB, SettingsCB
from bot.keyboards import delete_me_kb, main_menu_kb
from bot.texts import welcome_text
from bot.utils import safe_edit
from config.settings import Settings
from database.models import User
from database.repositories import SubscriptionRepository

router = Router(name="start")

WELCOME_HINT = (
    "\n\n💡 Начните с «➕ Добавить подписку» — это займёт меньше минуты."
)


@router.message(CommandStart())
async def cmd_start(
    message: Message,
    state: FSMContext,
    user: User,
    session,
    settings: Settings,
) -> None:
    await state.clear()
    if not user.is_active:
        user.is_active = True
        await session.commit()
    count = await SubscriptionRepository(session).count_for_user(user.user_id)
    text = welcome_text(user.first_name)
    if count == 0:
        text += WELCOME_HINT
    await message.answer(text, reply_markup=main_menu_kb())


@router.message(Command("menu"))
async def cmd_menu(message: Message, state: FSMContext, user: User) -> None:
    await state.clear()
    await message.answer(welcome_text(user.first_name), reply_markup=main_menu_kb())


@router.message(Command("delete_me"))
async def cmd_delete_me(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "⚠️ <b>Удаление аккаунта</b>\n\n"
        "Будут удалены профиль, все подписки и журнал уведомлений. "
        "Действие необратимо.",
        reply_markup=delete_me_kb(),
    )


@router.callback_query(SettingsCB.filter(F.action == "confirm_delete_me"))
async def confirm_delete_me(callback: CallbackQuery, session, user: User, state: FSMContext) -> None:
    await state.clear()
    await session.delete(user)
    await session.commit()
    await callback.answer("Данные удалены")
    if callback.message is not None:
        await safe_edit(
            callback.message,
            "✅ Профиль, подписки и уведомления удалены.\n"
            "Отправьте /start, чтобы начать заново.",
            None,
        )


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    current = await state.get_state()
    await state.clear()
    if current:
        await message.answer("✅ Действие отменено.", reply_markup=main_menu_kb())
    else:
        await message.answer("Нечего отменять 🙂", reply_markup=main_menu_kb())


@router.callback_query(MenuCB.filter(F.action == "home"))
async def menu_home(callback: CallbackQuery, state: FSMContext, user: User) -> None:
    await state.clear()
    await callback.answer()
    if callback.message is not None:
        await safe_edit(callback.message, welcome_text(user.first_name), main_menu_kb())


__all__ = ["router"]

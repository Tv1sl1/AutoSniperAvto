"""Bot routers."""

from bot.handlers import admin, fallback, help, search, start, subscriptions

__all__ = ["admin", "fallback", "help", "search", "start", "subscriptions"]

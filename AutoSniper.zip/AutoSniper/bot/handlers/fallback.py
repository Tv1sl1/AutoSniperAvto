"""Catch-all handlers: unknown messages, stale buttons, pagination no-op."""

from __future__ import annotations

from aiogram import Router
from aiogram.types import CallbackQuery, Message

from bot.keyboards import main_menu_kb

router = Router(name="fallback")


@router.callback_query(lambda query: query.data == "noop")
async def noop(callback: CallbackQuery) -> None:
    await callback.answer()


@router.message()
async def unknown_message(message: Message) -> None:
    text = (message.text or "").strip()
    if text == "/admin" or text.startswith("/admin "):
        return  # non-admin: stay silent
    await message.answer(
        "Не понял сообщение 🤔\n"
        "Воспользуйтесь меню ниже или отправьте /help.",
        reply_markup=main_menu_kb(),
    )


@router.callback_query()
async def unknown_callback(callback: CallbackQuery) -> None:
    await callback.answer(
        "Кнопка устарела. Откройте меню заново командой /start.",
        show_alert=False,
    )


__all__ = ["router"]

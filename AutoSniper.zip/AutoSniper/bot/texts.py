"""User-facing copy (HTML-safe where dynamic values are inserted)."""

from __future__ import annotations

from collections.abc import Sequence
from html import escape
from typing import Any

from bot.keyboards import PAGE_SIZE
from database.models import Subscription
from services.formatting import format_datetime, format_price, format_subscription_line

WELCOME = (
    "🚗 <b>AutoSniper</b> — мониторинг объявлений о продаже автомобилей.\n\n"
    "Я слежу за Telegram-каналами, сообществами VK и веб-площадками "
    "и присылаю подходящие машины, как только они появляются.\n\n"
    "Выберите действие 👇"
)

ASK_MAKE = (
    "➕ <b>Новая подписка</b>\n\n"
    "<b>Шаг 1/5 — марка</b>\n\n"
    "Выберите марку из списка или напишите её сообщением "
    "(например, <i>BMW</i>, <i>Mercedes</i>, <i>Лада</i>)."
)

ASK_MODEL = (
    "✅ Марка: <b>{make}</b>\n\n"
    "<b>Шаг 2/5 — модели</b>\n\n"
    "Напишите одну или несколько моделей через запятую: "
    "<i>3 Series, X5</i> или <i>Camry</i>. До 10 моделей.\n"
    "Или пропустите шаг, чтобы искать все модели этой марки."
)

ASK_CITY = (
    "✅ {make}{model}\n\n"
    "<b>Шаг 3/5 — город</b>\n\n"
    "Выберите город или напишите свой. Если город не важен — нажмите «Любой город»."
)

ASK_DISTANCE = (
    "✅ {make}{model} · {city}\n\n"
    "<b>Шаг 4/5 — расстояние от города</b>\n\n"
    "Насколько далеко искать объявления? Например, «до 100 км» "
    "включает область и соседние города.\n\n"
    "<i>Расстояние доступно для крупных городов; для остальных шаг будет пропущен.</i>"
)

ASK_PRICE = (
    "✅ {make}{model} · {city}{distance}\n\n"
    "<b>Шаг 5/5 — максимальная цена</b>\n\n"
    "Напишите сумму в рублях, например <i>2 500 000</i> или <i>2,5 млн</i>."
)

CONFIRM = "Проверьте параметры подписки:\n\n{summary}\n\nВсё верно?"

PERIOD_LABELS = {
    30: "за последний месяц",
    7: "за последнюю неделю",
    1: "за последние сутки",
    0: "за всё время",
}

HELP = (
    "<b>❓ Как это работает</b>\n\n"
    "1. Создайте подписку: марка, модели, город, расстояние и максимальная цена.\n"
    "2. Фоновый движок каждые {interval} секунд проверяет Telegram-каналы, "
    "VK и веб-площадки.\n"
    "3. Когда появляется подходящее объявление, вы получаете карточку с фото, "
    "ценой, городом и ссылкой на источник.\n\n"
    "<b>Команды</b>\n"
    "/add — добавить подписку\n"
    "/subs — мои подписки\n"
    "/settings — настройки уведомлений\n"
    "/search — разовый поиск по подписке\n"
    "/status — состояние системы\n"
    "/cancel — отменить текущее действие\n\n"
    "<b>Важно</b>\n"
    "• Подписка присылает только свежие объявления (по умолчанию за 7 дней).\n"
    "• В разовом поиске можно выбрать месяц, неделю, сутки или всё время.\n"
    "• Можно указать до 10 моделей через запятую.\n"
    "• Расстояние работает для крупных городов; город и цена должны распознаваться.\n"
    "• Повторно одно и то же объявление не приходит.\n"
    "• Парсер работает по эвристикам: цена и город могут не распознаться, "
    "если автор написал их необычно."
)


def welcome_text(first_name: str | None = None) -> str:
    if first_name:
        return f"👋 Привет, <b>{escape(first_name)}</b>!\n\n{WELCOME}"
    return WELCOME


def ask_model_text(make: str) -> str:
    return ASK_MODEL.format(make=escape(make))


def _models_suffix(models: Sequence[str] | None) -> str:
    values = [model for model in (models or []) if model]
    if not values:
        return " (любая модель)"
    return f" {escape(', '.join(values))}"


def ask_city_text(make: str, models: Sequence[str] | None) -> str:
    return ASK_CITY.format(make=escape(make), model=_models_suffix(models))


def ask_distance_text(make: str, models: Sequence[str] | None, city: str) -> str:
    return ASK_DISTANCE.format(
        make=escape(make),
        model=_models_suffix(models),
        city=escape(city),
    )


def ask_price_text(
    make: str,
    models: Sequence[str] | None,
    city: str | None,
    distance: int | None = None,
) -> str:
    distance_text = ""
    if distance is not None and city:
        distance_text = f" · до {distance} км" if distance else " · только город"
    return ASK_PRICE.format(
        make=escape(make),
        model=_models_suffix(models),
        city=escape(city or "любой город"),
        distance=distance_text,
    )


def period_label(days: int) -> str:
    return PERIOD_LABELS.get(days, f"за {days} дн.")


def subscription_list_text(
    subscriptions: Sequence[Subscription],
    page: int,
    pages: int,
    total: int,
) -> str:
    if not subscriptions:
        return (
            "📋 <b>Мои подписки</b>\n\n"
            "Пока пусто. Добавьте первую подписку — и я начну искать автомобиль."
        )
    lines = [f"📋 <b>Мои подписки</b> · всего {total}"]
    if pages > 1:
        lines[0] += f" · страница {page + 1}/{pages}"
    lines.append("")
    for index, subscription in enumerate(subscriptions, start=page * PAGE_SIZE + 1):
        icon = "🟢" if subscription.is_active else "⏸"
        lines.append(f"{icon} <b>{index}.</b> {format_subscription_line(subscription)}")
    lines.append("")
    lines.append("<i>Кнопки под списком управляют подписками по их номеру.</i>")
    return "\n".join(lines)


def settings_text(subscription_count: int, active_count: int, notifications: bool) -> str:
    return (
        "⚙️ <b>Настройки</b>\n\n"
        f"🔔 Уведомления: <b>{'включены' if notifications else 'выключены'}</b>\n"
        f"📋 Подписок: <b>{subscription_count}</b> (активных {active_count})\n\n"
        "Когда уведомления выключены, подписки сохраняются, "
        "но новые объявления вам не присылаются."
    )


def status_text(
    *,
    overview: dict[str, int],
    scrapers: Sequence[dict[str, Any]],
    interval: int,
    uptime: str,
    timezone_name: str,
    is_admin: bool,
) -> str:
    lines = [
        "📊 <b>Статус системы</b>",
        "",
        f"👥 Пользователей: <b>{overview.get('users', 0)}</b> "
        f"(активных {overview.get('active_users', 0)})",
        f"📋 Подписок: <b>{overview.get('active_subscriptions', 0)}</b> активных "
        f"из {overview.get('subscriptions', 0)}",
        f"🚗 Объявлений в базе: <b>{overview.get('listings', 0)}</b>",
        f"📨 Уведомлений отправлено: <b>{overview.get('notifications_sent', 0)}</b>",
        "",
        f"⏱ Аптайм: <b>{escape(uptime)}</b>",
        f"🔄 Интервал опроса: <b>{interval} с</b>",
        "",
        "<b>Источники</b>",
    ]
    if not scrapers:
        lines.append("• источники не настроены")
    for row in scrapers:
        name = escape(str(row["name"]))
        if row.get("last_success_at"):
            last = format_datetime(row["last_success_at"], timezone_name)
        else:
            last = "ещё не запускался"
        failures = int(row.get("consecutive_failures") or 0)
        icon = "✅" if not failures else "⚠️"
        line = f"{icon} <b>{name}</b> — {last}"
        if failures:
            line += f", ошибок подряд: {failures}"
            if is_admin and row.get("last_error"):
                line += f"\n   <code>{escape(str(row['last_error'])[:180])}</code>"
        lines.append(line)
    lines.append("")
    lines.append("<i>Разовый поиск не сохраняет объявления и не влияет на подписки.</i>")
    return "\n".join(lines)


def search_results_header(count: int, days: int | None = None) -> str:
    period = f" · {period_label(days)}" if days is not None else ""
    return f"🔍 <b>Разовый поиск</b>{period}\n\nНайдено объявлений: <b>{count}</b>."


def subscription_label(subscription: Subscription) -> str:
    return format_subscription_line(subscription)


def price_text(value: int | None) -> str:
    return format_price(value)


__all__ = [
    "ASK_CITY",
    "ASK_DISTANCE",
    "ASK_MAKE",
    "ASK_MODEL",
    "ASK_PRICE",
    "CONFIRM",
    "HELP",
    "PERIOD_LABELS",
    "WELCOME",
    "ask_city_text",
    "ask_distance_text",
    "ask_model_text",
    "ask_price_text",
    "period_label",
    "price_text",
    "search_results_header",
    "settings_text",
    "status_text",
    "subscription_label",
    "subscription_list_text",
    "welcome_text",
]

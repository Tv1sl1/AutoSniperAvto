"""FSM states for the step-by-step subscription wizard."""

from __future__ import annotations

from aiogram.fsm.state import State, StatesGroup


class AddSubscriptionState(StatesGroup):
    make = State()
    model = State()
    city = State()
    distance = State()
    price = State()
    confirm = State()


__all__ = ["AddSubscriptionState"]

"""Admin-only filters."""

from __future__ import annotations

from aiogram.filters import BaseFilter
from aiogram.types import TelegramObject

from config.settings import Settings


class AdminFilter(BaseFilter):
    """Allow only IDs listed in ``ADMIN_IDS``; silently ignores everyone else."""

    async def __call__(self, event: TelegramObject, settings: Settings) -> bool:
        user = getattr(event, "from_user", None)
        return user is not None and user.id in settings.admin_ids


__all__ = ["AdminFilter"]

"""Middlewares: per-update DB session, user sync, throttling and error handling."""

from __future__ import annotations

import time
from collections import deque
from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware, Bot
from aiogram.types import CallbackQuery, ErrorEvent, Message, TelegramObject

from config.logger import get_logger
from config.settings import Settings
from database.repositories import UserRepository
from database.session import Database

logger = get_logger(__name__)


class DbSessionMiddleware(BaseMiddleware):
    """Opens one transaction-scoped session per update and injects ``session``/``user``."""

    def __init__(self, db: Database) -> None:
        self.db = db

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        async with self.db.session() as session:
            data["session"] = session
            telegram_user = getattr(event, "from_user", None)
            if telegram_user is not None:
                data["user"] = await UserRepository(session).get_or_create(
                    telegram_user.id,
                    username=telegram_user.username,
                    first_name=telegram_user.first_name,
                )
            return await handler(event, data)


class ThrottlingMiddleware(BaseMiddleware):
    """Cheap anti-flood: N updates per 10 seconds and a minimum gap between them."""

    def __init__(self, *, min_interval: float = 0.5, burst: int = 6, window: float = 10.0) -> None:
        self.min_interval = min_interval
        self.burst = burst
        self.window = window
        self._events: dict[int, deque[float]] = {}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = getattr(event, "from_user", None)
        if user is None:
            return await handler(event, data)

        now = time.monotonic()
        bucket = self._events.setdefault(user.id, deque())
        while bucket and now - bucket[0] > self.window:
            bucket.popleft()

        if bucket and now - bucket[-1] < self.min_interval:
            await self._reject(event)
            return None
        if len(bucket) >= self.burst:
            await self._reject(event)
            return None

        bucket.append(now)
        if len(self._events) > 10_000:  # pragma: no cover - protection for long uptime
            self._events = {uid: events for uid, events in self._events.items() if events}
        return await handler(event, data)

    @staticmethod
    async def _reject(event: TelegramObject) -> None:
        text = "⏳ Слишком много запросов. Подождите пару секунд."
        try:
            if isinstance(event, CallbackQuery):
                await event.answer(text, show_alert=False)
            elif isinstance(event, Message):
                await event.answer(text)
        except Exception:  # pragma: no cover - callback may be too old
            pass


async def error_handler(event: ErrorEvent, bot: Bot, settings: Settings) -> bool:
    """Log unexpected exceptions and tell the user something went wrong."""
    logger.error(
        "Update %s failed: %s",
        getattr(event.update, "update_id", "?"),
        event.exception,
        exc_info=event.exception,
    )
    update = event.update
    try:
        if update.callback_query is not None:
            await update.callback_query.answer(
                "⚠️ Внутренняя ошибка. Попробуйте ещё раз или откройте /start.",
                show_alert=True,
            )
        elif update.message is not None:
            await update.message.answer(
                "⚠️ Внутренняя ошибка. Попробуйте ещё раз или откройте /start."
            )
    except Exception:  # pragma: no cover - never fail inside the error handler
        pass
    return True


__all__ = ["DbSessionMiddleware", "ThrottlingMiddleware", "error_handler"]

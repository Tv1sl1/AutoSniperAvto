"""Telegram bot package."""

from bot.app import create_bot, create_dispatcher, set_bot_commands

__all__ = ["create_bot", "create_dispatcher", "set_bot_commands"]

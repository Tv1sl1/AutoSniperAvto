"""Typed callback-data factories (safe <64-byte packing)."""

from __future__ import annotations

from aiogram.filters.callback_data import CallbackData


class MenuCB(CallbackData, prefix="menu"):
    action: str


class AddSubCB(CallbackData, prefix="add"):
    action: str
    value: str = ""


class SubCB(CallbackData, prefix="sub"):
    action: str
    sub_id: int = 0
    page: int = 0


class PageCB(CallbackData, prefix="page"):
    page: int
    kind: str = "subs"


class SettingsCB(CallbackData, prefix="settings"):
    action: str


class SearchCB(CallbackData, prefix="search"):
    action: str
    sub_id: int = 0
    days: int = 0


__all__ = ["AddSubCB", "MenuCB", "PageCB", "SearchCB", "SettingsCB", "SubCB"]

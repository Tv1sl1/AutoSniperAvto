"""Aiogram application factory."""

from __future__ import annotations

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, BotCommandScopeChat

from bot.handlers import admin, fallback, help, search, start, subscriptions
from bot.middlewares import DbSessionMiddleware, ThrottlingMiddleware, error_handler
from config.settings import ConfigError, Settings
from database.session import Database
from services.notifier import TelegramNotifier
from services.orchestrator import ScraperOrchestrator


def create_bot(settings: Settings) -> Bot:
    if not settings.bot_token:
        raise ConfigError("BOT_TOKEN is empty — create a bot with @BotFather and put the token in .env")
    return Bot(
        token=settings.bot_token,
        session=AiohttpSession(
            timeout=float(settings.bot_request_timeout),
            proxy=settings.bot_proxy,
        ),
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML,
            link_preview_is_disabled=False,
        ),
    )


def create_dispatcher(
    *,
    db: Database,
    settings: Settings,
    orchestrator: ScraperOrchestrator,
    notifier: TelegramNotifier | None,
) -> Dispatcher:
    dispatcher = Dispatcher(storage=MemoryStorage())
    dispatcher["settings"] = settings
    dispatcher["db"] = db
    dispatcher["orchestrator"] = orchestrator
    dispatcher["notifier"] = notifier

    session_middleware = DbSessionMiddleware(db)
    throttling = ThrottlingMiddleware(
        min_interval=settings.throttle_min_interval,
        burst=settings.throttle_burst,
        window=settings.throttle_window,
    )
    for observer in (dispatcher.message, dispatcher.callback_query):
        observer.middleware(session_middleware)
        observer.middleware(throttling)

    dispatcher.include_routers(
        start.router,
        admin.router,
        subscriptions.router,
        search.router,
        help.router,
        fallback.router,
    )
    dispatcher.errors.register(error_handler)
    return dispatcher


async def set_bot_commands(bot: Bot, settings: Settings) -> None:
    user_commands = [
        BotCommand(command="start", description="Главное меню"),
        BotCommand(command="add", description="Добавить подписку"),
        BotCommand(command="subs", description="Мои подписки"),
        BotCommand(command="search", description="Разовый поиск сейчас"),
        BotCommand(command="settings", description="Настройки"),
        BotCommand(command="status", description="Статус системы"),
        BotCommand(command="help", description="Помощь"),
        BotCommand(command="delete_me", description="Удалить аккаунт и данные"),
        BotCommand(command="cancel", description="Отменить действие"),
    ]
    await bot.set_my_commands(user_commands)
    for admin_id in settings.admin_ids:
        try:
            await bot.set_my_commands(
                [*user_commands, BotCommand(command="admin", description="Админ-меню")],
                scope=BotCommandScopeChat(chat_id=admin_id),
            )
        except Exception:  # admin may not have started the bot yet
            continue


__all__ = ["create_bot", "create_dispatcher", "set_bot_commands"]

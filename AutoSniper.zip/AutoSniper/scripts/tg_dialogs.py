"""List Telegram dialogs with their numeric IDs.

Useful when a private channel has no public username: copy its ``-100...`` id
into ``TELEGRAM_CHANNELS``.

    python scripts/tg_dialogs.py
    python scripts/tg_dialogs.py --limit 100 --channels-only
    python scripts/tg_dialogs.py --grep bmw
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config.settings import Settings  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="List Telegram dialogs and their IDs")
    parser.add_argument("--limit", type=int, default=200, help="how many dialogs to scan (default: 200)")
    parser.add_argument("--channels-only", action="store_true", help="show only channels and groups")
    parser.add_argument("--grep", default="", help="filter by title or username (case-insensitive)")
    return parser.parse_args()


async def main() -> int:
    args = parse_args()
    settings = Settings.load()
    if not settings.telegram_api_id or not settings.telegram_api_hash:
        print("TELEGRAM_API_ID / TELEGRAM_API_HASH are not set. Fill .env first.")
        return 2

    try:
        from telethon import TelegramClient
        from telethon.tl.types import Channel
    except ImportError:
        print("Telethon is not installed: python -m pip install telethon")
        return 2

    session_path = Path(settings.telegram_session)
    client = TelegramClient(
        str(session_path),
        settings.telegram_api_id,
        settings.telegram_api_hash,
        flood_sleep_threshold=60,
        device_model="AutoSniper",
        system_version="1.0",
        app_version="1.0",
        lang_code="ru",
    )
    await client.connect()
    try:
        if not await client.is_user_authorized():
            print("Session is not authorized. Run `python scripts/tg_login.py` first.")
            return 2

        me = await client.get_me()
        username = f"@{me.username}" if getattr(me, "username", None) else "(no username)"
        print(f"Account: {me.first_name or ''} {username} (id={me.id})")
        print()
        print(f"{'ID':>16}  {'USERNAME':<26}  TITLE")
        print("-" * 78)

        needle = args.grep.lower()
        shown = 0
        async for dialog in client.iter_dialogs(limit=max(1, args.limit)):
            entity = dialog.entity
            if args.channels_only and not isinstance(entity, Channel):
                continue
            title = dialog.name or ""
            handle = getattr(entity, "username", None) or ""
            if needle and needle not in title.lower() and needle not in handle.lower():
                continue
            print(f"{dialog.id:>16}  {'@' + handle if handle else '-':<26}  {title[:48]}")
            shown += 1

        print()
        print(f"Shown: {shown}. Copy an ID (for example -1001234567890) or @username")
        print("into TELEGRAM_CHANNELS in .env, then restart the bot.")
        return 0
    finally:
        await client.disconnect()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))

"""Check VK token and community access without printing the token.

    python scripts/vk_check.py

Exit codes: 0 = token works and groups are readable, 1 = problems, 2 = no token.
"""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config.settings import Settings  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

API_URL = "https://api.vk.com/method"


def call(method: str, token: str, version: str, **params: object) -> dict:
    payload = {**params, "access_token": token, "v": version}
    request = urllib.request.Request(
        f"{API_URL}/{method}",
        data=urllib.parse.urlencode(payload).encode("utf-8"),
        headers={"User-Agent": "AutoSniper/1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return {"http_error": exc.code, "body": exc.read().decode("utf-8", "replace")[:300]}
    except Exception as exc:  # noqa: BLE001 - report any network problem
        return {"network_error": str(exc)}


def error_text(data: dict) -> str:
    error = data.get("error") or {}
    if error:
        return f"ERROR {error.get('error_code')}: {error.get('error_msg')}"
    if "http_error" in data:
        return f"HTTP {data['http_error']}: {data.get('body', '')}"
    if "network_error" in data:
        return f"NETWORK: {data['network_error']}"
    return "unknown error"


def normalize_group(group: str) -> str:
    cleaned = group.strip().rstrip("/")
    for prefix in ("https://vk.com/", "http://vk.com/", "vk.com/"):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix) :]
    return cleaned


def main() -> int:
    settings = Settings.load()
    token = (settings.vk_token or "").strip()
    version = settings.vk_api_version
    groups = [group for group in settings.vk_groups if group.strip()]

    if not token:
        print("VK_TOKEN is empty.")
        print("Get a user token with scope wall,groups,offline and put it into .env.")
        return 2

    print(f"VK API version: {version}")
    print(f"Token length: {len(token)} characters")
    if len(token) < 50:
        print("WARNING: this does not look like a real VK access token (expected 80+ chars).")

    me = call("users.get", token, version)
    if "response" not in me:
        print("Token: INVALID —", error_text(me))
        print()
        print("Get a new USER token:")
        print("  1. https://dev.vk.com -> Мои приложения -> Создать приложение (Standalone)")
        print("  2. Add redirect URI: https://oauth.vk.com/blank.html")
        print("  3. Open the OAuth URL with scope wall,groups,offline")
        print("  4. Copy access_token from the redirected URL into VK_TOKEN")
        print("Docs: D:\\AutoSniper\\SOURCES.md, section 2")
        return 1

    response = me["response"]
    if response:
        user = response[0]
        print(f"Token: OK, account: {user.get('first_name', '')} {user.get('last_name', '')}".rstrip())
    else:
        print("Token: OK (service/app token, no user context)")
        print("  Public wall.get and newsfeed.search are available; private communities need a user token.")

    if not groups:
        print("VK_GROUPS is empty — global newsfeed.search will be used.")
        sample = call("newsfeed.search", token, version, q="BMW", count=1)
        if "response" in sample:
            found = len((sample["response"] or {}).get("items") or [])
            print(f"newsfeed.search: OK (sample results: {found})")
            return 0
        print("newsfeed.search:", error_text(sample))
        return 1

    failures = 0
    for raw_group in groups:
        group = normalize_group(raw_group)
        print(f"\nGroup: {group}")
        if group.lower() in {"newsfeed.search", "wall.get", "wall", "search"}:
            print("  ERROR: this is a VK API method name, not a community.")
            print("  Put a community id (for example -12345678) or leave VK_GROUPS empty.")
            failures += 1
            continue

        if group.lstrip("-").isdigit():
            owner_id = int(group) if group.startswith("-") else -int(group)
            print(f"  numeric owner_id: {owner_id}")
        elif group.startswith(("club", "public")) and group[4:].isdigit():
            owner_id = -int(group[4:])
            print(f"  numeric owner_id: {owner_id}")
        else:
            resolved = call("utils.resolveScreenName", token, version, screen_name=group)
            response = resolved.get("response")
            if not response or isinstance(response, list):
                print("  cannot resolve:", error_text(resolved) if "error" in resolved else "not found")
                print("  Use the community URL (vk.com/club12345678) and put -12345678 into VK_GROUPS.")
                failures += 1
                continue
            owner_id = -int(response["object_id"])
            print(f"  resolved {response.get('type')} id={response['object_id']} -> {owner_id}")

        wall = call("wall.get", token, version, owner_id=owner_id, count=1, filter="owner")
        if "response" not in wall:
            print("  wall.get:", error_text(wall))
            failures += 1
            continue
        items = (wall["response"] or {}).get("items") or []
        count = (wall["response"] or {}).get("count")
        if items:
            published = datetime.fromtimestamp(int(items[0]["date"]), tz=UTC)
            print(f"  wall.get: OK, posts={count}, newest={published:%Y-%m-%d %H:%M UTC}")
        else:
            print(f"  wall.get: OK, posts={count}, no items")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Interactive Telethon login — run once to create the user session.

    python scripts/tg_login.py

The session file path comes from TELEGRAM_SESSION (default: data/telegram_scraper).
It grants full access to the account, so keep it private.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config.settings import Settings  # noqa: E402


async def main() -> int:
    settings = Settings.load()
    if not settings.telegram_api_id or not settings.telegram_api_hash:
        print("TELEGRAM_API_ID / TELEGRAM_API_HASH are not set.")
        print("Create an application at https://my.telegram.org -> API development tools")
        print("and put both values into .env.")
        return 2

    try:
        from telethon import TelegramClient
    except ImportError:
        print("Telethon is not installed: pip install telethon")
        return 2

    session_path = Path(settings.telegram_session)
    session_path.parent.mkdir(parents=True, exist_ok=True)

    print("Logging in to Telegram. Enter the phone number of the account that")
    print("will read the sale channels, then the code from Telegram.")
    print(f"Session file: {session_path}")
    print()

    client = TelegramClient(str(session_path), settings.telegram_api_id, settings.telegram_api_hash)
    await client.start()
    me = await client.get_me()
    username = f"@{me.username}" if me.username else "(no username)"
    print()
    print(f"Authorized as {me.first_name or ''} {username} (id={me.id})")

    dialogs = await client.get_dialogs(limit=5)
    if dialogs:
        print("First dialogs in this account:")
        for dialog in dialogs:
            print(f"  - {dialog.name}")
    await client.disconnect()
    print()
    print("Done. Put the channel usernames into TELEGRAM_CHANNELS and start the bot.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))

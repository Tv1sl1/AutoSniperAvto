@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoSniper - Telegram login

set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"

"%PYTHON%" --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    pause
    exit /b 1
)

echo Telegram login for the scraper user session.
echo You will be asked for the phone number and the code from Telegram.
echo.
"%PYTHON%" scripts\tg_login.py
echo.
echo Press any key to close.
pause >nul

"""Async orchestration: periodic scraping, backoff, cursors and ad-hoc search."""

from __future__ import annotations

import asyncio
import random
import time
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from config.logger import get_logger
from config.settings import Settings
from database.models import Listing, Subscription
from database.repositories import ScraperStateRepository, SubscriptionRepository, utcnow
from database.session import Database
from scrapers.base import BaseScraper, RawListing, ScrapeBatch, SearchQuery
from services.agents import quality_agent
from services.net import ScraperError
from services.normalizer import normalize_raw
from services.pipeline import IngestionPipeline

logger = get_logger(__name__)

__all__ = ["CycleReport", "FetchedBatch", "ScraperOrchestrator", "ScraperOutcome"]


@dataclass(slots=True)
class ScraperOutcome:
    name: str
    ok: bool
    found: int = 0
    created: int = 0
    notifications: int = 0
    error: str | None = None
    duration: float = 0.0
    skipped: bool = False


@dataclass(slots=True)
class FetchedBatch:
    name: str
    batch: ScrapeBatch | None
    error: str | None
    duration: float


@dataclass(slots=True)
class CycleReport:
    started_at: datetime = field(default_factory=utcnow)
    duration: float = 0.0
    outcomes: list[ScraperOutcome] = field(default_factory=list)

    @property
    def total_found(self) -> int:
        return sum(outcome.found for outcome in self.outcomes)

    @property
    def total_created(self) -> int:
        return sum(outcome.created for outcome in self.outcomes)

    @property
    def total_notifications(self) -> int:
        return sum(outcome.notifications for outcome in self.outcomes)

    @property
    def failures(self) -> list[ScraperOutcome]:
        return [outcome for outcome in self.outcomes if not outcome.ok]


class ScraperOrchestrator:
    def __init__(
        self,
        *,
        db: Database,
        pipeline: IngestionPipeline,
        scrapers: Sequence[BaseScraper],
        settings: Settings,
    ) -> None:
        self.db = db
        self.pipeline = pipeline
        self.scrapers = list(scrapers)
        self.settings = settings
        self._locks: dict[str, asyncio.Lock] = {scraper.name: asyncio.Lock() for scraper in self.scrapers}
        self._failures: dict[str, int] = {}
        self._next_allowed: dict[str, float] = {}
        self._stop = asyncio.Event()
        self.last_quality = None
        self._started_at: datetime | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    @property
    def stopped(self) -> bool:
        return self._stop.is_set()

    def stop(self) -> None:
        self._stop.set()

    async def close(self) -> None:
        self.stop()
        for scraper in self.scrapers:
            try:
                await scraper.close()
            except Exception as exc:  # pragma: no cover - shutdown best effort
                logger.warning("Error closing scraper %s: %s", scraper.name, exc)

    async def run_forever(self) -> None:
        self._started_at = utcnow()
        logger.info(
            "Orchestrator started: scrapers=%s, interval=%ss",
            ", ".join(scraper.name for scraper in self.scrapers) or "none",
            self.settings.poll_interval_seconds,
        )
        while not self._stop.is_set():
            try:
                report = await self.run_cycle()
                logger.info(
                    "Cycle finished in %.1fs: found=%s new=%s notifications=%s failures=%s",
                    report.duration,
                    report.total_found,
                    report.total_created,
                    report.total_notifications,
                    ", ".join(outcome.name for outcome in report.failures) or "none",
                )
            except asyncio.CancelledError:
                raise
            except Exception:  # the poll loop must survive any cycle-level bug
                logger.exception("Unhandled error during scraping cycle")

            delay = max(30, self.settings.poll_interval_seconds) + random.uniform(
                0, max(0.0, self.settings.poll_jitter_seconds)
            )
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=delay)
            except TimeoutError:
                continue

    # ------------------------------------------------------------------
    # One cycle
    # ------------------------------------------------------------------
    async def run_cycle(self) -> CycleReport:
        report = CycleReport()
        started = time.monotonic()

        if self._stop.is_set():
            report.duration = 0.0
            return report

        if self.pipeline.notifier is not None:
            try:
                await self.pipeline.retry_pending()
            except Exception as exc:  # pragma: no cover - retry best effort
                logger.warning("Pending notification retry failed: %s", exc)

        async with self.db.session() as session:
            subscriptions = await SubscriptionRepository(session).list_active()
            states = await ScraperStateRepository(session).list_all()
        cursors = {state.name: dict(state.cursor or {}) for state in states}

        queries = self._build_queries(subscriptions)
        if not queries:
            logger.info("No active subscriptions — scraping cycle skipped")
            report.duration = time.monotonic() - started
            return report

        active_scrapers: list[BaseScraper] = []
        now = time.monotonic()
        for scraper in self.scrapers:
            if not scraper.enabled:
                continue
            if self._next_allowed.get(scraper.name, 0.0) > now:
                report.outcomes.append(
                    ScraperOutcome(
                        name=scraper.name,
                        ok=True,
                        error="backoff",
                        skipped=True,
                    )
                )
                continue
            active_scrapers.append(scraper)

        if not active_scrapers:
            report.duration = time.monotonic() - started
            return report

        fetch_tasks = [
            asyncio.create_task(self._fetch(scraper, cursors.get(scraper.name), queries))
            for scraper in active_scrapers
        ]
        fetched = await asyncio.gather(*fetch_tasks, return_exceptions=True)

        for result in fetched:
            if isinstance(result, BaseException):
                logger.error("Scraper task crashed: %s", result)
                continue

            outcome = ScraperOutcome(name=result.name, ok=False, duration=result.duration)
            if result.error is not None or result.batch is None:
                outcome.error = result.error or "unknown error"
                await self._record_failure(result.name, outcome.error)
                report.outcomes.append(outcome)
                continue

            batch = result.batch
            outcome.found = len(batch.listings)
            try:
                stats = await self.pipeline.ingest(batch.listings)
                outcome.created = stats.created
                outcome.notifications = stats.notifications
                await self._record_success(result.name, batch.cursor, len(batch.listings))
                self._failures.pop(result.name, None)
                self._next_allowed.pop(result.name, None)
                outcome.ok = True
            except Exception as exc:
                logger.exception("Ingestion failed for %s", result.name)
                outcome.error = f"ingest: {exc}"
                await self._record_failure(result.name, outcome.error)
            report.outcomes.append(outcome)

        report.duration = time.monotonic() - started
        return report

    async def _fetch(
        self,
        scraper: BaseScraper,
        cursor: dict[str, Any] | None,
        queries: Sequence[SearchQuery],
    ) -> FetchedBatch:
        started = time.monotonic()
        lock = self._locks[scraper.name]
        try:
            async with lock:
                batch = await asyncio.wait_for(
                    scraper.fetch(cursor, queries),
                    timeout=max(10, self.settings.scraper_timeout_seconds),
                )
            return FetchedBatch(scraper.name, batch, None, time.monotonic() - started)
        except asyncio.CancelledError:
            raise
        except TimeoutError:
            return FetchedBatch(
                scraper.name,
                None,
                f"timeout after {self.settings.scraper_timeout_seconds}s",
                time.monotonic() - started,
            )
        except Exception as exc:
            logger.warning("Scraper %s failed: %s", scraper.name, exc)
            return FetchedBatch(scraper.name, None, str(exc), time.monotonic() - started)

    async def _record_success(self, name: str, cursor: dict[str, Any], found: int) -> None:
        async with self.db.session() as session:
            await ScraperStateRepository(session).record_success(name, cursor=cursor, found=found)

    async def _record_failure(self, name: str, error: str) -> None:
        failures = self._failures.get(name, 0) + 1
        self._failures[name] = failures
        delay = min(
            max(self.settings.backoff_base_seconds, 5.0) * (2 ** (failures - 1)),
            max(self.settings.backoff_max_seconds, 60.0),
        ) * random.uniform(0.8, 1.2)
        self._next_allowed[name] = time.monotonic() + delay
        logger.warning(
            "Scraper %s failed %s time(s) in a row: %s — next attempt in %.0fs",
            name,
            failures,
            error,
            delay,
        )
        try:
            async with self.db.session() as session:
                await ScraperStateRepository(session).record_failure(name, error)
        except Exception as exc:  # pragma: no cover - DB issue during error handling
            logger.error("Cannot persist failure state for %s: %s", name, exc)

    @staticmethod
    def _build_queries(subscriptions: Sequence[Subscription]) -> list[SearchQuery]:
        queries: list[SearchQuery] = []
        seen: set[str] = set()
        for subscription in subscriptions:
            query = SearchQuery.from_subscription(subscription)
            label = query.label().lower()
            if label in seen:
                continue
            seen.add(label)
            queries.append(query)
        return queries

    # ------------------------------------------------------------------
    # Ad-hoc search
    # ------------------------------------------------------------------
    async def search_now(
        self,
        query: SearchQuery,
        *,
        limit: int | None = None,
        max_age_days: int | None = None,
    ) -> list[Listing]:
        """Search every search-capable scraper, without storing or notifying.

        ``max_age_days`` limits results to listings published recently
        (``0``/``None`` disables the limit).
        """
        limit = limit or self.settings.single_search_limit
        searchable = [scraper for scraper in self.scrapers if scraper.supports_search and scraper.enabled]
        if not searchable:
            raise ScraperError(
                "Ни один источник не поддерживает разовый поиск. "
                "Проверьте WEB_TARGETS / Telegram / VK в настройках."
            )

        expanded_queries = query.expand()
        tasks = []
        for scraper in searchable:
            queries_for_scraper = expanded_queries if scraper.expand_search_queries else [query]
            tasks.extend(
                asyncio.create_task(self._search_one(scraper, item, limit * 10))
                for item in queries_for_scraper
            )
        done, pending = await asyncio.wait(
            tasks, timeout=max(10, self.settings.single_search_timeout_seconds)
        )
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

        raws: list[RawListing] = []
        for task in done:
            try:
                raws.extend(task.result())
            except Exception as exc:
                logger.warning("Ad-hoc search source failed: %s", exc)

        models = list(query.models) or ([query.model] if query.model else [])
        target = Subscription(
            make=query.make,
            model=query.model,
            models=models,
            max_price=query.max_price,
            city=query.city,
            max_distance_km=query.max_distance_km,
            max_age_days=max_age_days,
        )
        results: list[Listing] = []
        seen: set[str] = set()
        for raw in raws:
            listing = normalize_raw(raw).listing
            if listing.hash_id in seen:
                continue
            seen.add(listing.hash_id)
            if not self.pipeline.matcher.match(listing, target).matched:
                continue
            results.append(listing)

        results.sort(key=_recency_key, reverse=True)
        report = quality_agent.audit(query, results)
        self.last_quality = report
        if report.notes:
            logger.info(
                "Search quality (%s): %s", query.search_label(), "; ".join(report.notes)
            )
        return results[:limit]

    async def _search_one(
        self, scraper: BaseScraper, query: SearchQuery, limit: int
    ) -> list[RawListing]:
        async with self._locks[scraper.name]:
            return await scraper.search(query, limit=limit)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------
    async def status_snapshot(self) -> list[dict[str, Any]]:
        async with self.db.session() as session:
            states = {state.name: state for state in await ScraperStateRepository(session).list_all()}

        snapshot: list[dict[str, Any]] = []
        now = time.monotonic()
        for scraper in self.scrapers:
            state = states.get(scraper.name)
            next_in = max(0.0, self._next_allowed.get(scraper.name, 0.0) - now)
            snapshot.append(
                {
                    "name": scraper.name,
                    "enabled": scraper.enabled,
                    "last_success_at": state.last_success_at if state else None,
                    "last_error": state.last_error if state else None,
                    "consecutive_failures": state.consecutive_failures if state else 0,
                    "total_listings": state.total_listings if state else 0,
                    "next_attempt_in": next_in,
                }
            )
        return snapshot

    def describe(self) -> str:
        names = ", ".join(scraper.name for scraper in self.scrapers) or "нет"
        return (
            f"Источники: {names}. Интервал опроса: {self.settings.poll_interval_seconds} с."
        )

    @property
    def started_at(self) -> datetime | None:
        return self._started_at


def _recency_key(listing: Listing) -> float:
    published = listing.published_at
    if published is None:
        return 0.0
    if published.tzinfo is None:
        published = published.replace(tzinfo=UTC)
    return published.timestamp()

"""City coordinates and distance helpers.

The list covers the cities supported by the parser. Coordinates are city-centre
approximations (sufficient for radius filtering in tens of kilometres). Cities
outside the list cannot be used with a distance filter.
"""

from __future__ import annotations

from math import asin, cos, radians, sin, sqrt

from services.parser_engine import canonical_city, normalize_city

EARTH_RADIUS_KM = 6371.0088

# Approximate city-centre coordinates (lat, lon).
CITY_COORDINATES: dict[str, tuple[float, float]] = {    "Москва": (55.7558, 37.6173),
    "Санкт-Петербург": (59.9343, 30.3351),
    "Екатеринбург": (56.8389, 60.6057),
    "Нижний Тагил": (57.9101, 59.9813),
    "Каменск-Уральский": (56.4149, 61.9187),
    "Первоуральск": (56.9046, 59.9436),
    "Асбест": (57.0054, 61.4585),
    "Серов": (59.6030, 60.5787),
    "Новоуральск": (57.2439, 60.0839),
    "Верхняя Пышма": (56.9764, 60.5816),
    "Верхние Серги": (56.6500, 59.5500),
    "Малышева": (57.1167, 61.4000),
    "Березовский": (56.9080, 60.8120),
    "Ревда": (56.8000, 59.9300),
    "Полевской": (56.4950, 60.1900),
    "Краснотурьинск": (59.7667, 60.2000),
    "Сухой Лог": (56.9000, 62.0333),
    "Алапаевск": (57.8500, 61.7000),
    "Ирбит": (57.6700, 63.0600),
    "Реж": (57.4000, 60.3667),
    "Заречный": (56.8167, 61.3167),
    "Сысерть": (56.5000, 60.8167),
    "Арамиль": (56.7000, 60.8333),
    "Среднеуральск": (56.9833, 60.4667),
    "Невьянск": (57.4833, 60.2167),
    "Кировград": (57.4333, 60.0500),
    "Качканар": (58.7000, 59.4833),
    "Красноуфимск": (56.6167, 57.7667),
    "Артемовский": (57.3333, 61.8833),
    "Богданович": (56.7833, 62.0500),
    "Карпинск": (59.7667, 60.0000),
    "Североуральск": (60.1500, 59.9500),
    "Верхняя Салда": (58.0500, 60.5500),
    "Нижняя Салда": (58.0833, 60.7167),
    "Новосибирск": (55.0084, 82.9357),
    "Краснодар": (45.0355, 38.9753),
    "Сочи": (43.5855, 39.7231),
    "Казань": (55.7961, 49.1064),
    "Самара": (53.1959, 50.1002),
    "Уфа": (54.7388, 55.9721),
    "Челябинск": (55.1644, 61.4368),
    "Омск": (54.9885, 73.3242),
    "Тюмень": (57.1522, 65.5272),
    "Пермь": (58.0105, 56.2502),
    "Волгоград": (48.7080, 44.5133),
    "Воронеж": (51.6720, 39.1843),
    "Саратов": (51.5336, 46.0343),
    "Тольятти": (53.5078, 49.4204),
    "Ижевск": (56.8527, 53.2115),
    "Барнаул": (53.3548, 83.7698),
    "Ульяновск": (54.3142, 48.4031),
    "Иркутск": (52.2870, 104.3050),
    "Хабаровск": (48.4827, 135.0838),
    "Владивосток": (43.1155, 131.8855),
    "Ярославль": (57.6261, 39.8845),
    "Махачкала": (42.9849, 47.5047),
    "Томск": (56.4977, 84.9744),
    "Оренбург": (51.7682, 55.0969),
    "Кемерово": (55.3547, 86.0873),
    "Новокузнецк": (53.7557, 87.1099),
    "Рязань": (54.6269, 39.6916),
    "Астрахань": (46.3497, 48.0408),
    "Пенза": (53.2007, 45.0046),
    "Липецк": (52.6031, 39.5708),
    "Киров": (58.6036, 49.6680),
    "Чебоксары": (56.1462, 47.2489),
    "Тула": (54.1961, 37.6182),
    "Калининград": (54.7104, 20.4522),
    "Курск": (51.7304, 36.1926),
    "Ставрополь": (45.0428, 41.9734),
    "Тверь": (56.8587, 35.9176),
    "Магнитогорск": (53.4186, 59.0472),
    "Иваново": (57.0004, 40.9739),
    "Брянск": (53.2434, 34.3639),
    "Белгород": (50.5977, 36.5858),
    "Сургут": (61.2540, 73.3962),
    "Владимир": (56.1290, 40.4070),
    "Архангельск": (64.5393, 40.5184),
    "Чита": (52.0340, 113.4994),
    "Грозный": (43.3169, 45.6981),
    "Смоленск": (54.7818, 32.0401),
    "Курган": (55.4408, 65.3411),
    "Орел": (52.9651, 36.0785),
    "Череповец": (59.1269, 37.9090),
    "Вологда": (59.2181, 39.8886),
    "Мурманск": (68.9585, 33.0827),
    "Петрозаводск": (61.7849, 34.3469),
    "Йошкар-Ола": (56.6388, 47.8908),
    "Таганрог": (47.2095, 38.9352),
    "Нальчик": (43.4981, 43.6189),
    "Шахты": (47.7085, 40.2159),
    "Дзержинск": (56.2377, 43.4595),
    "Орск": (51.2290, 58.4752),
    "Сыктывкар": (61.6688, 50.8370),
    "Нижневартовск": (60.9397, 76.5690),
    "Новороссийск": (44.7239, 37.7686),
    "Нижний Новгород": (56.3269, 44.0059),
    "Ростов-на-Дону": (47.2357, 39.7015),
    "Улан-Удэ": (51.8335, 107.5841),
    "Комсомольск-на-Амуре": (50.5500, 137.0070),
    "Химки": (55.8892, 37.4450),
    "Подольск": (55.4312, 37.5450),
    "Красногорск": (55.8317, 37.3300),
    "Мытищи": (55.9116, 37.7308),
    "Балашиха": (55.7969, 37.9385),
    "Королев": (55.9142, 37.8255),
    "Люберцы": (55.6758, 37.8938),
    "Одинцово": (55.6789, 37.2639),
    "Минск": (53.9045, 27.5615),
    "Гомель": (52.4412, 30.9878),
    "Брест": (52.0976, 23.7341),
    "Витебск": (55.1904, 30.2049),
    "Гродно": (53.6688, 23.8223),
    "Могилев": (53.9007, 30.3319),
    "Алматы": (43.2220, 76.8512),
    "Астана": (51.1694, 71.4491),
    "Шымкент": (42.3417, 69.5901),
    "Караганда": (49.8047, 73.1094),
    "Актобе": (50.2839, 57.1670),
    "Бишкек": (42.8746, 74.5698),
    "Ташкент": (41.2995, 69.2401),
    "Ереван": (40.1872, 44.5152),
    "Тбилиси": (41.7151, 44.8271),
    "Баку": (40.4093, 49.8671),
    "Киев": (50.4501, 30.5234),
    "Харьков": (49.9935, 36.2304),
    "Одесса": (46.4825, 30.7233),
    "Днепр": (48.4647, 35.0462),
}

# URL slugs used by Avito / Auto.ru / Drom.
CITY_SLUGS: dict[str, str] = {
    "moskva": "Москва",
    "moscow": "Москва",
    "sankt-peterburg": "Санкт-Петербург",
    "saint-petersburg": "Санкт-Петербург",
    "spb": "Санкт-Петербург",
    "ekaterinburg": "Екатеринбург",
    "nizhny-tagil": "Нижний Тагил",
    "nizhniy-tagil": "Нижний Тагил",
    "kamensk-uralsky": "Каменск-Уральский",
    "pervouralsk": "Первоуральск",
    "asbest": "Асбест",
    "serov": "Серов",
    "novouralsk": "Новоуральск",
    "verkhnyaya-pyshma": "Верхняя Пышма",
    "verkhnie-sergi": "Верхние Серги",
    "malysheva": "Малышева",
    "berezovsky": "Березовский",
    "revda": "Ревда",
    "polevskoy": "Полевской",
    "krasnoturinsk": "Краснотурьинск",
    "sukhoy-log": "Сухой Лог",
    "alapaevsk": "Алапаевск",
    "irbit": "Ирбит",
    "rezh": "Реж",
    "zarechny": "Заречный",
    "sysert": "Сысерть",
    "aramil": "Арамиль",
    "sredneuralsk": "Среднеуральск",
    "nevyansk": "Невьянск",
    "kirovgrad": "Кировград",
    "kachkanar": "Качканар",
    "krasnoufimsk": "Красноуфимск",
    "artemovsky": "Артемовский",
    "bogdanovich": "Богданович",
    "karpinsk": "Карпинск",
    "severouralsk": "Североуральск",
    "verkhnyaya-salda": "Верхняя Салда",
    "nizhnyaya-salda": "Нижняя Салда",
    "novosibirsk": "Новосибирск",
    "krasnodar": "Краснодар",
    "sochi": "Сочи",
    "kazan": "Казань",
    "samara": "Самара",
    "ufa": "Уфа",
    "chelyabinsk": "Челябинск",
    "omsk": "Омск",
    "tyumen": "Тюмень",
    "perm": "Пермь",
    "volgograd": "Волгоград",
    "voronezh": "Воронеж",
    "saratov": "Саратов",
    "tolyatti": "Тольятти",
    "izhevsk": "Ижевск",
    "barnaul": "Барнаул",
    "ulyanovsk": "Ульяновск",
    "irkutsk": "Иркутск",
    "khabarovsk": "Хабаровск",
    "vladivostok": "Владивосток",
    "yaroslavl": "Ярославль",
    "makhachkala": "Махачкала",
    "tomsk": "Томск",
    "orenburg": "Оренбург",
    "kemerovo": "Кемерово",
    "novokuznetsk": "Новокузнецк",
    "ryazan": "Рязань",
    "astrakhan": "Астрахань",
    "penza": "Пенза",
    "lipetsk": "Липецк",
    "kirov": "Киров",
    "cheboksary": "Чебоксары",
    "tula": "Тула",
    "kaliningrad": "Калининград",
    "kursk": "Курск",
    "stavropol": "Ставрополь",
    "tver": "Тверь",
    "magnitogorsk": "Магнитогорск",
    "ivanovo": "Иваново",
    "bryansk": "Брянск",
    "belgorod": "Белгород",
    "surgut": "Сургут",
    "vladimir": "Владимир",
    "arkhangelsk": "Архангельск",
    "chita": "Чита",
    "grozny": "Грозный",
    "smolensk": "Смоленск",
    "kurgan": "Курган",
    "orel": "Орел",
    "cherepovets": "Череповец",
    "vologda": "Вологда",
    "murmansk": "Мурманск",
    "petrozavodsk": "Петрозаводск",
    "yoshkar-ola": "Йошкар-Ола",
    "taganrog": "Таганрог",
    "nalchik": "Нальчик",
    "shakhty": "Шахты",
    "dzerzhinsk": "Дзержинск",
    "orsk": "Орск",
    "syktyvkar": "Сыктывкар",
    "nizhnevartovsk": "Нижневартовск",
    "novorossiysk": "Новороссийск",
    "nizhny-novgorod": "Нижний Новгород",
    "rostov-na-donu": "Ростов-на-Дону",
    "ulan-ude": "Улан-Удэ",
}


def city_from_slug(value: str | None) -> str | None:
    if not value:
        return None
    return CITY_SLUGS.get(value.strip().lower().replace("_", "-"))


def slug_for_city(city: str | None) -> str | None:
    canonical = canonical_name(city)
    if not canonical:
        return None
    for slug, name in CITY_SLUGS.items():
        if name == canonical:
            return slug
    return None


def canonical_name(city: str | None) -> str | None:
    if not city:
        return None
    return canonical_city(city) or normalize_city(city)


def coordinates_for(city: str | None) -> tuple[float, float] | None:
    name = canonical_name(city)
    return CITY_COORDINATES.get(name) if name else None


def has_coordinates(city: str | None) -> bool:
    return coordinates_for(city) is not None


def haversine_km(
    lat1: float,
    lon1: float,
    lat2: float,
    lon2: float,
) -> float:
    """Great-circle distance in kilometres."""
    phi1, phi2 = radians(lat1), radians(lat2)
    d_phi = radians(lat2 - lat1)
    d_lambda = radians(lon2 - lon1)
    a = sin(d_phi / 2) ** 2 + cos(phi1) * cos(phi2) * sin(d_lambda / 2) ** 2
    return 2 * EARTH_RADIUS_KM * asin(sqrt(a))


def distance_between_cities(city_a: str | None, city_b: str | None) -> float | None:
    first = coordinates_for(city_a)
    second = coordinates_for(city_b)
    if first is None or second is None:
        return None
    return haversine_km(first[0], first[1], second[0], second[1])


def city_within_radius(center: str | None, candidate: str | None, radius_km: float) -> bool | None:
    """``True/False`` when both cities are known, ``None`` otherwise."""
    distance = distance_between_cities(center, candidate)
    if distance is None:
        return None
    return distance <= radius_km


__all__ = [
    "CITY_COORDINATES",
    "CITY_SLUGS",
    "canonical_name",
    "city_from_slug",
    "city_within_radius",
    "coordinates_for",
    "distance_between_cities",
    "has_coordinates",
    "haversine_km",
    "slug_for_city",
]

"""Telegram delivery: rich HTML cards with photos and resilient error handling."""

from __future__ import annotations

import asyncio
import html
from pathlib import Path
from urllib.parse import urlsplit

from aiogram import Bot
from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramRetryAfter,
)
from aiogram.types import FSInputFile

from config.logger import get_logger
from database.models import Listing, Source, Subscription
from services.formatting import format_datetime, format_price, truncate
from services.net import RateLimiter
from services.pipeline import DeliveryOutcome, DeliveryResult

logger = get_logger(__name__)

CAPTION_LIMIT = 1024
DEFAULT_HEADER = "🚗 <b>НАЙДЕН АВТОМОБИЛЬ!</b>"

__all__ = ["TelegramNotifier", "source_label"]


def source_label(listing: Listing) -> str:
    """Human-readable source, e.g. ``Telegram (@auto_sale_msk)``."""
    if listing.source is Source.TG:
        path = urlsplit(listing.url).path.strip("/").split("/")
        if path and path[0] and path[0] != "c":
            return f"Telegram (@{path[0]})"
        return "Telegram"
    return {
        Source.VK: "VKontakte",
        Source.AVITO: "Avito",
        Source.AUTORU: "Auto.ru",
        Source.DROM: "Drom.ru",
        Source.RSS: "RSS",
    }.get(listing.source, listing.source.value)


def _safe(value: str | None) -> str:
    return html.escape(value or "", quote=False)


class TelegramNotifier:
    """Sends match cards and reports a machine-readable delivery outcome."""

    def __init__(
        self,
        bot: Bot,
        *,
        rate_per_second: float = 20.0,
        allowed_link_domains: tuple[str, ...] = (),
    ) -> None:
        self.bot = bot
        self.rate_limiter = RateLimiter(rate_per_second)
        self.allowed_link_domains = tuple(
            item.lower().lstrip(".") for item in allowed_link_domains if item
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def send_match(
        self,
        user_id: int,
        listing: Listing,
        subscription: Subscription | None = None,
    ) -> DeliveryResult:
        await self.rate_limiter.acquire()
        try:
            await self._deliver(user_id, listing, header=DEFAULT_HEADER)
            return DeliveryResult(DeliveryOutcome.SENT)
        except TelegramRetryAfter as exc:
            wait_for = float(getattr(exc, "retry_after", 5) or 5)
            logger.warning("Flood control: retrying message to %s in %.1fs", user_id, wait_for)
            await asyncio.sleep(min(wait_for + 1, 300))
            try:
                await self._deliver(user_id, listing, header=DEFAULT_HEADER)
                return DeliveryResult(DeliveryOutcome.SENT)
            except TelegramForbiddenError:
                return DeliveryResult(DeliveryOutcome.BLOCKED, "bot blocked by user")
            except TelegramBadRequest as retry_exc:
                return DeliveryResult(DeliveryOutcome.FAILED, str(retry_exc))
            except TelegramAPIError as retry_exc:
                return DeliveryResult(DeliveryOutcome.FAILED, str(retry_exc))
        except TelegramForbiddenError:
            return DeliveryResult(DeliveryOutcome.BLOCKED, "bot blocked by user")
        except TelegramBadRequest as exc:
            logger.warning("Bad request while sending to %s: %s", user_id, exc)
            return DeliveryResult(DeliveryOutcome.FAILED, str(exc))
        except TelegramAPIError as exc:
            logger.warning("Telegram API error while sending to %s: %s", user_id, exc)
            return DeliveryResult(DeliveryOutcome.FAILED, str(exc))
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("Unexpected notifier error for %s", user_id)
            return DeliveryResult(DeliveryOutcome.FAILED, str(exc))

    async def send_listing(
        self,
        chat_id: int,
        listing: Listing,
        *,
        header: str = DEFAULT_HEADER,
        footer: str | None = None,
    ) -> bool:
        """Public helper for ad-hoc search results."""
        await self.rate_limiter.acquire()
        return await self._deliver(chat_id, listing, header=header, footer=footer)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _deliver(
        self,
        chat_id: int,
        listing: Listing,
        *,
        header: str,
        footer: str | None = None,
    ) -> bool:
        caption = self.build_caption(listing, header=header, footer=footer)
        photo = self._resolve_photo(listing)
        if photo is not None:
            try:
                await self.bot.send_photo(
                    chat_id=chat_id,
                    photo=photo,
                    caption=caption,
                    parse_mode="HTML",
                )
                return True
            except TelegramBadRequest as exc:
                # Expired external image URL or unsupported format: fall back to text.
                logger.info("Photo delivery failed, falling back to text: %s", exc)
            except TelegramRetryAfter:
                raise
            except TelegramForbiddenError:
                raise
        await self.bot.send_message(
            chat_id=chat_id,
            text=caption,
            parse_mode="HTML",
            disable_web_page_preview=False,
        )
        return True

    def build_caption(
        self,
        listing: Listing,
        *,
        header: str = DEFAULT_HEADER,
        footer: str | None = None,
        limit: int = CAPTION_LIMIT,
    ) -> str:
        title = listing.title or "Автомобиль"
        if listing.make:
            title = f"{listing.make} {listing.model or ''}".strip()

        source = source_label(listing)
        url = listing.url if (listing.url and listing.url.startswith("http")) else ""
        if url and not self._link_allowed(url):
            url = ""
        price_text = format_price(listing.price) if listing.price else "не указана"
        lines = [
            header,
            "",
            f"📌 <b>Модель:</b> {_safe(title)}",
            f"💰 <b>Цена:</b> {_safe(price_text)}",
            f"📍 <b>Город:</b> {_safe(listing.city or 'не указан')}",
            f"🌐 <b>Источник:</b> {_safe(source)}",
        ]
        if listing.year:
            lines.append(f"📅 <b>Год:</b> {listing.year}")
        if getattr(listing, "generation", None):
            lines.append(f"🔧 <b>Поколение/кузов:</b> {_safe(listing.generation)}")
        if getattr(listing, "transmission", None):
            lines.append(f"⚙️ <b>КПП:</b> {_safe(listing.transmission)}")
        if getattr(listing, "engine_volume", None):
            lines.append(f"🧾 <b>Объём:</b> {listing.engine_volume:g} л")
        if getattr(listing, "date_approx", False):
            lines.append("📅 <b>Дата:</b> приблизительная")
        elif listing.published_at is not None:
            lines.append(
                f"🕒 <b>Опубликовано:</b> {_safe(format_datetime(listing.published_at))}"
            )

        description = self._description(listing, title)
        tail = ""
        if url:
            tail += f'\n\n🔗 <a href="{html.escape(url, quote=True)}">Открыть объявление</a>'
        if footer:
            tail += f"\n\n{footer}"

        head = "\n".join(lines)
        description_prefix = "\n\n📝 <b>Описание:</b> "
        budget = limit - len(head) - len(tail) - len(description_prefix) - 1
        if description and budget > 40:
            excerpt = truncate(description, budget)
            while excerpt and len(head) + len(description_prefix) + len(html.escape(excerpt, quote=False)) + len(tail) > limit:
                excerpt = excerpt[:-20].rstrip()
            if excerpt:
                head += description_prefix + _safe(excerpt)
        return head + tail

    @staticmethod
    def _description(listing: Listing, title: str) -> str:
        raw = (listing.raw_text or "").strip()
        if not raw:
            return ""
        if title and raw.lower().startswith(title.lower()):
            raw = raw[len(title) :].lstrip(" \n-—:.,")
        return " ".join(raw.split())

    def _link_allowed(self, url: str) -> bool:
        if not self.allowed_link_domains:
            return True
        host = (urlsplit(url).hostname or "").lower().rstrip(".")
        return any(
            host == domain or host.endswith("." + domain)
            for domain in self.allowed_link_domains
        )

    @staticmethod
    def _resolve_photo(listing: Listing) -> FSInputFile | str | None:
        for photo in listing.photos or []:
            if not photo:
                continue
            if photo.startswith(("http://", "https://")):
                return photo
            path = Path(photo)
            if path.is_file() and path.stat().st_size > 0:
                return FSInputFile(str(path))
        return None

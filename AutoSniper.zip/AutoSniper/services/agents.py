"""Local agents for query validation and cheap text cleanup.

No external LLM/API calls: everything runs locally with stdlib ``difflib`` and
the brand/model/city dictionaries already used by the parser. This keeps the
token/ruble cost at zero and works offline.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from difflib import SequenceMatcher, get_close_matches
from functools import lru_cache

from services.parser_engine import (
    BRAND_ALIASES,
    CITY_ALIASES,
    MODEL_ALIASES,
    normalize_make,
    normalize_model,
)
from services.synonyms_dict import canonical_model

__all__ = [
    "EntityFix",
    "ModelCheck",
    "QualityReport",
    "SearchQualityAgent",
    "TextCheck",
    "TextAgent",
    "model_agent",
    "quality_agent",
    "text_agent",
]

# Curated catalog is intentionally small: it is a spelling aid, not a full
# vehicle database. Unknown models are kept unless a close known model exists.
KNOWN_MODELS: dict[str, tuple[str, ...]] = {
    "Lada": (
        "2101", "2102", "2103", "2104", "2105", "2106", "2107", "2108", "2109",
        "2110", "2111", "2112", "2113", "2114", "2115", "2116", "2117",
        "21011", "21012", "21013", "21099", "21103", "2114", "2115",
        "4x4", "Niva", "Granta", "Kalina", "Priora", "Vesta", "Largus", "XRAY",
    ),
    "BMW": (
        "3 Series", "5 Series", "7 Series", "X1", "X3", "X5", "X6", "X7",
        "M3", "M5", "M6", "I3", "I4", "IX", "Z4",
    ),
    "Mercedes-Benz": (
        "A-Class", "B-Class", "C-Class", "E-Class", "S-Class", "V-Class",
        "CLA", "GLA", "GLB", "GLC", "GLE", "GLS", "G-Class", "Sprinter", "Vito",
    ),
    "Toyota": (
        "Camry", "Corolla", "RAV4", "Land Cruiser", "Prado", "Highlander",
        "C-HR", "Yaris", "Avensis", "Prius", "Mark II", "Chaser", "Crown",
    ),
    "Kia": ("Rio", "Sportage", "Cerato", "Sorento", "Soul", "K5", "Seltos", "Ceed"),
    "Hyundai": (
        "Solaris", "Creta", "Tucson", "Santa Fe", "Elantra", "i30", "ix35",
        "Accent", "Sonata", "Staria",
    ),
    "Volkswagen": ("Polo", "Golf", "Passat", "Tiguan", "Touareg", "Jetta", "Arteon", "Teramont"),
    "Nissan": ("Qashqai", "X-Trail", "Almera", "Juke", "Note", "Murano", "Patrol"),
    "Renault": ("Logan", "Sandero", "Duster", "Kaptur", "Arkana", "Megane", "Scenic"),
    "Ford": ("Focus", "Focus 2", "Focus 2 Restyling", "Mondeo", "Kuga", "Explorer", "Fiesta", "Transit"),
    "Skoda": ("Octavia", "Rapid", "Superb", "Kodiaq", "Karoq", "Fabia"),
    "Audi": ("A3", "A4", "A5", "A6", "A7", "A8", "Q3", "Q5", "Q7", "Q8", "TT"),
    "Mazda": ("3", "6", "CX-5", "CX-30", "CX-9", "MX-5"),
    "Chevrolet": ("Cruze", "Aveo", "Lacetti", "Niva", "Captiva", "Orlando"),
    "Opel": ("Astra", "Corsa", "Insignia", "Mokka", "Zafira"),
    "Volvo": ("XC40", "XC60", "XC90", "S60", "S90", "V60", "V90"),
    "Land Rover": ("Discovery", "Defender", "Range Rover", "Evoque", "Velar", "Sport"),
    "Chery": ("Tiggo 4", "Tiggo 7", "Tiggo 8", "Arrizo"),
    "Haval": ("Jolion", "F7", "Dargo", "H9"),
    "Geely": ("Coolray", "Atlas", "Tugella", "Monjaro"),
    "Changan": ("CS35", "CS55", "CS75", "UNI-K", "UNI-Z"),
    "UAZ": ("Patriot", "Hunter", "Profi", "Bukhanka"),
    "GAZ": ("Gazelle", "Sobol", "Volga"),
}

# alias/canonical -> canonical, used by fuzzy lookups.
_BRAND_TARGETS: dict[str, str] = {}
for _canonical, _aliases in BRAND_ALIASES.items():
    for _value in (_canonical, *_aliases):
        _BRAND_TARGETS[_value.lower()] = _canonical

_MODEL_TARGETS: dict[str, str] = dict(MODEL_ALIASES)
for _canonical, _models in KNOWN_MODELS.items():
    for _model in _models:
        _MODEL_TARGETS.setdefault(_model.lower(), _model)

_CITY_TARGETS: dict[str, str] = dict(CITY_ALIASES)
for _value, _canonical in CITY_ALIASES.items():
    _CITY_TARGETS.setdefault(_value.lower(), _canonical)

# Text agent targets: aliases are valid and stay as written; unknown tokens are
# corrected only when they are very close to a known brand/model/city.
_TEXT_TARGETS: dict[str, str] = {}
for _mapping in (_BRAND_TARGETS, _MODEL_TARGETS, _CITY_TARGETS):
    for _alias, _canonical in _mapping.items():
        _TEXT_TARGETS.setdefault(_alias, _canonical)
_TEXT_VALID = frozenset(_TEXT_TARGETS)
_TEXT_KEYS = tuple(sorted(_TEXT_TARGETS, key=len, reverse=True))
_TEXT_IGNORE = frozenset(
    {
        "series",
        "class",
        "серия",
        "серии",
        "класс",
        "кузов",
        "мотор",
        "двигатель",
        "пробег",
        "цена",
        "руб",
    }
)
_TEXT_TOKEN_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9-]{4,}")


@dataclass(frozen=True, slots=True)
class EntityFix:
    original: str
    corrected: str
    confidence: float = 0.0
    suggestions: tuple[str, ...] = ()

    @property
    def changed(self) -> bool:
        return self.corrected and self.corrected != self.original


@dataclass(frozen=True, slots=True)
class ModelCheck:
    make: str
    models: tuple[str, ...]
    fixes: tuple[EntityFix, ...] = ()
    suggestions: tuple[str, ...] = ()

    @property
    def corrections(self) -> tuple[EntityFix, ...]:
        return tuple(fix for fix in self.fixes if fix.changed)


@dataclass(frozen=True, slots=True)
class TextCheck:
    text: str
    changes: tuple[tuple[str, str], ...] = ()

    @property
    def changed(self) -> bool:
        return bool(self.changes)


@dataclass(frozen=True, slots=True)
class QualityReport:
    total: int
    sources: tuple[tuple[str, int], ...]
    unknown_models: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()


def _closest(
    value: str, targets: dict[str, str], *, cutoff: float = 0.8, limit: int = 3
) -> list[tuple[str, str, float]]:
    """Return (matched_key, canonical, score) for close dictionary keys."""
    cleaned = value.strip().lower()
    if not cleaned:
        return []
    matches = get_close_matches(cleaned, _TEXT_KEYS if targets is _TEXT_TARGETS else tuple(targets), n=limit, cutoff=cutoff)
    result: list[tuple[str, str, float]] = []
    for match in matches:
        canonical = targets.get(match)
        if canonical:
            score = SequenceMatcher(None, cleaned, match).ratio()
            result.append((match, canonical, score))
    return result


def _strip_make_prefix(make: str, model: str) -> str:
    lowered = model.strip().lower()
    aliases = [make.lower(), *(alias.lower() for alias in BRAND_ALIASES.get(make, ()))]
    for alias in sorted(set(aliases), key=len, reverse=True):
        for separator in ("-", " "):
            prefix = f"{alias}{separator}"
            if lowered.startswith(prefix):
                return model.strip()[len(prefix) :].strip()
    return model.strip()


class ModelAgent:
    """Validate a make/model list, correct high-confidence typos, suggest the rest."""

    def check_make(self, raw: str) -> EntityFix:
        original = (raw or "").strip()
        if not original:
            return EntityFix(original, original)
        canonical = normalize_make(original)
        if canonical and canonical in BRAND_ALIASES:
            return EntityFix(original, canonical, 1.0)

        matches = _closest(original, _BRAND_TARGETS, cutoff=0.74)
        suggestions = tuple(dict.fromkeys(item[1] for item in matches))
        if matches and matches[0][2] >= 0.82:
            return EntityFix(original, matches[0][1], matches[0][2], suggestions)
        return EntityFix(original, canonical or original.title(), 0.0, suggestions)

    def check_model(self, make: str, raw: str) -> EntityFix:
        original = (raw or "").strip()
        if not original:
            return EntityFix(original, original)
        canonical_make = normalize_make(make) or make
        cleaned = _strip_make_prefix(canonical_make, original)
        slang = canonical_model(canonical_make, cleaned)
        if slang is not None:
            value = slang.model
            if slang.generation and slang.generation.lower() not in value.lower():
                value = f"{value} {slang.generation}"
            return EntityFix(original, value, 0.99)
        normalized = normalize_model(cleaned) or cleaned

        catalog = set(KNOWN_MODELS.get(canonical_make, ()))
        for known in catalog:
            if normalized.lower() == known.lower():
                return EntityFix(original, known, 1.0)
            if normalized.lower().startswith(known.lower() + " "):
                return EntityFix(original, normalized, 0.95)
        if normalized in set(MODEL_ALIASES.values()):
            return EntityFix(original, normalized, 1.0)
        if normalized.isdigit() and canonical_make == "Lada" and normalized.startswith("21"):
            # Numeric VAZ variants are a large family; do not nag on valid variants.
            return EntityFix(original, normalized, 0.95)

        candidates = dict(_MODEL_TARGETS)
        for model in catalog:
            candidates.setdefault(model.lower(), model)
        matches = _closest(normalized, candidates, cutoff=0.78)
        suggestions = tuple(dict.fromkeys(item[1] for item in matches))
        if matches and matches[0][2] >= 0.88:
            return EntityFix(original, matches[0][1], matches[0][2], suggestions)
        return EntityFix(original, cleaned or original, 0.0, suggestions)

    def check_models(self, make: str, raw_models: Sequence[str]) -> ModelCheck:
        make_fix = self.check_make(make)
        canonical_make = make_fix.corrected or (make or "").strip()
        fixes: list[EntityFix] = []
        models: list[str] = []
        for raw in raw_models:
            fix = self.check_model(canonical_make, raw)
            fixes.append(fix)
            value = fix.corrected or raw.strip()
            if value and value not in models:
                models.append(value)
        suggestions = tuple(
            dict.fromkeys(s for fix in fixes for s in fix.suggestions if s not in models)
        )
        if make_fix.suggestions and not make_fix.changed:
            suggestions = tuple(dict.fromkeys((*suggestions, *make_fix.suggestions)))
        return ModelCheck(
            make=canonical_make,
            models=tuple(models),
            fixes=tuple(fixes),
            suggestions=suggestions,
        )


class TextAgent:
    """Correct only high-confidence brand/model/city typos in listing text."""

    @staticmethod
    @lru_cache(maxsize=4096)
    def _correct_token(token: str) -> str | None:
        lowered = token.lower()
        if lowered in _TEXT_VALID or lowered in _TEXT_IGNORE:
            return None
        if len(lowered) < 4 or not re.search(r"[A-Za-zА-Яа-яЁё]", lowered):
            return None
        matches = get_close_matches(lowered, _TEXT_KEYS, n=1, cutoff=0.82)
        if not matches:
            return None
        canonical = _TEXT_TARGETS.get(matches[0])
        if not canonical:
            return None
        score = SequenceMatcher(None, lowered, matches[0]).ratio()
        return canonical if score >= 0.82 else None

    def correct_text(self, text: str, *, max_chars: int = 8000) -> TextCheck:
        if not text:
            return TextCheck(text)
        limit = min(len(text), max_chars)
        source = text[:limit]
        changes: list[tuple[str, str]] = []
        pieces: list[str] = []
        cursor = 0
        for match in _TEXT_TOKEN_RE.finditer(source):
            token = match.group(0)
            replacement = self._correct_token(token)
            if replacement is None or replacement == token:
                continue
            pieces.append(source[cursor : match.start()])
            pieces.append(replacement)
            cursor = match.end()
            changes.append((token, replacement))
        if not changes:
            return TextCheck(text)
        pieces.append(source[cursor:])
        return TextCheck("".join(pieces) + text[limit:], tuple(changes))


class SearchQualityAgent:
    """Cheap post-search audit: source coverage and query spelling hints."""

    def audit(self, query, listings: Iterable) -> QualityReport:
        items = list(listings)
        sources: dict[str, int] = {}
        unknown: set[str] = set()
        for listing in items:
            source = getattr(getattr(listing, "source", None), "value", None)
            if source:
                sources[source] = sources.get(source, 0) + 1
            model = getattr(listing, "model", None)
            if model and query.make:
                known = KNOWN_MODELS.get(normalize_make(query.make) or "", ())
                if known and not any(model.lower() == item.lower() for item in known):
                    unknown.add(model)

        notes: list[str] = []
        check = model_agent.check_models(query.make, query.all_models())
        if not items:
            notes.append("0 результатов: проверьте марку/модель и период")
        if check.suggestions:
            notes.append("возможные модели: " + ", ".join(check.suggestions[:3]))
        if unknown:
            notes.append("неизвестные модели в выдаче: " + ", ".join(sorted(unknown)[:3]))
        return QualityReport(
            total=len(items),
            sources=tuple(sorted(sources.items())),
            unknown_models=tuple(sorted(unknown)),
            notes=tuple(notes),
        )


model_agent = ModelAgent()
text_agent = TextAgent()
quality_agent = SearchQualityAgent()

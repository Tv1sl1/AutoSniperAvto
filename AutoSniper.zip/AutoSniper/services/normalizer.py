"""Convert scraper output (``RawListing``) into ORM ``Listing`` rows."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

from database.models import Listing
from services.agents import text_agent
from services.hashing import compute_hash_id
from services.parser_engine import ParsedListing, normalize_make, normalize_model, parse_listing

_PHONE_RE = re.compile(
    r"(?<!\d)(?:\+7|8)?[\s\-()]*\d{3}[\s\-()]*\d{3}[\s\-()]*\d{2}[\s\-()]*\d{2}(?!\d)"
)


def _scrub_phones(text: str) -> str:
    return _PHONE_RE.sub("[телефон скрыт]", text or "")

if TYPE_CHECKING:  # pragma: no cover - typing only
    from scrapers.base import RawListing

__all__ = ["NormalizedListing", "normalize_raw"]


@dataclass(slots=True)
class NormalizedListing:
    listing: Listing
    parsed: ParsedListing


def normalize_raw(raw: RawListing) -> NormalizedListing:
    """Run heuristics over the raw post and build an unsaved ``Listing``."""
    text = (raw.raw_text or "").strip() or (raw.title or "").strip()
    corrected = text_agent.correct_text(text)
    if corrected.changed:
        text = corrected.text
    title_source = (raw.title or "").strip()
    if title_source:
        title_source = text_agent.correct_text(title_source).text
    parsed = parse_listing(
        text,
        title=title_source or None,
        default_city=raw.city,
        default_price=raw.price,
        default_year=getattr(raw, "year", None),
        default_make=getattr(raw, "make", None),
    )

    title = (parsed.title or raw.title or "Автомобиль").strip()[:512]
    # Structured source price is authoritative: free text often contains
    # engine/model codes (e.g. "1.2 MT 21013") that look like a price.
    price = int(raw.price) if raw.price is not None else parsed.price
    listing = Listing(
        hash_id=compute_hash_id(title, price, raw.url),
        source=raw.source,
        external_id=raw.external_id or None,
        title=title,
        price=price,
        city=parsed.city,
        url=raw.url,
        photos=list(dict.fromkeys(raw.photos or [])),
        published_at=raw.published_at,
        date_approx=bool((raw.meta or {}).get("date_assumed")),
        raw_text=_scrub_phones(text)[:20000],
        make=normalize_make(parsed.make),
        model=normalize_model(parsed.model),
        year=parsed.year,
        generation=parsed.generation,
        transmission=parsed.transmission,
        engine_volume=parsed.engine_volume,
    )
    return NormalizedListing(listing=listing, parsed=parsed)

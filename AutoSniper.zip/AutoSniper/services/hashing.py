"""Deterministic deduplication keys for listings."""

from __future__ import annotations

import hashlib
import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

TRACKING_PARAMS = frozenset(
    {
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_term",
        "utm_content",
        "utm_referrer",
        "from",
        "context",
        "ref",
        "referrer",
        "fbclid",
        "gclid",
        "yclid",
        "cmp",
        "source",
        "src",
    }
)
_WHITESPACE_RE = re.compile(r"\s+")


def normalize_title(title: str) -> str:
    """Lowercase, strip punctuation noise and collapse whitespace."""
    cleaned = (title or "").lower().replace("ё", "е")
    cleaned = re.sub(r"[^\w\s]+", " ", cleaned, flags=re.UNICODE)
    return _WHITESPACE_RE.sub(" ", cleaned).strip()


def normalize_url(url: str) -> str:
    """Remove tracking parameters and canonicalise the URL for hashing."""
    if not url:
        return ""
    try:
        parts = urlsplit(url.strip())
    except ValueError:
        return url.strip().lower()
    if not parts.scheme or not parts.netloc:
        return url.strip().lower()

    query = [
        (key, value)
        for key, value in parse_qsl(parts.query, keep_blank_values=False)
        if key.lower() not in TRACKING_PARAMS
    ]
    query.sort()
    path = parts.path.rstrip("/") or "/"
    return urlunsplit(
        (parts.scheme.lower(), parts.netloc.lower(), path, urlencode(query), "")
    )


def compute_hash_id(title: str, price: int | None, url: str) -> str:
    """SHA-256 over ``normalized title | price | normalized source URL``."""
    payload = f"{normalize_title(title)}|{price if price is not None else ''}|{normalize_url(url)}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


__all__ = ["compute_hash_id", "normalize_title", "normalize_url"]

"""Networking helpers: rate limiting, proxy/UA rotation, retries with backoff."""

from __future__ import annotations

import asyncio
import random
import time
from collections.abc import Awaitable, Callable, Iterable
from typing import Any, TypeVar
from urllib.parse import urlsplit

import aiohttp

from config.logger import get_logger

logger = get_logger(__name__)

T = TypeVar("T")

DEFAULT_USER_AGENTS: tuple[str, ...] = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/17.4 Mobile/15E148 Safari/604.1",
)

_RETRYABLE_STATUSES = frozenset({403, 408, 425, 429, 500, 502, 503, 504})


class ScraperError(Exception):
    """Base error for all scrapers."""


class NetworkError(ScraperError):
    """Network/HTTP failure after retries were exhausted."""


class AuthError(ScraperError):
    """Credentials are missing, invalid or revoked."""


class RateLimitedError(ScraperError):
    """The remote side explicitly asked us to slow down."""

    def __init__(self, message: str, retry_after: float = 5.0) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class RateLimiter:
    """Simple async rate limiter with a minimum interval between calls."""

    def __init__(self, per_second: float) -> None:
        self.per_second = max(per_second, 0.01)
        self.min_interval = 1.0 / self.per_second
        self._lock = asyncio.Lock()
        self._last_call = 0.0

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()
            wait_for = self._last_call + self.min_interval - now
            if wait_for > 0:
                await asyncio.sleep(wait_for)
                now = time.monotonic()
            self._last_call = now

    async def __aenter__(self) -> RateLimiter:
        await self.acquire()
        return self

    async def __aexit__(self, *_exc: object) -> None:
        return None


class ProxyPool:
    """Round-robin proxy rotation."""

    def __init__(self, proxies: Iterable[str] = ()) -> None:
        self._proxies = [proxy.strip() for proxy in proxies if proxy and proxy.strip()]
        self._index = 0

    def __len__(self) -> int:
        return len(self._proxies)

    def __bool__(self) -> bool:
        return bool(self._proxies)

    def next(self) -> str | None:
        if not self._proxies:
            return None
        proxy = self._proxies[self._index % len(self._proxies)]
        self._index += 1
        return proxy


class UserAgentPool:
    def __init__(self, agents: Iterable[str] = ()) -> None:
        self._agents = [agent for agent in agents if agent] or list(DEFAULT_USER_AGENTS)

    def next(self) -> str:
        return random.choice(self._agents)


async def retry_async(
    operation: Callable[[], Awaitable[T]],
    *,
    attempts: int = 4,
    base_delay: float = 2.0,
    max_delay: float = 120.0,
    retry_on: tuple[type[BaseException], ...] = (Exception,),
    jitter: bool = True,
    description: str = "operation",
) -> T:
    """Run ``operation`` with exponential backoff and jitter."""
    last_error: BaseException | None = None
    for attempt in range(1, max(attempts, 1) + 1):
        try:
            return await operation()
        except asyncio.CancelledError:
            raise
        except retry_on as exc:
            last_error = exc
            if attempt >= attempts:
                break
            delay = min(base_delay * (2 ** (attempt - 1)), max_delay)
            if jitter:
                delay *= random.uniform(0.8, 1.25)
            logger.warning(
                "%s failed (attempt %s/%s): %s — retrying in %.1fs",
                description,
                attempt,
                attempts,
                exc,
                delay,
            )
            await asyncio.sleep(delay)
    assert last_error is not None
    raise last_error


class HttpClient:
    """Small aiohttp wrapper used by the VK and web scrapers.

    Features: retries with exponential backoff, ``Retry-After`` support,
    per-request proxy/User-Agent rotation and optional rate limiting.
    """

    def __init__(
        self,
        *,
        timeout: float = 25.0,
        max_retries: int = 4,
        backoff_base: float = 2.0,
        backoff_max: float = 120.0,
        proxies: Iterable[str] = (),
        user_agents: Iterable[str] = (),
        rate_limiter: RateLimiter | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        self.timeout = aiohttp.ClientTimeout(total=timeout, connect=min(timeout, 15.0))
        self.max_retries = max(1, max_retries)
        self.backoff_base = backoff_base
        self.backoff_max = backoff_max
        self.proxies = ProxyPool(proxies)
        self.user_agents = UserAgentPool(user_agents)
        self.rate_limiter = rate_limiter
        self.default_headers = {
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            **(default_headers or {}),
        }
        self._session: aiohttp.ClientSession | None = None

    async def __aenter__(self) -> HttpClient:
        await self._ensure_session()
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.close()

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=self.timeout,
                headers=self.default_headers,
                cookie_jar=aiohttp.CookieJar(unsafe=True),
            )
        return self._session

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
        self._session = None

    def _headers(self, extra: dict[str, str] | None) -> dict[str, str]:
        headers = {"User-Agent": self.user_agents.next(), "Referer": "https://www.google.com/"}
        if extra:
            headers.update(extra)
        return headers

    async def _request_text(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        data: Any = None,
        json: Any = None,
        headers: dict[str, str] | None = None,
        retry_statuses: frozenset[int] = _RETRYABLE_STATUSES,
    ) -> str:
        session = await self._ensure_session()
        last_error: Exception | None = None

        for attempt in range(1, self.max_retries + 1):
            if self.rate_limiter is not None:
                await self.rate_limiter.acquire()
            proxy = self.proxies.next()
            try:
                async with session.request(
                    method,
                    url,
                    params=params,
                    data=data,
                    json=json,
                    headers=self._headers(headers),
                    proxy=proxy,
                    allow_redirects=True,
                ) as response:
                    body = await response.text(errors="replace")
                    if response.status < 400:
                        return body
                    detail = f"HTTP {response.status} for {url}"
                    if response.status not in retry_statuses:
                        raise NetworkError(detail)
                    last_error = NetworkError(detail)
                    retry_after = _parse_retry_after(response.headers.get("Retry-After"))
                    if attempt >= self.max_retries:
                        raise last_error
                    delay = self._backoff_delay(attempt, retry_after)
                    logger.warning(
                        "%s: %s (attempt %s/%s), retrying in %.1fs",
                        urlsplit(url).netloc,
                        detail,
                        attempt,
                        self.max_retries,
                        delay,
                    )
                    await asyncio.sleep(delay)
                    continue
            except asyncio.CancelledError:
                raise
            except NetworkError:
                raise
            except (TimeoutError, aiohttp.ClientError, OSError) as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    break
                delay = self._backoff_delay(attempt)
                logger.warning(
                    "%s: %s (attempt %s/%s), retrying in %.1fs",
                    urlsplit(url).netloc,
                    exc or type(exc).__name__,
                    attempt,
                    self.max_retries,
                    delay,
                )
                await asyncio.sleep(delay)

        raise NetworkError(f"Request failed after {self.max_retries} attempts: {url} ({last_error})")

    def _backoff_delay(self, attempt: int, retry_after: float | None = None) -> float:
        delay = min(self.backoff_base * (2 ** (attempt - 1)), self.backoff_max)
        delay *= random.uniform(0.8, 1.2)
        if retry_after:
            delay = max(delay, min(retry_after, self.backoff_max))
        return delay

    async def get_text(self, url: str, **kwargs: Any) -> str:
        return await self._request_text("GET", url, **kwargs)

    async def post_text(self, url: str, **kwargs: Any) -> str:
        return await self._request_text("POST", url, **kwargs)

    async def get_json(self, url: str, **kwargs: Any) -> Any:
        import json as json_module

        text = await self._request_text(
            "GET", url, headers={"Accept": "application/json, text/plain, */*", **(kwargs.pop("headers", None) or {})}, **kwargs
        )
        try:
            return json_module.loads(text)
        except ValueError as exc:
            raise NetworkError(f"Invalid JSON response from {url}: {exc}") from exc


def _parse_retry_after(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        return None


__all__ = [
    "AuthError",
    "DEFAULT_USER_AGENTS",
    "HttpClient",
    "NetworkError",
    "ProxyPool",
    "RateLimitedError",
    "RateLimiter",
    "ScraperError",
    "UserAgentPool",
    "retry_async",
]

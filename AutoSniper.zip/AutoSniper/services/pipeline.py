"""Ingestion pipeline: deduplicate -> store -> match -> notify -> journal.

Notifications are created transactionally together with the listing, then sent
*after* the commit. Delivery results are written in a separate transaction, so a
crash can never lose an already-delivered alert or spam the user twice thanks to
the ``(user_id, listing_id)`` unique constraint.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from enum import StrEnum
from typing import Protocol

from config.logger import get_logger
from config.settings import Settings
from database.models import Listing, Subscription
from database.repositories import (
    ListingRepository,
    NotificationRepository,
    SubscriptionRepository,
    UserRepository,
)
from database.session import Database
from services.matching import MatchPolicy, SubscriptionMatcher
from services.normalizer import normalize_raw

logger = get_logger(__name__)

__all__ = [
    "DeliveryOutcome",
    "DeliveryResult",
    "IngestStats",
    "IngestionPipeline",
    "Notifier",
    "PendingNotification",
]


class DeliveryOutcome(StrEnum):
    SENT = "sent"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass(frozen=True, slots=True)
class DeliveryResult:
    outcome: DeliveryOutcome
    error: str | None = None


class Notifier(Protocol):
    async def send_match(
        self,
        user_id: int,
        listing: Listing,
        subscription: Subscription | None = None,
    ) -> DeliveryResult: ...


@dataclass(slots=True)
class PendingNotification:
    notification_id: int
    user_id: int
    listing: Listing
    subscription: Subscription | None = None


@dataclass(slots=True)
class IngestStats:
    received: int = 0
    created: int = 0
    updated: int = 0
    duplicates: int = 0
    matched: int = 0
    notifications: int = 0
    delivered: int = 0
    failed: int = 0
    blocked: int = 0

    def merge(self, other: IngestStats) -> IngestStats:
        for name in self.__slots__:  # type: ignore[attr-defined]
            setattr(self, name, getattr(self, name) + getattr(other, name))
        return self

    def as_dict(self) -> dict[str, int]:
        return {name: int(getattr(self, name)) for name in self.__slots__}  # type: ignore[attr-defined]


class IngestionPipeline:
    def __init__(
        self,
        db: Database,
        *,
        settings: Settings | None = None,
        notifier: Notifier | None = None,
        matcher: SubscriptionMatcher | None = None,
    ) -> None:
        self.db = db
        self.settings = settings
        self.notifier = notifier
        policy = (
            MatchPolicy(
                require_known_price=settings.match_require_known_price,
                require_known_city=settings.match_require_known_city,
                same_region=settings.match_same_region,
            )
            if settings
            else MatchPolicy()
        )
        self.matcher = matcher or SubscriptionMatcher(policy)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def ingest(self, raws: Iterable[object], *, notify: bool = True) -> IngestStats:
        """Persist a batch of ``RawListing`` items and notify matched users."""
        items = list(raws)
        stats = IngestStats(received=len(items))
        if not items:
            return stats

        pending: list[PendingNotification] = []
        async with self.db.session() as session:
            listings = ListingRepository(session)
            subscriptions_repo = SubscriptionRepository(session)
            notifications = NotificationRepository(session)

            subscriptions = await subscriptions_repo.list_active() if notify else []
            cold_start_ids = [sub.id for sub in subscriptions if not sub.cold_start_done]
            seen_hashes: set[str] = set()

            for raw in items:
                try:
                    normalized = normalize_raw(raw)  # type: ignore[arg-type]
                except Exception as exc:  # defensive: one bad post must not kill the batch
                    logger.exception("Failed to normalize raw listing from %s: %s", getattr(raw, "url", "?"), exc)
                    stats.failed += 1
                    continue

                listing = normalized.listing
                if listing.hash_id in seen_hashes:
                    stats.duplicates += 1
                    continue
                seen_hashes.add(listing.hash_id)

                try:
                    stored, created = await listings.save(listing)
                except Exception as exc:
                    logger.exception("Failed to store listing %s: %s", listing.url, exc)
                    stats.failed += 1
                    continue

                if created:
                    stats.created += 1
                else:
                    stats.updated += 1

                if not notify or not created or not subscriptions:
                    continue

                matches = self.matcher.match_all(stored, subscriptions)
                stats.matched += len(matches)
                if not matches:
                    logger.debug(
                        "No subscription matched %s (%s, %s)", stored.title, stored.price, stored.city
                    )
                    continue

                # One alert per (user, listing) even when several filters match.
                notified_users: set[int] = set()
                for subscription, _result in matches:
                    if not subscription.cold_start_done:
                        continue
                    if subscription.user_id in notified_users:
                        continue
                    notification = await notifications.create(
                        user_id=subscription.user_id,
                        listing_id=stored.id,
                        subscription_id=subscription.id,
                    )
                    if notification is None:
                        continue
                    notified_users.add(subscription.user_id)
                    pending.append(
                        PendingNotification(
                            notification_id=notification.id,
                            user_id=subscription.user_id,
                            listing=stored,
                            subscription=subscription,
                        )
                    )

            if cold_start_ids:
                await subscriptions_repo.mark_cold_start_done(cold_start_ids)
                logger.info("Cold start completed for %s subscription(s)", len(cold_start_ids))

        stats.notifications = len(pending)
        if pending and notify and self.notifier is not None:
            await self._deliver(pending, stats)
        return stats

    async def retry_pending(self, limit: int = 20) -> IngestStats:
        """Retry notifications that were not delivered (network blip, restart)."""
        stats = IngestStats()
        if self.notifier is None:
            return stats

        tasks: list[PendingNotification] = []
        async with self.db.session() as session:
            notifications_repo = NotificationRepository(session)
            users_repo = UserRepository(session)
            for notification in await notifications_repo.list_pending(limit):
                if notification.listing is None:  # pragma: no cover - FK guarantees it
                    continue
                user = await users_repo.get(notification.user_id)
                if user is None or not user.is_active:
                    await notifications_repo.mark_failed(
                        notification.id, "user inactive or deleted"
                    )
                    continue
                tasks.append(
                    PendingNotification(
                        notification_id=notification.id,
                        user_id=notification.user_id,
                        listing=notification.listing,
                        subscription=None,
                    )
                )

        if tasks:
            logger.info("Retrying %s pending notification(s)", len(tasks))
            await self._deliver(tasks, stats)
        return stats

    # ------------------------------------------------------------------
    # Delivery
    # ------------------------------------------------------------------
    async def _deliver(self, pending: Sequence[PendingNotification], stats: IngestStats) -> None:
        assert self.notifier is not None
        for task in pending:
            try:
                result = await self.notifier.send_match(task.user_id, task.listing, task.subscription)
            except Exception as exc:  # notifier must not kill the pipeline
                logger.exception("Notifier crashed for user %s: %s", task.user_id, exc)
                await self._record_failure(task.notification_id, f"notifier crashed: {exc}")
                stats.failed += 1
                continue

            if result.outcome is DeliveryOutcome.SENT:
                stats.delivered += 1
                await self._record_success(task.notification_id)
            elif result.outcome is DeliveryOutcome.BLOCKED:
                stats.blocked += 1
                await self._record_blocked(task.notification_id, task.user_id, result.error or "blocked by user")
            else:
                stats.failed += 1
                await self._record_failure(task.notification_id, result.error or "delivery failed")

    async def _record_success(self, notification_id: int) -> None:
        async with self.db.session() as session:
            await NotificationRepository(session).mark_sent(notification_id)

    async def _record_failure(self, notification_id: int, error: str) -> None:
        async with self.db.session() as session:
            await NotificationRepository(session).mark_failed(notification_id, error)

    async def _record_blocked(self, notification_id: int, user_id: int, error: str) -> None:
        async with self.db.session() as session:
            await NotificationRepository(session).mark_failed(notification_id, error)
            await UserRepository(session).set_active(user_id, False)
        logger.warning("User %s blocked the bot; notifications disabled", user_id)

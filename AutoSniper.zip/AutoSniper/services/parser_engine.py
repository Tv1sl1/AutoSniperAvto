"""Heuristic parsing engine for Russian car advertisements.

The engine is deliberately dependency-free: it only needs the standard library,
which keeps it fast and trivially unit-testable. It powers three things:

* turning free-form post text into structured ``(make, model, price, city, year)``;
* normalizing user input from the bot;
* fuzzy comparison helpers used by the matching service.

Supported price shapes::

    1 200 000 ₽      1.200.000 руб.     1,2 млн     1200k
    2.35 млн         120 тыс.           900 000     1 250 000 рублей
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Final

from services.synonyms_dict import extract_generation, resolve_slang

__all__ = [
    "BRAND_ALIASES",
    "CITY_ALIASES",
    "ParsedListing",
    "canonical_city",
    "canonical_region",
    "city_matches",
    "detect_city",
    "detect_make",
    "models_match",
    "normalize_city",
    "normalize_make",
    "normalize_model",
    "normalize_text",
    "parse_listing",
    "parse_price",
    "parse_year",
    "tokenize_model",
]

MIN_PLAUSIBLE_PRICE: Final[int] = 20_000
MAX_PLAUSIBLE_PRICE: Final[int] = 100_000_000

# ---------------------------------------------------------------------------
# Generic text helpers
# ---------------------------------------------------------------------------

_WHITESPACE_RE = re.compile(r"\s+")
_DATE_SEPARATORS = str.maketrans({"\u00a0": " ", "\u202f": " ", "\u2009": " "})


def normalize_text(text: str) -> str:
    """Lowercase, unify ё/е and collapse whitespace."""
    if not text:
        return ""
    prepared = text.translate(_DATE_SEPARATORS).replace("Ё", "Е").replace("ё", "е")
    return _WHITESPACE_RE.sub(" ", prepared).strip().lower()


def _strip_accents(text: str) -> str:
    return text.translate(_DATE_SEPARATORS).replace("Ё", "Е").replace("ё", "е")


# ---------------------------------------------------------------------------
# Price parsing
# ---------------------------------------------------------------------------

_NUMBER_RE = re.compile(
    r"(?<![\d.,])"
    r"(?P<num>\d{1,3}(?:[ \u00a0\u202f.,]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d+)?)"
    r"(?![\d])"
)
_THOUSANDS_RE = re.compile(r"^(?P<int>\d{1,3}(?:[.,]\d{3})+)(?:[.,](?P<dec>\d{1,2}))?$")
_DECIMAL_RE = re.compile(r"^\d+[.,]\d{1,2}$")

_MULTIPLIERS: Final[dict[str, float]] = {
    "млн": 1_000_000,
    "млн.": 1_000_000,
    "млрд": 1_000_000_000,
    "тыс": 1_000,
    "тыс.": 1_000,
    "тысяч": 1_000,
    "тысячи": 1_000,
    "к": 1_000,
    "k": 1_000,
    "m": 1_000_000,
}
_UNIT_RE = re.compile(r"^\s*(млн|млрд|тыс(?:яч|ячи)?\.?|тр|т\.\s*р|к|k|m)(?![а-яa-z])", re.I)
_CURRENCY_RE = re.compile(r"^\s*(₽|руб(?:\.|лей|ля)?|р\.?(?![а-яa-z])|rub|rur|доллар|usd|€|eur|\$)", re.I)
_BAD_SUFFIX_RE = re.compile(
    r"^\s*(?:км(?:/ч)?|тыс\.?\s*км|год(?:а|у|ов)?|г\.|лет|мес(?:яц(?:ев)?)?|"
    r"л\.?\s*с\.?|лошад\w*|куб(?:\.|\s*см)?|см|мм|%|чел\w*|дней|день|часов|мин)",
    re.I,
)
_BAD_PREFIX_RE = re.compile(
    r"(?:пробег|пробегом|проехал|расход|объем|объём|мощность|год|г\.в\.|л\.с\.)\s*[:—-]?\s*$",
    re.I,
)
_PRICE_WORD_RE = re.compile(r"(?:цена|стоимость|продам\s+за|отдам\s+за|за|всего)\s*[:—-]?\s*$", re.I)
_PHONE_RE = re.compile(
    r"(?<!\d)(?:\+7|8|7)[\s\-()]*\d{3}[\s\-()]*\d{3}[\s\-()]*\d{2}[\s\-()]*\d{2}(?!\d)"
)


def _number_to_float(raw: str) -> float | None:
    text = raw.replace(" ", "").replace("\u00a0", "").replace("\u202f", "")
    thousands = _THOUSANDS_RE.match(text)
    if thousands:
        integer = re.sub(r"[.,]", "", thousands.group("int"))
        decimals = thousands.group("dec")
        try:
            return float(integer) + (int(decimals) / 100 if decimals and len(decimals) == 2 else 0)
        except ValueError:
            return None
    if _DECIMAL_RE.match(text):
        text = text.replace(",", ".")
    elif "," in text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _looks_like_phone(digits: str, value: int) -> bool:
    if len(digits) not in (10, 11):
        return False
    return digits[0] in "789" and value >= 1_000_000_000


def parse_price(text: str) -> int | None:
    """Extract the most plausible car price from an ad text."""
    if not text:
        return None
    searchable = _strip_accents(text)
    phone_spans = [match.span() for match in _PHONE_RE.finditer(searchable)]
    candidates: list[tuple[float, int]] = []

    for match in _NUMBER_RE.finditer(searchable):
        raw_number = match.group("num")
        start, end = match.span()
        if any(span_start <= start < span_end for span_start, span_end in phone_spans):
            continue
        after = searchable[end : end + 14]
        before = searchable[max(0, start - 24) : start]

        if _BAD_SUFFIX_RE.match(after):
            continue
        if _BAD_PREFIX_RE.search(before):
            continue

        unit_match = _UNIT_RE.match(after)
        multiplier = _MULTIPLIERS.get(unit_match.group(1).lower()) if unit_match else None
        compact_number = raw_number.replace(" ", "").replace("\u00a0", "").replace("\u202f", "")
        is_thousands_number = bool(_THOUSANDS_RE.match(compact_number))
        if multiplier == 1_000 and is_thousands_number:
            base_probe = _number_to_float(raw_number)
            if base_probe is not None and base_probe >= 10_000:
                # "50.000 тысяч" is colloquial for 50 000, not 50 million.
                multiplier = None
        currency = bool(_CURRENCY_RE.match(after))

        base = _number_to_float(raw_number)
        if base is None:
            continue
        value = int(round(base * (multiplier or 1)))
        digits = re.sub(r"\D", "", raw_number.split(",")[0].split(".")[0])

        if _looks_like_phone(digits, value):
            continue
        if value < MIN_PLAUSIBLE_PRICE or value > MAX_PLAUSIBLE_PRICE:
            continue

        score = 0.0
        if multiplier:
            score += 3.0
        if currency:
            score += 2.0
        if _PRICE_WORD_RE.search(before):
            score += 2.0
        if 100_000 <= value <= 50_000_000:
            score += 0.5
        if multiplier and not currency:
            # "2.5 млн" is unambiguous even without "руб".
            score += 0.5
        candidates.append((score, value))

    if not candidates:
        return None

    # Highest score wins; ties are resolved towards the larger amount.
    candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return candidates[0][1]


# ---------------------------------------------------------------------------
# Year parsing
# ---------------------------------------------------------------------------

_YEAR_RE = re.compile(r"(?<!\d)(?P<year>19[5-9]\d|20[0-4]\d)(?!\d)\s*(?P<marker>г\.?|год(?:а|у)?|лет|y\.?|year)?", re.I)
_CURRENT_YEAR = datetime.now(UTC).year


def parse_year(text: str) -> int | None:
    """Return the model year, preferring numbers explicitly marked as a year."""
    if not text:
        return None
    searchable = _strip_accents(text)
    best: tuple[int, int] | None = None  # (bonus, year)
    for match in _YEAR_RE.finditer(searchable):
        year = int(match.group("year"))
        if year < 1950 or year > _CURRENT_YEAR + 1:
            continue
        has_marker = bool(match.group("marker"))
        bonus = 2 if has_marker else 1
        if best is None or bonus > best[0]:
            best = (bonus, year)
    return best[1] if best else None


# ---------------------------------------------------------------------------
# Cities
# ---------------------------------------------------------------------------

_CITY_ALIASES_RAW: Final[dict[str, tuple[str, ...]]] = {
    "Москва": (
        "москва",
        "москве",
        "москвы",
        "москву",
        "мск",
        "moscow",
        "москва и мо",
        "московская область",
        "московская обл",
        "подмосковье",
    ),
    "Санкт-Петербург": (
        "санкт-петербург",
        "санкт петербург",
        "санкт-петербурге",
        "санкт петербурге",
        "санкт-петербурга",
        "петербург",
        "петербурге",
        "питер",
        "питере",
        "спб",
        "ленинградская область",
        "ленобласть",
        "saint petersburg",
        "saint-petersburg",
        "spb",
    ),
    "Екатеринбург": (
        "екатеринбург",
        "екатеринбурге",
        "екб",
        "екат",
        "ekaterinburg",
        "свердловская область",
    ),
    "Нижний Тагил": ("нижний тагил", "нижнем тагиле", "тагил", "нижний-тагил"),
    "Каменск-Уральский": (
        "каменск-уральский",
        "каменске-уральском",
        "каменск уральский",
        "каменск",
    ),
    "Первоуральск": ("первоуральск", "первоуральске"),
    "Асбест": ("асбест", "асбесте"),
    "Серов": ("серов", "серове"),
    "Новоуральск": ("новоуральск", "новоуральске"),
    "Верхняя Пышма": ("верхняя пышма", "верхней пышме", "пышма"),
    "Верхние Серги": ("верхние серги", "верхних сергах"),
    "Малышева": ("малышева", "малышеве"),
    "Березовский": ("березовский", "березовском", "березовского"),
    "Ревда": ("ревда", "ревде"),
    "Полевской": ("полевской", "полевском"),
    "Краснотурьинск": ("краснотурьинск", "краснотурьинске"),
    "Сухой Лог": ("сухой лог", "сухом логу"),
    "Алапаевск": ("алапаевск", "алапаевске"),
    "Ирбит": ("ирбит", "ирбите"),
    "Реж": ("реж", "реже"),
    "Заречный": ("заречный", "заречном"),
    "Сысерть": ("сысерть", "сысерти"),
    "Арамиль": ("арамиль", "арамиле"),
    "Среднеуральск": ("среднеуральск", "среднеуральске"),
    "Невьянск": ("невьянск", "невьянске"),
    "Кировград": ("кировград", "кировграде"),
    "Качканар": ("качканар", "качканаре"),
    "Красноуфимск": ("красноуфимск", "красноуфимске"),
    "Артемовский": ("артемовский", "артемовском"),
    "Богданович": ("богданович", "богдановиче"),
    "Карпинск": ("карпинск", "карпинске"),
    "Североуральск": ("североуральск", "североуральске"),
    "Верхняя Салда": ("верхняя салда", "верхней салде"),
    "Нижняя Салда": ("нижняя салда", "нижней салде"),
    "Новосибирск": ("новосибирск", "новосибирске", "нск", "новосиб"),
    "Краснодар": ("краснодар", "краснодаре", "krasnodar"),
    "Сочи": ("сочи", "sochi"),
    "Казань": ("казань", "казани", "кзн", "kazan"),
    "Самара": ("самара", "самаре", "samara"),
    "Уфа": ("уфа", "уфе", "ufa"),
    "Челябинск": ("челябинск", "челябинске", "челяба", "chelyabinsk"),
    "Омск": ("омск", "омске"),
    "Тюмень": ("тюмень", "тюмени", "tyumen"),
    "Пермь": ("пермь", "перми", "perm"),
    "Волгоград": ("волгоград", "волгограде", "volgograd"),
    "Воронеж": ("воронеж", "воронеже", "voronezh"),
    "Саратов": ("саратов", "саратове", "saratov"),
    "Тольятти": ("тольятти", "tolyatti"),
    "Ижевск": ("ижевск", "ижевске", "izhevsk"),
    "Барнаул": ("барнаул", "барнауле", "barnaul"),
    "Ульяновск": ("ульяновск", "ульяновске", "ulyanovsk"),
    "Иркутск": ("иркутск", "иркутске", "irkutsk"),
    "Хабаровск": ("хабаровск", "хабаровске", "khabarovsk"),
    "Владивосток": ("владивосток", "владивостоке", "vladivostok"),
    "Ярославль": ("ярославль", "ярославле", "yaroslavl"),
    "Махачкала": ("махачкала", "махачкале", "makhachkala"),
    "Томск": ("томск", "томске", "tomsk"),
    "Оренбург": ("оренбург", "оренбурге", "orenburg"),
    "Кемерово": ("кемерово", "kemerovo"),
    "Новокузнецк": ("новокузнецк", "новокузнецке", "novokuznetsk"),
    "Рязань": ("рязань", "рязани", "ryazan"),
    "Астрахань": ("астрахань", "астрахани", "astrakhan"),
    "Пенза": ("пенза", "пензе", "penza"),
    "Липецк": ("липецк", "липецке", "lipetsk"),
    "Киров": ("киров", "кирове", "kirov"),
    "Чебоксары": ("чебоксары", "чебоксарах", "cheboksary"),
    "Тула": ("тула", "туле", "tula"),
    "Калининград": ("калининград", "калининграде", "kaliningrad"),
    "Курск": ("курск", "курске", "kursk"),
    "Ставрополь": ("ставрополь", "ставрополе", "stavropol"),
    "Тверь": ("тверь", "твери", "tver"),
    "Магнитогорск": ("магнитогорск", "магнитогорске", "magnitogorsk"),
    "Иваново": ("иваново", "ivanovo"),
    "Брянск": ("брянск", "брянске", "bryansk"),
    "Белгород": ("белгород", "белгороде", "belgorod"),
    "Сургут": ("сургут", "сургуте", "surgut"),
    "Владимир": ("владимир", "владимире", "vladimir"),
    "Архангельск": ("архангельск", "архангельске", "arkhangelsk"),
    "Чита": ("чита", "чите", "chita"),
    "Грозный": ("грозный", "грозном", "grozny"),
    "Смоленск": ("смоленск", "смоленске", "smolensk"),
    "Курган": ("курган", "кургане", "kurgan"),
    "Орел": ("орел", "орле", "orel"),
    "Череповец": ("череповец", "череповце", "cherepovets"),
    "Вологда": ("вологда", "вологде", "vologda"),
    "Мурманск": ("мурманск", "мурманске", "murmansk"),
    "Петрозаводск": ("петрозаводск", "петрозаводске", "petrozavodsk"),
    "Йошкар-Ола": ("йошкар-ола", "йошкар ола", "yoshkar-ola"),
    "Таганрог": ("таганрог", "таганроге", "taganrog"),
    "Нальчик": ("нальчик", "нальчике", "nalchik"),
    "Шахты": ("шахты", "шахтах", "shakhty"),
    "Дзержинск": ("дзержинск", "дзержинске", "dzerzhinsk"),
    "Орск": ("орск", "орске", "orsk"),
    "Сыктывкар": ("сыктывкар", "сыктывкаре", "syktyvkar"),
    "Нижневартовск": ("нижневартовск", "нижневартовске", "nizhnevartovsk"),
    "Новороссийск": ("новороссийск", "новороссийске", "novorossiysk"),
    "Нижний Новгород": ("нижний новгород", "нижнем новгороде", "н.новгород", "нн", "nizhny novgorod"),
    "Ростов-на-Дону": (
        "ростов-на-дону",
        "ростов на дону",
        "ростове-на-дону",
        "ростове на дону",
        "ростов",
        "ростове",
        "rostov",
    ),
    "Улан-Удэ": ("улан-удэ", "улан удэ", "ulan-ude"),
    "Комсомольск-на-Амуре": ("комсомольск-на-амуре", "комсомольск на амуре"),
    "Химки": ("химки", "химках"),
    "Подольск": ("подольск", "подольске"),
    "Красногорск": ("красногорск", "красногорске"),
    "Мытищи": ("мытищи", "мытищах"),
    "Балашиха": ("балашиха", "балашихе"),
    "Королев": ("королев", "королеве"),
    "Люберцы": ("люберцы", "люберцах"),
    "Одинцово": ("одинцово", "одинцове"),
    "Минск": ("минск", "минске", "minsk"),
    "Гомель": ("гомель", "гомеле"),
    "Брест": ("брест", "бресте"),
    "Витебск": ("витебск", "витебске"),
    "Гродно": ("гродно",),
    "Могилев": ("могилев", "могилеве"),
    "Алматы": ("алматы", "алма-ата", "almaty"),
    "Астана": ("астана", "астане", "нур-султан", "нурсултан", "astana"),
    "Шымкент": ("шымкент", "чимкент"),
    "Караганда": ("караганда", "караганде"),
    "Актобе": ("актобе", "актюбинск"),
    "Бишкек": ("бишкек", "бишкеке", "bishkek"),
    "Ташкент": ("ташкент", "ташкенте", "tashkent"),
    "Ереван": ("ереван", "ереване", "yerevan"),
    "Тбилиси": ("тбилиси", "tbilisi"),
    "Баку": ("баку", "baku"),
    "Киев": ("киев", "киеве", "kyiv", "kiev"),
    "Харьков": ("харьков", "харькове", "kharkiv"),
    "Одесса": ("одесса", "одессе", "odessa"),
    "Днепр": ("днепр", "днепре", "dnipro"),
}

CITY_ALIASES: Final[dict[str, str]] = {
    alias: canonical
    for canonical, aliases in _CITY_ALIASES_RAW.items()
    for alias in (canonical.lower(), *(a.lower() for a in aliases))
}

_CITY_REGION_OVERRIDES: Final[dict[str, str]] = {
    "Химки": "Московская область",
    "Подольск": "Московская область",
    "Красногорск": "Московская область",
    "Мытищи": "Московская область",
    "Балашиха": "Московская область",
    "Королев": "Московская область",
    "Люберцы": "Московская область",
    "Одинцово": "Московская область",
    "Москва": "Московская область",
    "Екатеринбург": "Свердловская область",
    "Нижний Тагил": "Свердловская область",
    "Каменск-Уральский": "Свердловская область",
    "Первоуральск": "Свердловская область",
    "Асбест": "Свердловская область",
    "Серов": "Свердловская область",
    "Новоуральск": "Свердловская область",
    "Верхняя Пышма": "Свердловская область",
    "Верхние Серги": "Свердловская область",
    "Малышева": "Свердловская область",
    "Березовский": "Свердловская область",
    "Ревда": "Свердловская область",
    "Полевской": "Свердловская область",
    "Краснотурьинск": "Свердловская область",
    "Сухой Лог": "Свердловская область",
    "Алапаевск": "Свердловская область",
    "Ирбит": "Свердловская область",
    "Реж": "Свердловская область",
    "Заречный": "Свердловская область",
    "Сысерть": "Свердловская область",
    "Арамиль": "Свердловская область",
    "Среднеуральск": "Свердловская область",
    "Невьянск": "Свердловская область",
    "Кировград": "Свердловская область",
    "Качканар": "Свердловская область",
    "Красноуфимск": "Свердловская область",
    "Артемовский": "Свердловская область",
    "Богданович": "Свердловская область",
    "Карпинск": "Свердловская область",
    "Североуральск": "Свердловская область",
    "Верхняя Салда": "Свердловская область",
    "Нижняя Салда": "Свердловская область",
}
_KNOWN_REGIONS: Final[frozenset[str]] = frozenset(_CITY_REGION_OVERRIDES.values())

_CITY_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"(?<![а-яёa-z0-9])(" + "|".join(
        re.escape(alias) for alias in sorted(CITY_ALIASES, key=len, reverse=True)
    ) + r")(?![а-яёa-z0-9])",
    re.IGNORECASE,
)

_EXPLICIT_CITY_RE = re.compile(
    r"(?:город|г\.|локация|местоположение|нахожусь\s+в|находится\s+в|район)\s*[:—-]?\s*"
    r"([А-ЯЁA-Z][А-Яа-яЁёA-Za-z\- ]{2,30})",
)


def canonical_city(value: str | None) -> str | None:
    """Resolve any known spelling/case form to the canonical city name."""
    if not value:
        return None
    lowered = normalize_text(value).replace("г.", " ").strip(" ,.;:-")
    if not lowered:
        return None
    if lowered in CITY_ALIASES:
        return CITY_ALIASES[lowered]
    # Try the longest alias contained in the string ("Москва, МО").
    for alias in sorted(CITY_ALIASES, key=len, reverse=True):
        if len(alias) >= 4 and alias in lowered:
            return CITY_ALIASES[alias]
    return None


def normalize_city(value: str | None) -> str | None:
    """Canonicalize user input, falling back to a clean display form."""
    if not value:
        return None
    canonical = canonical_city(value)
    if canonical:
        return canonical
    cleaned = re.sub(r"\s+", " ", value).strip(" ,.;:-")
    return cleaned.title() if cleaned else None


def canonical_region(city: str | None) -> str | None:
    if not city:
        return None
    canonical = canonical_city(city) or normalize_city(city)
    if canonical in _KNOWN_REGIONS:
        return canonical
    return _CITY_REGION_OVERRIDES.get(canonical)


def city_matches(a: str | None, b: str | None, *, same_region: bool = True) -> bool:
    """Compare two cities, optionally treating one federal region as a match."""
    if not a or not b:
        return False
    left, right = canonical_city(a) or normalize_city(a), canonical_city(b) or normalize_city(b)
    if not left or not right:
        return False
    if left.casefold() == right.casefold():
        return True
    if same_region:
        left_region, right_region = canonical_region(left), canonical_region(right)
        if left_region and right_region and left_region == right_region:
            return True
    return False


def detect_city(text: str, *, default: str | None = None) -> str | None:
    """Detect the most likely city of a listing."""
    if not text:
        return normalize_city(default)
    searchable = _strip_accents(text)

    explicit = _EXPLICIT_CITY_RE.search(searchable)
    if explicit:
        canonical = canonical_city(explicit.group(1))
        if canonical:
            return canonical

    matches = list(_CITY_PATTERN.finditer(searchable))
    if not matches:
        return normalize_city(default)

    def score(match: re.Match[str]) -> tuple[int, int]:
        before = searchable[max(0, match.start() - 16) : match.start()].lower()
        bonus = 0
        if re.search(r"(город|г\.|локация|📍|местоположение)", before):
            bonus += 3
        if match.start() <= 2 or match.end() >= len(searchable) - 2:
            bonus += 1
        return bonus, match.end()

    best = max(matches, key=score)
    return CITY_ALIASES[best.group(1).lower()] or normalize_city(default)


# ---------------------------------------------------------------------------
# Brands & models
# ---------------------------------------------------------------------------

BRAND_ALIASES: Final[dict[str, tuple[str, ...]]] = {
    "BMW": ("bmw", "бмв", "бэха", "бумер"),
    "Mercedes-Benz": ("mercedes-benz", "mercedes", "мерседес", "мерседес-бенц", "мерс", "мерин"),
    "Audi": ("audi", "ауди"),
    "Volkswagen": ("volkswagen", "volkswagen", "фольксваген", "фольц", "vw"),
    "Toyota": ("toyota", "тойота", "таета", "тойоту", "тойоты", "тойоте"),
    "Lexus": ("lexus", "лексус"),
    "Kia": ("kia", "киа"),
    "Hyundai": ("hyundai", "хендай", "хундай", "хендэ", "хендей"),
    "Lada": ("lada", "лада", "ладу", "лады", "ладе", "ваз", "жигули", "vaz"),
    "Skoda": ("skoda", "шкода", "шкоду", "шкоды", "шкоде"),
    "Renault": ("renault", "рено"),
    "Nissan": ("nissan", "ниссан"),
    "Mazda": ("mazda", "мазда", "мазду", "мазды", "мазде"),
    "Ford": ("ford", "форд"),
    "Chevrolet": ("chevrolet", "шевроле", "chevy"),
    "Opel": ("opel", "опель"),
    "Peugeot": ("peugeot", "пежо"),
    "Citroen": ("citroen", "ситроен"),
    "Volvo": ("volvo", "вольво"),
    "Subaru": ("subaru", "субару"),
    "Mitsubishi": ("mitsubishi", "митсубиси", "мицубиси"),
    "Honda": ("honda", "хонда", "хонду", "хонды", "хонде"),
    "Suzuki": ("suzuki", "сузуки"),
    "Land Rover": ("land rover", "лэнд ровер", "ленд ровер", "лендровер", "лэндровер"),
    "Jaguar": ("jaguar", "ягуар"),
    "Porsche": ("porsche", "порше"),
    "Infiniti": ("infiniti", "инфинити"),
    "Cadillac": ("cadillac", "кадиллак"),
    "Jeep": ("jeep", "джип"),
    "Dodge": ("dodge", "додж"),
    "Chery": ("chery", "чери", "черри"),
    "Haval": ("haval", "хавал", "хавейл"),
    "Geely": ("geely", "джили"),
    "Exeed": ("exeed", "эксид"),
    "Tank": ("tank", "танк"),
    "Omoda": ("omoda", "омода"),
    "Changan": ("changan", "ченган", "чанган"),
    "UAZ": ("uaz", "уаз", "уазик"),
    "Tesla": ("tesla", "тесла"),
    "Mini": ("mini", "мини"),
    "Seat": ("seat", "сеат"),
    "Fiat": ("fiat", "фиат"),
    "Alfa Romeo": ("alfa romeo", "альфа ромео"),
    "Genesis": ("genesis", "генезис"),
    "Datsun": ("datsun", "датсун"),
    "Lifan": ("lifan", "лифан"),
    "Ravon": ("ravon", "равон"),
    "Great Wall": ("great wall", "грейт вол"),
    "FAW": ("faw",),
    "Isuzu": ("isuzu", "исузу"),
    "SsangYong": ("ssangyong", "ссангйонг", "санг йонг"),
    "Daihatsu": ("daihatsu", "дайхатсу"),
    "Smart": ("smart", "смарт"),
    "Lixiang": ("lixiang", "лисян", "li auto"),
    "Zeekr": ("zeekr", "зикр"),
    "Voyah": ("voyah", "воях"),
    "Moskvich": ("moskvich", "москвич"),
    "ZAZ": ("zaz", "заз"),
    "Bogdan": ("bogdan", "богдан"),
}

_BRAND_INDEX: dict[str, str] = {
    alias: canonical
    for canonical, aliases in BRAND_ALIASES.items()
    for alias in (canonical.lower(), *(a.lower() for a in aliases))
}
_BRAND_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"(?<![а-яёa-z0-9])(" + "|".join(
        re.escape(alias) for alias in sorted(_BRAND_INDEX, key=len, reverse=True)
    ) + r")(?![а-яёa-z0-9])",
    re.IGNORECASE,
)

_MODEL_STOPWORDS: Final[frozenset[str]] = frozenset(
    {
        "продам",
        "продаю",
        "продается",
        "продаётся",
        "продажа",
        "цена",
        "стоимость",
        "торг",
        "торгуюсь",
        "срочно",
        "год",
        "года",
        "году",
        "годов",
        "пробег",
        "пробегом",
        "км",
        "руб",
        "рублей",
        "р",
        "тыс",
        "млн",
        "обмен",
        "возможен",
        "кредит",
        "рассрочка",
        "звоните",
        "пишите",
        "телефон",
        "whatsapp",
        "telegram",
        "состояние",
        "состоянии",
        "идеальном",
        "идеальное",
        "отличное",
        "хорошее",
        "новая",
        "новый",
        "не",
        "без",
        "в",
        "во",
        "на",
        "с",
        "со",
        "и",
        "или",
        "для",
        "по",
        "от",
        "до",
        "за",
        "при",
        "как",
        "что",
        "это",
        "все",
        "весь",
        "авто",
        "автомобиль",
        "машина",
        "машину",
        "седан",
        "хэтчбек",
        "универсал",
        "кроссовер",
        "внедорожник",
        "купе",
        "кабриолет",
        "минивэн",
        "пикап",
        "акпп",
        "мкпп",
        "автомат",
        "вариатор",
        "робот",
        "механика",
        "бензин",
        "дизель",
        "гибрид",
        "электро",
        "газ",
        "метан",
        "пропан",
        "л.с",
        "лс",
        "сил",
        "цвет",
        "черный",
        "чёрный",
        "белый",
        "серебристый",
        "серый",
        "синий",
        "красный",
        "зеленый",
        "зелёный",
        "коричневый",
        "бежевый",
        "документы",
        "дтп",
        "вложений",
        "требует",
        "ремонта",
        "обслужен",
        "сервис",
        "комплектация",
        "комплектации",
        "владельцев",
        "владелец",
        "птс",
        "стс",
        "номер",
        " vin",
        "vin",
        "растаможен",
        "растаможена",
        "пробегу",
        "реальный",
        "оригинал",
        "срочный",
        "звонок",
        "звони",
        "писать",
        "смс",
        "адрес",
        "фото",
        "видео",
        "обзор",
        "тест",
        "драйв",
        "лизинг",
        "трейд",
        "trade",
        "in",
        "обмене",
        "рассмотрю",
        "варианты",
        "под",
        "договор",
        "оформление",
        "оформлена",
        "учет",
        "учёте",
    }
)

for _city_alias in CITY_ALIASES:
    _MODEL_STOPWORDS |= {word for word in _city_alias.split() if len(word) > 2}
    _MODEL_STOPWORDS |= {_city_alias}

_MODEL_TOKEN_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9.\-/]*")
_BMW_MODEL_HINTS: Final[dict[str, str]] = {
    "тройка": "3 Series",
    "трешка": "3 Series",
    "трешку": "3 Series",
    "пятерка": "5 Series",
    "пятак": "5 Series",
    "семерка": "7 Series",
}

# Russian transliterations and colloquial names -> canonical English model names.
MODEL_ALIASES: Final[dict[str, str]] = {
    "камри": "Camry",
    "камрюха": "Camry",
    "марк 2": "Mark II",
    "марк ii": "Mark II",
    "марковник": "Mark II",
    "mark 2": "Mark II",
    "mark ii": "Mark II",
    "буханка": "Bukhanka",
    "тришка": "3 Series",
    "трешка": "3 Series",
    "королла": "Corolla",
    "прадо": "Prado",
    "крузак": "Land Cruiser",
    "ленд крузер": "Land Cruiser",
    "хайлендер": "Highlander",
    "рав4": "RAV4",
    "рав 4": "RAV4",
    "солярис": "Solaris",
    "рио": "Rio",
    "спортейдж": "Sportage",
    "тигуан": "Tiguan",
    "поло": "Polo",
    "пассат": "Passat",
    "октавия": "Octavia",
    "фокус": "Focus",
    "мондео": "Mondeo",
    "астра": "Astra",
    "корса": "Corsa",
    "логан": "Logan",
    "дастер": "Duster",
    "аркана": "Arkana",
    "каптюр": "Kaptur",
    "веста": "Vesta",
    "весту": "Vesta",
    "весте": "Vesta",
    "гранта": "Granta",
    "гранту": "Granta",
    "нива": "Niva",
    "приора": "Priora",
    "калина": "Kalina",
    "ларгус": "Largus",
    "патриот": "Patriot",
    "3 серии": "3 Series",
    "5 серии": "5 Series",
    "с-класс": "C-Class",
    "е-класс": "E-Class",
}
_MODEL_TOKEN_ALIASES: Final[dict[str, str]] = {
    key: value.lower() for key, value in MODEL_ALIASES.items() if " " not in key
}


def normalize_make(value: str | None) -> str | None:
    """Canonicalize a brand name ("бмв" -> "BMW")."""
    if not value:
        return None
    cleaned = re.sub(r"\s+", " ", _strip_accents(value)).strip(" ,.;:-")
    if not cleaned:
        return None
    lowered = cleaned.lower()
    if lowered in _BRAND_INDEX:
        return _BRAND_INDEX[lowered]
    return cleaned.title()


def detect_make(text: str, *, default: str | None = None) -> str | None:
    """Find the first known brand mention in the text."""
    if not text:
        return normalize_make(default)
    match = _BRAND_PATTERN.search(_strip_accents(text))
    if not match:
        return normalize_make(default)
    return _BRAND_INDEX[match.group(1).lower()]


def _extract_model_after(text: str, brand_end: int, make: str | None) -> str | None:
    slice_text = text[brand_end : brand_end + 60]
    # Parenthesized generation codes ("(E90)") confuse matching — drop them.
    slice_text = re.sub(r"\([^)]*\)", " ", slice_text)
    slice_text = re.split(r"[,;!?\n]", slice_text, maxsplit=1)[0]

    tokens: list[str] = []
    for token_match in _MODEL_TOKEN_RE.finditer(slice_text):
        token = token_match.group(0).strip(".-/")
        lowered = token.lower()
        if not token or len(token) > 22:
            break
        if lowered in _MODEL_STOPWORDS:
            break
        if re.fullmatch(r"(?:19|20)\d{2}", token):
            break
        if token.isdigit() and len(token) > 4:
            break
        tokens.append(token)
        if len(tokens) >= 4:
            break

    if not tokens:
        return None
    if make == "BMW" and len(tokens) == 1:
        hinted = _BMW_MODEL_HINTS.get(tokens[0].lower())
        if hinted:
            return hinted
    raw_model = " ".join(tokens)
    return normalize_model(raw_model)


def normalize_model(value: str | None) -> str | None:
    """Normalize model spelling for storage and comparison."""
    if not value:
        return None
    cleaned = re.sub(r"\s+", " ", _strip_accents(value)).strip(" ,.;:-")
    if not cleaned:
        return None
    cleaned = re.sub(r"\bрест\b", "Restyling", cleaned, flags=re.IGNORECASE)
    aliased = MODEL_ALIASES.get(cleaned.lower())
    if aliased:
        return aliased
    # Keep alphanumeric designators readable: "x5" -> "X5", "3 series" -> "3 Series".
    return cleaned.title().replace("'S", "s")


def tokenize_model(value: str | None) -> set[str]:
    if not value:
        return set()
    canonical = normalize_model(value) or value
    normalized = normalize_text(canonical)
    raw_tokens = set(re.findall(r"[a-zа-я0-9]+", normalized))
    aliases = {"серии": "series", "серия": "series", "класс": "class"}
    tokens: set[str] = set()
    for token in raw_tokens:
        token = aliases.get(token, token)
        tokens.add(_MODEL_TOKEN_ALIASES.get(token, token))
    # BMW-style designators: 320i -> {320i, 3, series} so it matches "3 Series".
    for token in list(tokens):
        match = re.fullmatch(r"([1-8])\d{2}[a-z]?", token)
        if match:
            tokens.update({match.group(1), "series"})
    return tokens


def models_match(subscription_model: str | None, listing_model: str | None) -> bool:
    """Fuzzy model comparison based on token overlap.

    "3 series" matches "3", "3 series xdrive"; "x5" matches "x5 m".
    """
    left = tokenize_model(subscription_model)
    right = tokenize_model(listing_model)
    if not left or not right:
        return False
    if left <= right or right <= left:
        return True
    intersection = left & right
    if not intersection:
        return False
    return len(intersection) / len(left) >= 0.5


# ---------------------------------------------------------------------------
# Full listing parsing
# ---------------------------------------------------------------------------


_TRANSMISSION_PATTERNS: Final[tuple[tuple[re.Pattern[str], str], ...]] = (
    (re.compile(r"\b(?:акпп|автомат|automatic|at)\b", re.IGNORECASE), "АКПП"),
    (re.compile(r"\b(?:мкпп|механика|manual|mt)\b", re.IGNORECASE), "МКПП"),
    (re.compile(r"\b(?:5|6)\s*ступ(?:ка|ки|енчатая)?\b", re.IGNORECASE), "МКПП"),
    (re.compile(r"\b(?:вариатор|cvt)\b", re.IGNORECASE), "Вариатор"),
    (re.compile(r"\b(?:робот|dsg|dct)\b", re.IGNORECASE), "Робот"),
)
_ENGINE_VOLUME_RE = re.compile(r"(?<![\d.])(\d[.,]\d)(?![\d])")


def parse_transmission(text: str | None) -> str | None:
    source = text or ""
    for pattern, value in _TRANSMISSION_PATTERNS:
        if pattern.search(source):
            return value
    return None


def parse_engine_volume(text: str | None) -> float | None:
    for match in _ENGINE_VOLUME_RE.finditer(text or ""):
        try:
            value = float(match.group(1).replace(",", "."))
        except ValueError:
            continue
        if 0.6 <= value <= 8.0:
            return value
    return None


@dataclass(frozen=True, slots=True)
class ParsedListing:
    title: str = ""
    price: int | None = None
    city: str | None = None
    make: str | None = None
    model: str | None = None
    year: int | None = None
    generation: str | None = None
    transmission: str | None = None
    engine_volume: float | None = None
    confidence: float = 0.0

    @property
    def display_title(self) -> str:
        parts = [part for part in (self.make, self.model) if part]
        if parts:
            return " ".join(parts)
        return self.title or "Автомобиль"


def _make_title(text: str, fallback: str | None = None) -> str:
    if fallback and fallback.strip():
        return re.sub(r"\s+", " ", fallback).strip()[:300]
    for line in text.splitlines():
        cleaned = line.strip(" \t-•·*#>")
        if len(cleaned) >= 3:
            return cleaned[:300]
    return re.sub(r"\s+", " ", text).strip()[:300] or "Автомобиль"


def parse_listing(
    text: str,
    *,
    title: str | None = None,
    default_city: str | None = None,
    default_price: int | None = None,
    default_year: int | None = None,
    default_make: str | None = None,
) -> ParsedListing:
    """Parse a free-form advertisement into structured fields.

    ``default_*`` values come from structured sources (VK geo, JSON-LD) and win
    over text heuristics when the text itself yields nothing.
    """
    raw = text or ""
    detected_make = detect_make(raw, default=default_make)
    slang = resolve_slang(raw, make=detected_make, require_context=True)
    if slang is not None:
        make = slang.make
        model = slang.model
        generation = slang.generation or extract_generation(raw)
        if generation and generation.lower() not in model.lower():
            model = f"{model} {generation}"
    else:
        make = detected_make
        brand_match = _BRAND_PATTERN.search(_strip_accents(raw))
        model = _extract_model_after(raw, brand_match.end(), make) if brand_match else None
        generation = extract_generation(raw)
    price = parse_price(raw) or (int(default_price) if default_price else None)
    city = detect_city(raw, default=default_city)
    year = parse_year(raw) or (int(default_year) if default_year else None)

    known = sum(
        1
        for value in (make, model, price, city, year)
        if value not in (None, "", 0)
    )
    confidence = round(min(1.0, known / 5), 2)

    return ParsedListing(
        title=_make_title(raw, title),
        price=price,
        city=city,
        make=make,
        model=model,
        year=year,
        generation=generation,
        transmission=parse_transmission(raw),
        engine_volume=parse_engine_volume(raw),
        confidence=confidence,
    )


def iter_city_aliases() -> Iterable[str]:  # pragma: no cover - introspection helper
    return CITY_ALIASES.keys()

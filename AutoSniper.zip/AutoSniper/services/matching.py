"""Subscription <-> listing matching logic."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Protocol

from database.models import Subscription
from services.geo import distance_between_cities
from services.parser_engine import (
    canonical_city,
    city_matches,
    models_match,
    normalize_city,
    normalize_make,
)

__all__ = ["MatchPolicy", "MatchResult", "SubscriptionMatcher"]


class ListingLike(Protocol):
    make: str | None
    model: str | None
    price: int | None
    city: str | None
    year: int | None
    published_at: datetime | None


@dataclass(frozen=True, slots=True)
class MatchPolicy:
    """What to do when a listing field is missing.

    ``require_known_price`` — never alert if the budget cannot be verified.
    ``require_known_city`` — never alert if the city could not be detected.
    ``same_region`` — treat e.g. Moscow and Moscow Oblast cities as a match.
    """

    require_known_price: bool = True
    require_known_city: bool = False
    same_region: bool = True


@dataclass(frozen=True, slots=True)
class MatchResult:
    matched: bool
    reasons: tuple[str, ...]

    @property
    def explanation(self) -> str:
        return ", ".join(self.reasons) if self.reasons else "ok"


class SubscriptionMatcher:
    def __init__(self, policy: MatchPolicy | None = None) -> None:
        self.policy = policy or MatchPolicy()

    def match(
        self,
        listing: ListingLike,
        subscription: Subscription,
        *,
        now: datetime | None = None,
    ) -> MatchResult:
        failures: list[str] = []

        # --- make ---------------------------------------------------------
        wanted_make = normalize_make(subscription.make)
        actual_make = normalize_make(listing.make)
        if not wanted_make:
            failures.append("subscription_make_empty")
        elif not actual_make:
            failures.append("make_unknown")
        elif wanted_make.casefold() != actual_make.casefold():
            failures.append(f"make_mismatch:{actual_make}")

        # --- models -------------------------------------------------------
        wanted_models = list(getattr(subscription, "model_list", []) or [])
        if not wanted_models and subscription.model:
            wanted_models = [subscription.model]
        if wanted_models:
            if not listing.model:
                failures.append("model_unknown")
            elif not any(models_match(model, listing.model) for model in wanted_models):
                failures.append(f"model_mismatch:{listing.model}")

        # --- price --------------------------------------------------------
        if subscription.max_price:
            if listing.price is None:
                if self.policy.require_known_price:
                    failures.append("price_unknown")
            elif listing.price > subscription.max_price:
                failures.append(f"price_too_high:{listing.price}")

        # --- city ---------------------------------------------------------
        wanted_city = normalize_city(subscription.city)
        actual_city = normalize_city(listing.city)
        if wanted_city:
            if not actual_city:
                if self.policy.require_known_city:
                    failures.append("city_unknown")
            elif not city_matches(wanted_city, actual_city, same_region=self.policy.same_region):
                failures.append(f"city_mismatch:{actual_city}")

        # --- distance from the selected city ------------------------------
        max_distance = getattr(subscription, "max_distance_km", None)
        if max_distance is not None:
            if not wanted_city:
                failures.append("distance_without_city")
            elif not actual_city:
                failures.append("city_unknown_for_distance")
            elif max_distance == 0:
                if canonical_city(wanted_city) != canonical_city(actual_city):
                    failures.append(f"outside_city:{actual_city}")
            else:
                distance = distance_between_cities(wanted_city, actual_city)
                if distance is None:
                    failures.append("distance_unknown")
                elif distance > max_distance:
                    failures.append(f"distance_too_far:{int(round(distance))}km")

        # --- publication age ----------------------------------------------
        max_age_days = getattr(subscription, "max_age_days", None)
        if max_age_days:
            published = getattr(listing, "published_at", None)
            if published is None:
                failures.append("published_at_unknown")
            else:
                if published.tzinfo is None:
                    published = published.replace(tzinfo=UTC)
                reference = now or datetime.now(UTC)
                if reference.tzinfo is None:
                    reference = reference.replace(tzinfo=UTC)
                age_seconds = (reference - published).total_seconds()
                if age_seconds > max_age_days * 86_400:
                    failures.append(f"too_old:{int(age_seconds // 86_400)}d")

        # --- year ---------------------------------------------------------
        if subscription.year_min:
            if listing.year is None:
                failures.append("year_unknown")
            elif listing.year < subscription.year_min:
                failures.append(f"year_too_old:{listing.year}")

        if failures:
            return MatchResult(False, tuple(failures))
        return MatchResult(True, ("ok",))

    def match_all(
        self, listing: ListingLike, subscriptions: Sequence[Subscription]
    ) -> list[tuple[Subscription, MatchResult]]:
        """Return ``(subscription, result)`` for every subscription that matches."""
        matched: list[tuple[Subscription, MatchResult]] = []
        for subscription in subscriptions:
            result = self.match(listing, subscription)
            if result.matched:
                matched.append((subscription, result))
        return matched


__all__ = ["ListingLike", "MatchPolicy", "MatchResult", "SubscriptionMatcher"]

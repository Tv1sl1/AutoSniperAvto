"""Human-readable formatting shared by the bot and the notifier."""

from __future__ import annotations

import html
from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo

from database.models import Subscription

__all__ = [
    "format_age_days",
    "format_city",
    "format_datetime",
    "format_distance",
    "format_price",
    "format_subscription_line",
    "format_subscription_summary",
    "format_year",
    "truncate",
]


def format_price(value: int | None) -> str:
    if value is None:
        return "цена не указана"
    return f"{value:,}".replace(",", " ") + " ₽"


def format_city(value: str | None) -> str:
    return value or "любой город"


def format_distance(value: int | None) -> str:
    if value is None:
        return "не важно"
    if value == 0:
        return "только выбранный город"
    return f"до {value} км"


def format_age_days(value: int | None) -> str:
    if not value:
        return "без ограничения по дате"
    return f"опубликовано за последние {value} дн."


def format_year(value: int | None) -> str:
    return f"{value} г." if value else "год не указан"


def truncate(text: str | None, limit: int = 400) -> str:
    if not text:
        return ""
    cleaned = " ".join(text.split())
    if len(cleaned) <= limit:
        return cleaned
    return cleaned[: max(0, limit - 1)].rstrip() + "…"


def _models_label(subscription: Subscription) -> str:
    models = subscription.model_list
    return ", ".join(models) if models else "любая модель"


def format_subscription_line(subscription: Subscription) -> str:
    """HTML-safe one-line summary of a subscription."""
    model = _models_label(subscription)
    model_part = f" {html.escape(model)}" if model != "любая модель" else " (любая модель)"
    parts = [f"{html.escape(subscription.make)}{model_part}"]
    parts.append(html.escape(format_city(subscription.city)))
    if subscription.max_distance_km is not None and subscription.city:
        parts.append(html.escape(format_distance(subscription.max_distance_km)))
    parts.append(f"до {format_price(subscription.max_price)}" if subscription.max_price else "без ограничения цены")
    if subscription.year_min:
        parts.append(f"от {subscription.year_min} г.")
    if not subscription.is_active:
        parts.append("на паузе")
    return " · ".join(parts)


def format_subscription_summary(subscription: Subscription) -> str:
    """HTML-safe multi-line card used in the confirmation step."""
    lines = [
        f"🚘 <b>Марка:</b> {html.escape(subscription.make)}",
        f"📌 <b>Модели:</b> {html.escape(_models_label(subscription))}",
        f"📍 <b>Город:</b> {html.escape(format_city(subscription.city))}",
    ]
    if subscription.max_distance_km is not None and subscription.city:
        lines.append(f"🛣 <b>Расстояние:</b> {html.escape(format_distance(subscription.max_distance_km))}")
    lines.append(f"💰 <b>Максимальная цена:</b> {format_price(subscription.max_price)}")
    if subscription.max_age_days:
        lines.append(f"🕒 <b>Свежесть:</b> {html.escape(format_age_days(subscription.max_age_days))}")
    if subscription.year_min:
        lines.append(f"📅 <b>Год от:</b> {subscription.year_min}")
    return "\n".join(lines)


def format_datetime(value: datetime | None, timezone_name: str = "Europe/Moscow") -> str:
    if value is None:
        return "—"
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    try:
        tz = ZoneInfo(timezone_name)
    except Exception:  # pragma: no cover - invalid tz config
        tz = UTC
    return value.astimezone(tz).strftime("%d.%m.%Y %H:%M")


def format_any(value: Any) -> str:  # pragma: no cover - debugging helper
    return str(value)

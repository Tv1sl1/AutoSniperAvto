"""Russian automotive slang and common misspellings.

The dictionary is intentionally local and cheap: no external APIs. Entries may
be ambiguous (``семёрка`` is a Lada 2107 or a BMW 7 Series), so callers pass the
brand already detected in the text to choose the right candidate.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass

__all__ = [
    "SLANG_PATTERNS",
    "SlangMatch",
    "canonical_model",
    "extract_generation",
    "normalize_lookup_text",
    "resolve_slang",
    "slang_matches_query",
    "slang_search_terms",
]


@dataclass(frozen=True, slots=True)
class SlangMatch:
    make: str
    model: str
    generation: str | None = None


@dataclass(frozen=True, slots=True)
class _Entry:
    phrase: str
    candidates: tuple[SlangMatch, ...]


def _m(make: str, model: str, generation: str | None = None) -> SlangMatch:
    return SlangMatch(make=make, model=model, generation=generation)


SLANG_ENTRIES: tuple[_Entry, ...] = (
    _Entry("семерка", (_m("Lada", "2107"), _m("BMW", "7 Series"))),
    _Entry("семёрка", (_m("Lada", "2107"), _m("BMW", "7 Series"))),
    _Entry("семерку", (_m("Lada", "2107"), _m("BMW", "7 Series"))),
    _Entry("четырка", (_m("Lada", "2104"),)),
    _Entry("четвёрка", (_m("Lada", "2104"),)),
    _Entry("четырку", (_m("Lada", "2104"),)),
    _Entry("пятерка", (_m("Lada", "2105"), _m("BMW", "5 Series"))),
    _Entry("пятёрка", (_m("Lada", "2105"), _m("BMW", "5 Series"))),
    _Entry("пятерку", (_m("Lada", "2105"), _m("BMW", "5 Series"))),
    _Entry("шестерка", (_m("Lada", "2106"),)),
    _Entry("шестёрка", (_m("Lada", "2106"),)),
    _Entry("шестерку", (_m("Lada", "2106"),)),
    _Entry("восьмерка", (_m("Lada", "2108"),)),
    _Entry("восьмёрка", (_m("Lada", "2108"),)),
    _Entry("восьмерку", (_m("Lada", "2108"),)),
    _Entry("девятка", (_m("Lada", "2109"),)),
    _Entry("девятку", (_m("Lada", "2109"),)),
    _Entry("десятка", (_m("Lada", "2110"),)),
    _Entry("десятку", (_m("Lada", "2110"),)),
    _Entry("марковник", (_m("Toyota", "Mark II"),)),
    _Entry("марковника", (_m("Toyota", "Mark II"),)),
    _Entry("марк 2", (_m("Toyota", "Mark II"),)),
    _Entry("марк ii", (_m("Toyota", "Mark II"),)),
    _Entry("mark 2", (_m("Toyota", "Mark II"),)),
    _Entry("mark ii", (_m("Toyota", "Mark II"),)),
    _Entry("глазастый", (_m("Toyota", "Mark II", "90"),)),
    _Entry("буханка", (_m("UAZ", "Bukhanka"),)),
    _Entry("буханку", (_m("UAZ", "Bukhanka"),)),
    _Entry("солярис", (_m("Hyundai", "Solaris"),)),
    _Entry("камри", (_m("Toyota", "Camry"),)),
    _Entry("camry", (_m("Toyota", "Camry"),)),
    _Entry("камри 40", (_m("Toyota", "Camry", "40"),)),
    _Entry("camry 40", (_m("Toyota", "Camry", "40"),)),
    _Entry("фокус", (_m("Ford", "Focus"),)),
    _Entry("focus", (_m("Ford", "Focus"),)),
    _Entry("фокус 2", (_m("Ford", "Focus 2"),)),
    _Entry("focus 2", (_m("Ford", "Focus 2"),)),
    _Entry("фокус 2 рест", (_m("Ford", "Focus 2 Restyling"),)),
    _Entry("focus 2 rest", (_m("Ford", "Focus 2 Restyling"),)),
    _Entry("октавия", (_m("Skoda", "Octavia"),)),
    _Entry("рио", (_m("Kia", "Rio"),)),
    _Entry("поло", (_m("Volkswagen", "Polo"),)),
    _Entry("тигуан", (_m("Volkswagen", "Tiguan"),)),
    _Entry("логан", (_m("Renault", "Logan"),)),
    _Entry("дастер", (_m("Renault", "Duster"),)),
    _Entry("тришка", (_m("BMW", "3 Series"),)),
    _Entry("тришку", (_m("BMW", "3 Series"),)),
    _Entry("трешка", (_m("BMW", "3 Series"),)),
    _Entry("кабан", (_m("BMW", "7 Series"),)),
    _Entry("прадик", (_m("Toyota", "Prado"),)),
    _Entry("крузак", (_m("Toyota", "Land Cruiser"),)),
)
SLANG_ENTRIES = tuple(sorted(SLANG_ENTRIES, key=lambda item: len(item.phrase), reverse=True))

# "7 ку", "7ку", "в 90 кузове", "марк в 90 кузове"
SLANG_PATTERNS: tuple[tuple[re.Pattern[str], tuple[SlangMatch, ...]], ...] = (
    (
        re.compile(r"(?<!\d)7\s*к(?:у|уз(?:ов)?(?:е|а)?)?(?!\w)", re.IGNORECASE),
        (_m("Lada", "2107"),),
    ),
    (
        re.compile(r"\bмарк(?:\s*(?:2|ii))?\b", re.IGNORECASE),
        (_m("Toyota", "Mark II"),),
    ),
)

_GENERATION_RE = re.compile(
    r"(?:в\s*)?(\d{2,3})\s*(?:-?м\s*)?кузов(?:е|а|у)?|\b(?:xv|x)\s*(\d{2,3})\b",
    re.IGNORECASE,
)
_MAKE_ALIASES = {
    "ваз": "lada",
    "lada": "lada",
    "тойота": "toyota",
    "toyota": "toyota",
    "бмв": "bmw",
    "bmw": "bmw",
    "уаз": "uaz",
    "uaz": "uaz",
    "хендай": "hyundai",
    "хёндай": "hyundai",
    "hyundai": "hyundai",
}


def normalize_lookup_text(value: str | None) -> str:
    if not value:
        return ""
    text = value.replace("ё", "е").replace("Ё", "Е").lower()
    return re.sub(r"\s+", " ", text).strip(" ,.;:-")


def _make_key(value: str | None) -> str:
    key = normalize_lookup_text(value)
    return _MAKE_ALIASES.get(key, key)


def _choose(candidates: Iterable[SlangMatch], make: str | None) -> SlangMatch:
    wanted = _make_key(make)
    items = tuple(candidates)
    if wanted:
        for item in items:
            if _make_key(item.make) == wanted:
                return item
    return items[0]


def extract_generation(text: str | None) -> str | None:
    match = _GENERATION_RE.search(text or "")
    if not match:
        return None
    return match.group(1) or match.group(2)


_AUTO_CONTEXT = re.compile(
    r"\b(?:авто|автомоб|машин|кузов|двигател|мотор|пробег|руб|цена|торг|"
    r"тачка|обмен|покупк|куплю|документ|птс|стс|ваз|лада|тойота|бмв|"
    r"мерседес|хендай|хёндай|форд|уаз|(?:19|20)\d{2}|\d+\s*к)\b",
    re.IGNORECASE,
)


def _has_auto_context(text: str) -> bool:
    return bool(_AUTO_CONTEXT.search(text))


def resolve_slang(
    text: str | None,
    *,
    make: str | None = None,
    require_context: bool = False,
) -> SlangMatch | None:
    """Return a brand/model for a slang phrase, preferring the detected brand.

    Ambiguous words (``семёрка`` = Lada 2107 / BMW 7) require automotive
    context when ``require_context`` is set, to avoid lotteries and memes.
    """
    normalized = normalize_lookup_text(text)
    if not normalized:
        return None

    for pattern, candidates in SLANG_PATTERNS:
        if pattern.search(normalized):
            if require_context and len(candidates) > 1 and not _has_auto_context(normalized):
                return None
            match = _choose(candidates, make)
            generation = extract_generation(normalized)
            if generation and match.make == "Toyota":
                return SlangMatch(match.make, match.model, generation)
            return match

    for entry in SLANG_ENTRIES:
        phrase = normalize_lookup_text(entry.phrase)
        if not re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", normalized):
            continue
        if require_context and len(entry.candidates) > 1 and not _has_auto_context(normalized):
            return None
        match = _choose(entry.candidates, make)
        generation = extract_generation(normalized)
        if generation and match.make == "Toyota":
            return SlangMatch(match.make, match.model, generation)
        return match
    return None


def canonical_model(make: str | None, model: str | None) -> SlangMatch | None:
    """Slang/model lookup for the subscription wizard.

    When the user already chose a brand, a slang word from another brand must
    not silently replace it (e.g. Lada + "кабан").
    """
    match = resolve_slang(model, make=make)
    if match and make and _make_key(match.make) != _make_key(make):
        return None
    return match


def _model_tokens(value: str | None) -> set[str]:
    return {
        token.lower()
        for token in re.findall(r"[A-Za-zА-Яа-яЁё0-9]+", value or "")
        if len(token) > 1
    }


def _models_overlap(left: str | None, right: str | None) -> bool:
    a, b = _model_tokens(left), _model_tokens(right)
    return bool(a and b and (a <= b or b <= a or bool(a & b)))


def slang_matches_query(text: str, make: str | None, models: Iterable[str]) -> bool:
    """True when a slang phrase in ``text`` describes the requested car."""
    match = resolve_slang(text, make=make, require_context=True)
    if match is None:
        return False
    if make and _make_key(match.make) != _make_key(make):
        return False
    wanted = list(models)
    if not wanted:
        return True
    return any(_models_overlap(match.model, model) for model in wanted)


def slang_search_terms(make: str | None, models: Iterable[str]) -> tuple[str, ...]:
    """Search words for VK/wall.search: slang first, then canonical phrases."""
    wanted = list(models)
    terms: list[str] = []
    for entry in SLANG_ENTRIES:
        match = _choose(entry.candidates, make)
        if make and _make_key(match.make) != _make_key(make):
            continue
        if wanted and not any(_models_overlap(match.model, model) for model in wanted):
            continue
        terms.append(entry.phrase)
    if _make_key(make) == "lada" and any(_models_overlap("2107", model) for model in wanted):
        terms.extend(("7 ку", "7ку"))
    return tuple(dict.fromkeys(terms))
